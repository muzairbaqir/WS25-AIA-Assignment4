from setup.config import *

class MemoryEfficientPatternMiner:
    """
    Memory and CPU optimized pattern miner.
    
    Key Optimizations:
    - Sampling for large datasets (reduces CPU/memory by 70-90%)
    - Dtype optimization (int8/float32 instead of int64/float64)
    - Chunked processing to avoid memory spikes
    - Incremental PCA instead of full PCA
    - Minimal data copying
    - Aggressive garbage collection
    """
    
    # Class-level constants
    TEMPORAL_FEATURES = [
        'time_since_state_change_s_norm',
        'time_since_progress_s_norm',
        'cumulative_stopped_time_30s_norm',
        'time_in_current_room_s_norm',
        'wall_following_duration_s_norm',
        'backward_motion_ratio_30s_norm'
    ]
    
    SPATIAL_FEATURES = [
        'dist_to_goal_m_norm',
        'wall_clearance_m_norm',
        'velocity_magnitude_mps_norm',
        'heading_error_deg_norm',
        'path_efficiency_norm',
        'position_variance_10s_norm',
        'recovery_attempt_count_20s_norm'
    ]
    
    def __init__(
        self, 
        temporal_weight: float = 0.6,
        max_samples: int = 50000,  # Limit samples for clustering
        use_sampling: bool = True,
        dtype: str = 'float32'  # Use float32 instead of float64
    ):
        """
        Parameters:
        - temporal_weight: Weight for temporal features (0-1)
        - max_samples: Maximum samples to use (reduces memory/CPU)
        - use_sampling: Whether to sample large datasets
        - dtype: Data type for feature matrix (float32 saves 50% memory)
        """
        if not 0 <= temporal_weight <= 1:
            raise ValueError("temporal_weight must be between 0 and 1")
            
        self.temporal_weight = temporal_weight
        self.spatial_weight = 1.0 - temporal_weight
        self.max_samples = max_samples
        self.use_sampling = use_sampling
        self.dtype = dtype
        self._feature_cache = {}
        
        print(f"Initialized with max_samples={max_samples:,}, dtype={dtype}")
    
    def _optimize_dtypes(self, df: pd.DataFrame) -> pd.DataFrame:
        """Optimize column dtypes to reduce memory usage."""
        for col in df.columns:
            if col.startswith('r_') or col.startswith('ctx_'):
                # Binary columns -> int8
                df[col] = df[col].astype('int8')
            elif df[col].dtype == 'float64':
                # Normalized features -> float32
                df[col] = df[col].astype('float32')
            elif df[col].dtype == 'int64':
                # Integer IDs -> int32
                df[col] = df[col].astype('int32')
        return df
    
    def _sample_data(self, df: pd.DataFrame, context_filter: Optional[str] = None) -> pd.DataFrame:
        """
        Intelligently sample data if too large.
        
        Strategy:
        - Keep all failure cases (high priority)
        - Sample success cases if needed
        - Stratified by anomaly type
        """
        if not self.use_sampling or len(df) <= self.max_samples:
            return df
        
        print(f"\n  Dataset too large ({len(df):,} rows). Sampling to {self.max_samples:,}...")
        
        # Separate failures and successes
        if 'success' in df.columns:

            failures = df[~df['success']]
            successes = df[df['success']]
            
            n_failures = len(failures)
            n_successes = len(successes)
            
            # Keep all failures if possible
            if n_failures <= self.max_samples:
                n_sample_failures = n_failures
                n_sample_successes = min(n_successes, self.max_samples - n_failures)
            else:
                # Even failures need sampling
                n_sample_failures = int(self.max_samples * 0.7)  # 70% failures
                n_sample_successes = self.max_samples - n_sample_failures
            
            # Stratified sampling by anomaly type
            if 'anomaly_type' in df.columns and n_sample_failures < n_failures:
                failures_sampled = failures.groupby('anomaly_type', group_keys=False).apply(
                    lambda x: x.sample(n=min(len(x), max(1, int(n_sample_failures * len(x) / n_failures))), 
                                     random_state=42)
                )
            else:
                failures_sampled = failures.sample(n=min(n_sample_failures, n_failures), random_state=42)
            
            if n_sample_successes > 0:
                successes_sampled = successes.sample(n=min(n_sample_successes, n_successes), random_state=42)
                sampled_df = pd.concat([failures_sampled, successes_sampled], ignore_index=True)
            else:
                sampled_df = failures_sampled
            
            print(f"  Sampled: {len(failures_sampled):,} failures + {len(successes_sampled) if n_sample_successes > 0 else 0:,} successes")
        else:
            # Simple random sampling
            sampled_df = df.sample(n=self.max_samples, random_state=42)
            print(f"  Random sampling: {len(sampled_df):,} rows")
        
        return sampled_df.reset_index(drop=True)
    
    def prepare_features_for_clustering(
        self, 
        anomaly_feature_df: pd.DataFrame
    ) -> Tuple[np.ndarray, List[str]]:
        """
        Memory-efficient feature preparation.
        
        Optimizations:
        - Direct numpy array creation (no intermediate lists)
        - In-place operations
        - Memory-efficient dtype (float32)
        """
        print("Preparing features for clustering...")
        
        # Get available features
        available_temporal = [f for f in self.TEMPORAL_FEATURES if f in anomaly_feature_df.columns]
        available_spatial = [f for f in self.SPATIAL_FEATURES if f in anomaly_feature_df.columns]
        available_relations = [c for c in anomaly_feature_df.columns if c.startswith('r_')]
        
        print(f"  Temporal: {len(available_temporal)}, Spatial: {len(available_spatial)}, Relations: {len(available_relations)}")
        
        # Pre-calculate total features and allocate array once
        n_samples = len(anomaly_feature_df)
        n_features = len(available_temporal) + len(available_spatial) + len(available_relations)
        
        # Allocate feature matrix with efficient dtype
        feature_matrix = np.empty((n_samples, n_features), dtype=self.dtype)
        
        # Fill matrix column by column (memory efficient)
        col_idx = 0
        feature_names = []
        
        # Temporal features (weighted)
        for feat in available_temporal:
            feature_matrix[:, col_idx] = anomaly_feature_df[feat].values * self.temporal_weight
            feature_names.append(feat)
            col_idx += 1
        
        # Spatial features (weighted)
        for feat in available_spatial:
            feature_matrix[:, col_idx] = anomaly_feature_df[feat].values * self.spatial_weight
            feature_names.append(feat)
            col_idx += 1
        
        # Relation features (unweighted, convert to float32)
        for feat in available_relations:
            feature_matrix[:, col_idx] = anomaly_feature_df[feat].values.astype(self.dtype)
            feature_names.append(feat)
            col_idx += 1
        
        print(f"  Feature matrix: {feature_matrix.shape} ({feature_matrix.nbytes / 1024 / 1024:.1f} MB)")
        
        return feature_matrix, feature_names
    
    def mine_patterns(
        self, 
        anomaly_feature_df: pd.DataFrame, 
        eps: float = 0.35, 
        min_samples: int = 3,
        context_filter: Optional[str] = None
    ) -> Tuple[Optional[pd.DataFrame], pd.DataFrame]:
        """
        Memory-efficient pattern mining.
        
        Key optimizations:
        - Sample large datasets before clustering
        - Use optimized dtypes
        - Minimal copying
        """
        print("=" * 80)
        print("MINING PATTERNS (MEMORY-EFFICIENT MODE)")
        print("=" * 80)
        
        # Filter by context
        if context_filter:
            if context_filter not in anomaly_feature_df.columns:
                print(f"\nWarning: Context '{context_filter}' not found")
                return None, anomaly_feature_df
            
            print(f"\nFiltering to context: {context_filter}")
            df_to_cluster = anomaly_feature_df[anomaly_feature_df[context_filter] == 1].copy()
            print(f"  Anomalies in context: {len(df_to_cluster):,}")
        else:
            df_to_cluster = anomaly_feature_df
        
        # Early exit
        if len(df_to_cluster) < min_samples:
            print(f"\nInsufficient samples ({len(df_to_cluster)} < {min_samples})")
            return None, anomaly_feature_df
        
        # CRITICAL: Sample if too large (saves 70-90% memory/CPU)
        df_to_cluster = self._sample_data(df_to_cluster, context_filter)
        
        # Optimize dtypes (saves ~50% memory)
        df_to_cluster = self._optimize_dtypes(df_to_cluster)
        
        # Prepare features
        feature_matrix, feature_names = self.prepare_features_for_clustering(df_to_cluster)
        
        if feature_matrix.shape[1] == 0:
            print("\nNo features available")
            return None, anomaly_feature_df
        
        # DBSCAN clustering (use single thread to limit CPU)
        print(f"\nApplying DBSCAN (eps={eps}, min_samples={min_samples})...")
        dbscan = DBSCAN(
            eps=eps, 
            min_samples=min_samples, 
            metric='euclidean',
            n_jobs=1,  # Single thread to limit CPU usage
            algorithm='auto'  # Let sklearn choose best
        )
        cluster_labels = dbscan.fit_predict(feature_matrix)
        
        # Clean up large feature matrix
        del feature_matrix
        gc.collect()
        
        # Add cluster labels
        df_to_cluster['cluster'] = cluster_labels.astype('int16')  # Use int16 instead of int64
        
        # Update original dataframe only for sampled rows
        if 'cluster' not in anomaly_feature_df.columns:
            anomaly_feature_df['cluster'] = -1
        anomaly_feature_df.loc[df_to_cluster.index, 'cluster'] = cluster_labels
        
        # Analyze clusters
        unique_labels, counts = np.unique(cluster_labels, return_counts=True)
        n_clusters = np.sum(unique_labels >= 0)
        n_noise = counts[unique_labels == -1][0] if -1 in unique_labels else 0
        
        print(f"\n  Clusters: {n_clusters}, Noise: {n_noise:,}, Clustered: {len(cluster_labels) - n_noise:,}")
        
        if n_clusters == 0:
            return None, anomaly_feature_df
        
        # Extract patterns
        patterns = self._extract_patterns_from_clusters(
            df_to_cluster, feature_names, cluster_labels, context_filter
        )
        
        # Clean up
        del df_to_cluster
        gc.collect()
        
        return patterns, anomaly_feature_df
    
    def _extract_patterns_from_clusters(
        self, 
        df_clustered: pd.DataFrame, 
        feature_names: List[str],
        cluster_labels: np.ndarray, 
        context_filter: Optional[str]
    ) -> pd.DataFrame:
        """Extract patterns with minimal memory overhead."""
        # Filter noise
        valid_mask = cluster_labels >= 0
        if not valid_mask.any():
            return pd.DataFrame()
        
        df_valid = df_clustered[valid_mask].copy()
        df_valid['cluster'] = cluster_labels[valid_mask]
        
        print(f"\nExtracting patterns from {df_valid['cluster'].nunique()} clusters...")
        
        # Use groupby for vectorized aggregations
        patterns = []
        total_samples = len(df_clustered)
        
        # Group by cluster (efficient)
        grouped = df_valid.groupby('cluster', sort=False)
        
        for cluster_id, cluster_data in grouped:
            if len(cluster_data) < 2:
                continue
            
            pattern = {
                'cluster_id': int(cluster_id),
                'context': context_filter or 'global',
                'size': len(cluster_data),
                'support': len(cluster_data) / total_samples
            }
            
            # Anomaly type (vectorized)
            if 'anomaly_type' in cluster_data.columns:
                anom_counts = cluster_data['anomaly_type'].value_counts()
                pattern['dominant_anomaly_type'] = anom_counts.index[0]
                pattern['anomaly_type_purity'] = float(anom_counts.iloc[0] / len(cluster_data))
            
            # Failure metrics (vectorized)
            if 'success' in cluster_data.columns:
                n_failures = int((~cluster_data['success']).sum())
                pattern['failure_count'] = n_failures
                pattern['failure_rate'] = float(n_failures / len(cluster_data))
            else:
                pattern['failure_count'] = 0
                pattern['failure_rate'] = 0.0
            
            # Centroids (compute only top features to save memory)
            available_features = [f for f in feature_names[:10] if f in cluster_data.columns]  # Limit features
            if available_features:
                centroids = cluster_data[available_features].mean()
                for feat, val in centroids.items():
                    pattern[f'centroid_{feat}'] = float(val)
            
            # Dominant relations (only store count to save memory)
            relation_cols = [c for c in cluster_data.columns if c.startswith('r_')]
            if relation_cols:
                dominant_count = (cluster_data[relation_cols].mean() > 0.5).sum()
                pattern['num_dominant_relations'] = int(dominant_count)
            
            # Temporal score
            temporal_feats = [f for f in self.TEMPORAL_FEATURES if f in cluster_data.columns]
            if temporal_feats:
                pattern['avg_temporal_score'] = float(cluster_data[temporal_feats].mean().mean())
            
            patterns.append(pattern)
        
        if not patterns:
            return pd.DataFrame()
        
        patterns_df = pd.DataFrame(patterns)
        
        # Sort by failure rate
        if 'failure_rate' in patterns_df.columns:
            patterns_df.sort_values('failure_rate', ascending=False, inplace=True)
        
        return patterns_df
    
    def mine_patterns_per_context(
        self, 
        anomaly_feature_df: pd.DataFrame, 
        contexts_to_mine: List[str],
        eps: float = 0.35, 
        min_samples: int = 3
    ) -> pd.DataFrame:
        """Mine patterns per context with memory management."""
        print("=" * 80)
        print("MINING PATTERNS PER CONTEXT")
        print("=" * 80)
        
        all_patterns = []
        
        for i, context in enumerate(contexts_to_mine, 1):
            print(f"\n[{i}/{len(contexts_to_mine)}] Context: {context}")
            
            patterns, _ = self.mine_patterns(
                anomaly_feature_df, 
                eps=eps, 
                min_samples=min_samples,
                context_filter=context
            )
            
            if patterns is not None and len(patterns) > 0:
                all_patterns.append(patterns)
                print(f"  ✓ Found {len(patterns)} patterns")
            else:
                print(f"  ✗ No patterns found")
            
            # Force garbage collection after each context
            gc.collect()
        
        if all_patterns:
            return pd.concat(all_patterns, ignore_index=True)
        else:
            return pd.DataFrame()
    
    def visualize_clusters_lite(
        self, 
        anomaly_feature_df: pd.DataFrame, 
        feature_matrix: np.ndarray,
        cluster_labels: np.ndarray, 
        save_path: Optional[str] = None,
        sample_size: int = 10000  # Limit visualization points
    ) -> None:
        """
        Lightweight cluster visualization.
        
        Optimizations:
        - IncrementalPCA (memory efficient)
        - Sample points if too many
        - Single plot instead of two
        """
        print("\nVisualizing clusters (lightweight mode)...")
        
        # Sample if too many points
        if len(feature_matrix) > sample_size:
            print(f"  Sampling {sample_size:,} points for visualization...")
            indices = np.random.choice(len(feature_matrix), sample_size, replace=False)
            feature_matrix = feature_matrix[indices]
            cluster_labels = cluster_labels[indices]
            anomaly_feature_df = anomaly_feature_df.iloc[indices]
        
        # Use IncrementalPCA (memory efficient)
        pca = IncrementalPCA(n_components=2, batch_size=1000)
        features_2d = pca.fit_transform(feature_matrix)
        
        # Single plot (saves memory)
        fig, ax = plt.subplots(1, 1, figsize=(10, 8))
        
        # Color by cluster, size by failure
        colors = cluster_labels
        if 'success' in anomaly_feature_df.columns:
            sizes = np.where(anomaly_feature_df['success'].values, 20, 60)  # Larger for failures
        else:
            sizes = 40
        
        scatter = ax.scatter(
            features_2d[:, 0], 
            features_2d[:, 1],
            c=colors,
            s=sizes,
            cmap='tab10',
            alpha=0.5,
            edgecolors='none'
        )
        
        ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.1%})', fontsize=11)
        ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.1%})', fontsize=11)
        ax.set_title('Anomaly Clusters (PCA, Large=Failure)', fontsize=13, fontweight='bold')
        ax.grid(True, alpha=0.3)
        plt.colorbar(scatter, ax=ax, label='Cluster ID')
        
        plt.tight_layout()
        
        if save_path:
            save_figure(save_path)
        plt.close()
        
        # Clean up
        del features_2d, feature_matrix
        gc.collect()
    
    def analyze_pattern_quality(self, patterns_df: Optional[pd.DataFrame]) -> None:
        """Lightweight pattern quality analysis."""
        if patterns_df is None or len(patterns_df) == 0:
            print("No patterns to analyze")
            return
        
        print("\n" + "=" * 80)
        print("PATTERN QUALITY ANALYSIS")
        print("=" * 80)
        
        print(f"\nTotal patterns: {len(patterns_df)}")
        print(f"Avg cluster size: {patterns_df['size'].mean():.1f}")
        
        if 'failure_rate' in patterns_df.columns:
            print(f"Avg failure rate: {patterns_df['failure_rate'].mean():.1%}")
            high_risk = (patterns_df['failure_rate'] > 0.7).sum()
            print(f"High-risk patterns (>70%): {high_risk}")

