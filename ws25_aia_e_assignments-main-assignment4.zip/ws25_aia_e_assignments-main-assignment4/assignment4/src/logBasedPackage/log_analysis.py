from setup.config import *

class LogAnalyzer:
    def __init__(self, scenarios):
        """
        Initialize with the list of scenario objects.
        It builds a flat 'runs_df' which is used for all subsequent analysis.
        """
        self.runs_df = self._build_runs_dataframe(scenarios)
        self.runs_anomalies = self._build_runs_anomalies_dataframe(scenarios)
        self.summary_df = self._build_summary_dataframe()

    @staticmethod
    def _build_runs_dataframe(scenarios):
        """Creates a flat DataFrame where each row represents a single run."""
        data = []
        for scenario in scenarios:
            for run in scenario.runs:
                data.append({
                    "scenario_id": scenario.scenario_id,
                    "run_id": run.run_id,
                    "success": run.success,
                    "behavior_outcome": "Success" if run.success else "Failure",
                    "log_classification": run.classification
                })
                print(f"Processed Scenario: {scenario.scenario_id}, Run: {run.run_id}, Success: {run.success}, Classification: {run.classification}")
        return pd.DataFrame(data)

    @staticmethod
    def _build_runs_anomalies_dataframe(scenarios):
        data = []
        for scenario in scenarios:
            for run in scenario.runs:
                _ = run.anomaly_timestamps_and_poses
                if run.anomaly_timestamps_and_poses is not None:
                    for anomaly in run.anomaly_timestamps_and_poses:
                        if anomaly.get("anomaly_type") == "Goal reached":
                            continue
                        row = {
                            "scenario_id": scenario.scenario_id,
                            "run_id": run.run_id,
                            "anomaly_type": anomaly.get("anomaly_type"),
                            "timestamp": anomaly.get("timestamp"),
                            "gt_pose_x": anomaly.get("gt_pose_x"),
                            "gt_pose_y": anomaly.get("gt_pose_y"),
                            "gt_orientation_yaw": anomaly.get("gt_orientation_yaw")
                        }
                        data.append(row)
        return pd.DataFrame(data)

    def _build_summary_dataframe(self):
        """Aggregates run data into scenario-level success/failure counts."""
        summary = self.runs_df.groupby("scenario_id")["success"].agg(
            success_count=lambda x: (x == True).sum(),
            failure_count=lambda x: (x == False).sum()
        ).reset_index()
        return summary

    def plot_scenario_stacked_bar(self):
        """Plots success/failure proportion for every scenario."""
        x = self.summary_df['scenario_id']
        s_count = self.summary_df['success_count']
        f_count = self.summary_df['failure_count']

        fig, ax = plt.subplots(figsize=(10, 6))
        ax.bar(x, s_count, label='Success', color='seagreen')
        ax.bar(x, f_count, bottom=s_count, label='Failure', color='indianred')

        ax.set_xlabel('Scenario ID')
        ax.set_ylabel('Number of Runs')
        ax.set_title('Success/Failure Proportion per Scenario')
        ax.legend(loc='center left', bbox_to_anchor=(1, 0.5))
        plt.xticks([]) # Hide scenario IDs for clarity if there are many
        
        max_runs = int((s_count + f_count).max())
        ax.set_yticks(np.arange(0, max_runs + 1, 1))
        plt.tight_layout()
        save_figure("LOG_BASED_Success-Failure Proportion per Scenario.png")
        plt.close()

    def plot_totals_bar(self):
        """Plots the global totals for runs, successes, and failures."""
        total_s = self.summary_df['success_count'].sum()
        total_f = self.summary_df['failure_count'].sum()
        
        totals_df = pd.DataFrame({
            'Category': ['Total Runs', 'Success', 'Failure'],
            'Count': [total_s + total_f, total_s, total_f]
        })

        plt.figure(figsize=(6, 5))
        sns.set_style("whitegrid")
        bar = sns.barplot(data=totals_df, x='Category', y='Count', 
                          palette=['#4c72b0', 'seagreen', 'indianred'])

        for p in bar.patches:
            bar.annotate(f'{int(p.get_height())}', 
                         (p.get_x() + p.get_width() / 2, p.get_height()),
                         ha='center', va='bottom', fontweight='bold')

        plt.title('Total Mission Outcomes')
        plt.tight_layout()
        save_figure("LOG_BASED_Total Mission Outcomes.png")
        plt.close()

    def plot_outcome_correlation(self):
        """
        Plots a heatmap correlating Behavioral Ground Truth (from CSV)
        with Semantic Classification (from Logs).
        """
        # Create cross-tabulation
        ct = pd.crosstab(self.runs_df['log_classification'], 
                         self.runs_df['behavior_outcome'])

        plt.figure(figsize=(10, 6))
        sns.heatmap(ct, annot=True, fmt='d', cmap='YlGnBu', 
                    cbar_kws={'label': 'Number of Runs'})
        
        plt.title('Correlation: Behavior Ground Truth vs. Log Semantic Failure')
        plt.ylabel('Semantic Classification (from Logs)')
        plt.xlabel('Ground Truth Outcome (from Behaviors CSV)')
        plt.tight_layout()
        save_figure("LOG_BASED_Correlation - Behavior Ground Truth vs Log Semantic Failure.png")
        plt.close()

