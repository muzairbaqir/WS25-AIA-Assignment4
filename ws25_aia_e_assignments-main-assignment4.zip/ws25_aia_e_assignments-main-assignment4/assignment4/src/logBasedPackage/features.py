from setup.config import *

class EnhancedRawFeatureComputer:
    """
    Computes top 10 temporal-aware features from raw pose and sensor data
    Emphasizes temporal duration as key differentiator between success/failure
    """
    
    def __init__(self, map_details, scenarios):
        """
        Parameters:
        - map_details: Loaded maps_details.json
        - scenarios: List of ScenarioData objects for goal extraction
        """
        self.map_details = map_details
        self.scenarios = scenarios
        self.map_lookup = {map_info['map']: map_info for map_info in map_details['maps']}
        
        # Build scenario lookup for goals
        self.scenario_goals = self._extract_scenario_goals()
    
    def _extract_scenario_goals(self):
        """Extract goal positions from scenarios"""
        goals = {}
        for scenario in self.scenarios:
            if scenario.parameters and 'goal_poses' in scenario.parameters:
                goal_poses = scenario.parameters['goal_poses']
                if goal_poses:
                    goal = goal_poses[0]['position']
                    goals[scenario.scenario_id] = (goal.get('x', 0), goal.get('y', 0))
        return goals
    
    # ========================================================================
    # BASIC FEATURES
    # ========================================================================
    
    def compute_distance_to_goal(self, row):
        """Compute Euclidean distance to goal"""
        scenario_id = row.get('scenario_id')
        if scenario_id not in self.scenario_goals:
            return np.nan
        
        goal_x, goal_y = self.scenario_goals[scenario_id]
        pos_x = row.get('position_x_gt', 0)
        pos_y = row.get('position_y_gt', 0)
        
        return np.sqrt((pos_x - goal_x)**2 + (pos_y - goal_y)**2)
    
    def compute_distance_to_walls(self, row):
        """Compute minimum distance to walls using map geometry"""
        map_name = row.get('map_name')
        if map_name not in self.map_lookup:
            return np.nan
        
        pos_x = row.get('position_x_gt', 0)
        pos_y = row.get('position_y_gt', 0)
        point = Point(pos_x, pos_y)
        
        map_info = self.map_lookup[map_name]
        min_wall_dist = np.inf
        
        for space in map_info['spaces']:
            corners = space['corners']
            polygon = Polygon(corners)
            dist = point.distance(polygon.boundary)
            min_wall_dist = min(min_wall_dist, dist)
        
        return min_wall_dist if np.isfinite(min_wall_dist) else np.nan
    
    def compute_velocities(self, df):
        """Compute velocity by differentiating positions"""
        df = df.sort_values(['scenario_id', 'run_id', 'timestamp'])
        
        df['delta_x'] = df.groupby(['scenario_id', 'run_id'])['position_x_gt'].diff()
        df['delta_y'] = df.groupby(['scenario_id', 'run_id'])['position_y_gt'].diff()
        df['delta_t'] = df.groupby(['scenario_id', 'run_id'])['timestamp'].diff()
        
        df['velocity_x'] = df['delta_x'] / df['delta_t']
        df['velocity_y'] = df['delta_y'] / df['delta_t']
        df['velocity_magnitude_mps'] = np.sqrt(df['velocity_x']**2 + df['velocity_y']**2)
        df['velocity_magnitude_mps'] = df['velocity_magnitude_mps'].fillna(0)
        
        return df
    
    def compute_angular_velocity(self, df):
        """Compute angular velocity from yaw differences"""
        df = df.sort_values(['scenario_id', 'run_id', 'timestamp'])
        
        df['delta_yaw'] = df.groupby(['scenario_id', 'run_id'])['orientation_yaw_gt'].diff()
        df['delta_t'] = df.groupby(['scenario_id', 'run_id'])['timestamp'].diff()
        
        # Handle angle wrapping
        df['delta_yaw'] = np.arctan2(np.sin(df['delta_yaw']), np.cos(df['delta_yaw']))
        df['angular_velocity_radps'] = df['delta_yaw'] / df['delta_t']
        df['angular_velocity_radps'] = df['angular_velocity_radps'].fillna(0)
        
        return df
    
    # ========================================================================
    # TEMPORAL-AWARE FEATURES
    # ========================================================================
    
    def compute_f1_time_since_progress(self, df):
        """
        F1: Time since robot last made meaningful progress toward goal (>0.1m closer)
        KEY TEMPORAL DIFFERENTIATOR
        """
        print("   Computing F1: time_since_progress...")
        df = df.sort_values(['scenario_id', 'run_id', 'timestamp'])
        
        # Compute goal distance change
        df['goal_dist_change'] = df.groupby(['scenario_id', 'run_id'])['dist_to_goal_m'].diff()
        
        # Mark timesteps where meaningful progress was made (got >0.1m closer)
        df['made_progress'] = df['goal_dist_change'] < -0.1
        
        # Assign progress event ID
        df['progress_event_id'] = df.groupby(['scenario_id', 'run_id'])['made_progress'].cumsum()
        
        # Time since last progress event
        df['last_progress_time'] = df.groupby(['scenario_id', 'run_id', 'progress_event_id'])['timestamp'].transform('first')
        df['time_since_progress_s'] = df['timestamp'] - df['last_progress_time']
        
        # Fill initial NaN
        df['time_since_progress_s'] = df['time_since_progress_s'].fillna(0)
        
        return df
    
    def compute_f2_cumulative_stopped_time(self, df):
        """
        F2: Total time spent stopped (velocity < 0.01 m/s) in 30-second sliding window
        QUANTIFIES WASTED TIME
        """
        print("   Computing F2: cumulative_stopped_time...")
        df = df.sort_values(['scenario_id', 'run_id', 'timestamp'])
        
        # Mark stopped timesteps
        df['is_stopped'] = (df['velocity_magnitude_mps'] < 0.01).astype(int)
        
        # Compute time deltas
        df['time_delta'] = df.groupby(['scenario_id', 'run_id'])['timestamp'].diff().fillna(0)
        
        # Time spent stopped at each timestep
        df['stopped_time_delta'] = df['is_stopped'] * df['time_delta']
        
        # Rolling sum over 30-second window
        df['cumulative_stopped_time_30s'] = (
            df.groupby(['scenario_id', 'run_id'])['stopped_time_delta']
            .rolling(window=100, min_periods=1)  # Approximate 30s window
            .sum()
            .reset_index(level=[0, 1], drop=True)
        )
        
        return df
    
    def compute_f3_time_in_current_room(self, df):
        """
        F3: Duration robot has remained in current spatial context (room)
        SPATIAL-TEMPORAL CONTEXT
        """
        print("   Computing F3: time_in_current_room...")
        df = df.sort_values(['scenario_id', 'run_id', 'timestamp'])
        
        # Detect room changes
        df['room_changed'] = (
            df.groupby(['scenario_id', 'run_id'])['spatial_context'].shift() != df['spatial_context']
        ).fillna(True)
        
        # Room stay ID
        df['room_stay_id'] = df.groupby(['scenario_id', 'run_id'])['room_changed'].cumsum()
        
        # Time in current room
        df['room_entry_time'] = df.groupby(['scenario_id', 'run_id', 'room_stay_id'])['timestamp'].transform('first')
        df['time_in_current_room_s'] = df['timestamp'] - df['room_entry_time']
        
        return df
    
    def compute_f4_heading_error(self, df):
        """
        F4: Angular difference between robot heading and direction to goal
        ORIENTATION QUALITY
        """
        print("   Computing F4: heading_error...")
        
        # Get goal positions
        df['goal_x'] = df['scenario_id'].map(lambda sid: self.scenario_goals.get(sid, (0, 0))[0])
        df['goal_y'] = df['scenario_id'].map(lambda sid: self.scenario_goals.get(sid, (0, 0))[1])
        
        # Compute direction to goal
        df['direction_to_goal'] = np.arctan2(
            df['goal_y'] - df['position_y_gt'],
            df['goal_x'] - df['position_x_gt']
        )
        
        # Heading error (wrap to [-π, π])
        df['heading_error_raw'] = df['direction_to_goal'] - df['orientation_yaw_gt']
        df['heading_error_rad'] = np.arctan2(
            np.sin(df['heading_error_raw']),
            np.cos(df['heading_error_raw'])
        )
        df['heading_error_deg'] = np.abs(np.degrees(df['heading_error_rad']))
        
        return df
    
    def compute_f5_path_efficiency(self, df):
        """
        F5: Ratio of progress toward goal vs distance traveled (10-second window)
        PATH QUALITY
        """
        print("   Computing F5: path_efficiency...")
        df = df.sort_values(['scenario_id', 'run_id', 'timestamp'])
        
        # Distance traveled (path length)
        df['dist_traveled'] = np.sqrt(df['delta_x']**2 + df['delta_y']**2).fillna(0)
        
        # Goal distance change (negative = progress)
        df['goal_progress'] = -df.groupby(['scenario_id', 'run_id'])['dist_to_goal_m'].diff().fillna(0)
        
        # Rolling sums over ~10 seconds (approx 30 samples)
        window_size = 30
        
        df['total_dist_10s'] = (
            df.groupby(['scenario_id', 'run_id'])['dist_traveled']
            .rolling(window=window_size, min_periods=1)
            .sum()
            .reset_index(level=[0, 1], drop=True)
        )
        
        df['total_progress_10s'] = (
            df.groupby(['scenario_id', 'run_id'])['goal_progress']
            .rolling(window=window_size, min_periods=1)
            .sum()
            .reset_index(level=[0, 1], drop=True)
        )
        
        # Path efficiency (clip to [0, 1])
        df['path_efficiency'] = df['total_progress_10s'] / (df['total_dist_10s'] + 1e-6)
        df['path_efficiency'] = df['path_efficiency'].clip(0, 1)
        
        return df
    
    def compute_f6_goal_distance_change_rate(self, df):
        """
        F6: Rate of change of distance to goal (m/s) - already computed as progress_rate
        DIRECT PROGRESS METRIC
        """
        print("   Computing F6: goal_distance_change_rate...")
        df = df.sort_values(['scenario_id', 'run_id', 'timestamp'])
        
        df['delta_goal_dist'] = df.groupby(['scenario_id', 'run_id'])['dist_to_goal_m'].diff()
        df['delta_t'] = df.groupby(['scenario_id', 'run_id'])['timestamp'].diff()
        
        # Progress rate (negative means approaching)
        df['progress_rate_mps'] = -df['delta_goal_dist'] / df['delta_t']
        df['progress_rate_mps'] = df['progress_rate_mps'].fillna(0).clip(-2, 2)
        
        return df
    
    def compute_f7_position_variance_10s(self, df):
        """
        F7: Variance of x,y position in last 10 seconds
        STUCK DETECTOR
        """
        print("   Computing F7: position_variance_10s...")
        df = df.sort_values(['scenario_id', 'run_id', 'timestamp'])
        
        window_size = 30  # ~10 seconds
        
        # Rolling variance of position
        df['pos_x_variance'] = (
            df.groupby(['scenario_id', 'run_id'])['position_x_gt']
            .rolling(window=window_size, min_periods=1)
            .var()
            .reset_index(level=[0, 1], drop=True)
        )
        
        df['pos_y_variance'] = (
            df.groupby(['scenario_id', 'run_id'])['position_y_gt']
            .rolling(window=window_size, min_periods=1)
            .var()
            .reset_index(level=[0, 1], drop=True)
        )
        
        # Total position variance
        df['position_variance_10s'] = df['pos_x_variance'] + df['pos_y_variance']
        df['position_variance_10s'] = df['position_variance_10s'].fillna(0)
        
        return df
    
    def compute_f8_recovery_attempt_count(self, df):
        """
        F8: Number of significant direction changes (yaw delta > 45°) in last 20 seconds
        OSCILLATION INDICATOR
        """
        print("   Computing F8: recovery_attempt_count...")
        df = df.sort_values(['scenario_id', 'run_id', 'timestamp'])
        
        # Detect significant direction changes
        df['abs_delta_yaw'] = np.abs(df['delta_yaw'])
        df['significant_turn'] = (df['abs_delta_yaw'] > np.radians(45)).astype(int)
        
        # Count in rolling 20-second window (~60 samples)
        window_size = 60
        
        df['recovery_attempt_count_20s'] = (
            df.groupby(['scenario_id', 'run_id'])['significant_turn']
            .rolling(window=window_size, min_periods=1)
            .sum()
            .reset_index(level=[0, 1], drop=True)
        )
        
        return df
    
    def compute_f9_wall_following_duration(self, df):
        """
        F9: Time spent with tight wall clearance (<0.5m) while moving forward
        WALL FOLLOWING DETECTOR
        """
        print("   Computing F9: wall_following_duration...")
        df = df.sort_values(['scenario_id', 'run_id', 'timestamp'])
        
        # Mark wall-following states
        df['is_wall_following'] = (
            (df['wall_clearance_m'] < 0.5) & 
            (df['velocity_magnitude_mps'] > 0.05)
        ).astype(int)
        
        # Detect state changes
        df['wall_follow_changed'] = (
            df.groupby(['scenario_id', 'run_id'])['is_wall_following'].shift() != df['is_wall_following']
        ).fillna(True)
        
        # Wall-following episode ID
        df['wall_follow_episode_id'] = df.groupby(['scenario_id', 'run_id'])['wall_follow_changed'].cumsum()
        
        # Duration in current episode
        df['wall_follow_start_time'] = df.groupby(
            ['scenario_id', 'run_id', 'wall_follow_episode_id']
        )['timestamp'].transform('first')
        
        df['wall_following_duration_s'] = df['timestamp'] - df['wall_follow_start_time']
        
        # Zero out when not wall-following
        df.loc[df['is_wall_following'] == 0, 'wall_following_duration_s'] = 0
        
        return df
    
    def compute_f10_backward_motion_ratio(self, df):
        """
        F10: Ratio of time spent moving away from goal vs toward goal in last 30s
        RETREAT INDICATOR
        """
        print("   Computing F10: backward_motion_ratio...")
        df = df.sort_values(['scenario_id', 'run_id', 'timestamp'])
        
        # Mark forward/backward motion
        df['is_moving_away'] = (df['progress_rate_mps'] < -0.05).astype(int)  # Moving away from goal
        df['is_moving_toward'] = (df['progress_rate_mps'] > 0.05).astype(int)  # Moving toward goal
        
        # Time spent in each state
        df['time_delta'] = df.groupby(['scenario_id', 'run_id'])['timestamp'].diff().fillna(0)
        df['time_moving_away'] = df['is_moving_away'] * df['time_delta']
        df['time_moving_toward'] = df['is_moving_toward'] * df['time_delta']
        
        # Rolling sums over 30s window
        window_size = 100
        
        df['total_time_away_30s'] = (
            df.groupby(['scenario_id', 'run_id'])['time_moving_away']
            .rolling(window=window_size, min_periods=1)
            .sum()
            .reset_index(level=[0, 1], drop=True)
        )
        
        df['total_time_toward_30s'] = (
            df.groupby(['scenario_id', 'run_id'])['time_moving_toward']
            .rolling(window=window_size, min_periods=1)
            .sum()
            .reset_index(level=[0, 1], drop=True)
        )
        
        # Backward motion ratio
        df['backward_motion_ratio_30s'] = df['total_time_away_30s'] / (
            df['total_time_away_30s'] + df['total_time_toward_30s'] + 1e-6
        )
        df['backward_motion_ratio_30s'] = df['backward_motion_ratio_30s'].clip(0, 1)
        
        return df
    
    # ========================================================================
    # MAIN COMPUTATION PIPELINE
    # ========================================================================
    
    def compute_all_features(self, df):
        """
        Compute all 10 temporal-aware features from raw data
        
        Returns: DataFrame with computed feature columns
        """
        print("=" * 80)
        print("COMPUTING TOP 10 TEMPORAL-AWARE FEATURES FROM RAW DATA")
        print("=" * 80)
        
        df = df.copy()
        
        # STEP 1: Basic features (prerequisites)
        print("\n1. Computing basic features...")
        print("-" * 80)
        
        print("   - Velocities...")
        df = self.compute_velocities(df)
        df = self.compute_angular_velocity(df)
        
        print("   - Distance to goal...")
        df['dist_to_goal_m'] = df.apply(self.compute_distance_to_goal, axis=1)
        
        print("   - Distance to walls (sampled)...")
        # Sample every 10th row for performance
        wall_dist_sample = df.iloc[::10].apply(self.compute_distance_to_walls, axis=1)
        df['wall_clearance_m'] = np.nan
        df.loc[wall_dist_sample.index, 'wall_clearance_m'] = wall_dist_sample
        df['wall_clearance_m'] = df.groupby(['scenario_id', 'run_id'])['wall_clearance_m'].fillna(method='ffill').fillna(method='bfill')
        
        # STEP 2: Compute top 10 temporal features
        print("\n2. Computing TOP 10 temporal-aware features...")
        print("-" * 80)
        
        df = self.compute_f1_time_since_progress(df)
        df = self.compute_f2_cumulative_stopped_time(df)
        df = self.compute_f3_time_in_current_room(df)
        df = self.compute_f4_heading_error(df)
        df = self.compute_f5_path_efficiency(df)
        df = self.compute_f6_goal_distance_change_rate(df)
        df = self.compute_f7_position_variance_10s(df)
        df = self.compute_f8_recovery_attempt_count(df)
        df = self.compute_f9_wall_following_duration(df)
        df = self.compute_f10_backward_motion_ratio(df)
        
        # STEP 3: Add placeholders for unavailable features (will be inluded in the next revision)

        df['nearest_obstacle_dist_m'] = np.nan
        df['lidar_noise_std'] = 0.0
        df['corridor_width_m'] = np.nan
        df['door_width_m'] = np.nan
        
        # STEP 4: Add state-based temporal feature (for compatibility)
        df['state'] = 'moving'
        df.loc[df['velocity_magnitude_mps'] < 0.01, 'state'] = 'stopped'
        df.loc[(df['velocity_magnitude_mps'] >= 0.01) & 
               (df['velocity_magnitude_mps'] < 0.05), 'state'] = 'very_slow'
        
        df['state_changed'] = df.groupby(['scenario_id', 'run_id'])['state'].shift() != df['state']
        df['state_changed'] = df['state_changed'].fillna(True)
        df['state_id'] = df.groupby(['scenario_id', 'run_id'])['state_changed'].cumsum()
        
        df['state_start_time'] = df.groupby(['scenario_id', 'run_id', 'state_id'])['timestamp'].transform('first')
        df['time_since_state_change_s'] = df['timestamp'] - df['state_start_time']
        
        # STEP 5: Add AMCL localization uncertainty
        df['amcl_cov_trace'] = 0.0  # Placeholder (will be inluded in the next revision)
        
        print("\n" + "=" * 80)
        print("FEATURE COMPUTATION COMPLETE!")
        print("=" * 80)
        
        # Summary
        top_10_features = [
            'time_since_progress_s',
            'cumulative_stopped_time_30s',
            'time_in_current_room_s',
            'heading_error_deg',
            'path_efficiency',
            'progress_rate_mps',
            'position_variance_10s',
            'recovery_attempt_count_20s',
            'wall_following_duration_s',
            'backward_motion_ratio_30s'
        ]
                
        return df