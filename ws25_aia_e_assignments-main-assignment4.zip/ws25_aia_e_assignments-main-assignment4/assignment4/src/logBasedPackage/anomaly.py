from setup.config import *

# ============================================================================
# TEMPORAL FEATURE DEFINITIONS (Vectorized)
# ============================================================================

class TemporalAwareFeatureDefinitions:
    """
    Defines computable functions F 
    Emphasizes temporal duration as key differentiator between success/failure
    """
    @staticmethod
    def compute_all_features_df(df: pd.DataFrame) -> pd.DataFrame:
        features = pd.DataFrame(index=df.index)
        features['f_distance_to_goal'] = df.get('dist_to_goal_m', np.nan)
        features['f_distance_to_closest_wall'] = df.get('wall_clearance_m', np.nan)
        features['f_distance_to_obstacle'] = df.get('nearest_obstacle_dist_m', np.nan)
        features['f_velocity_magnitude'] = df.get('velocity_magnitude_mps', 0.0)
        features['f_angular_velocity'] = df.get('angular_velocity_radps', 0.0).abs()
        features['f_time_in_current_state'] = df.get('time_since_state_change_s', 0.0)
        features['f_progress_rate'] = df.get('progress_rate_mps', 0.0)
        features['f_localization_uncertainty'] = df.get('amcl_cov_trace', 0.0)
        features['f_lidar_noise_level'] = df.get('lidar_noise_std', 0.0)
        features['f_corridor_width'] = df.get('corridor_width_m', np.nan)
        features['f_door_width'] = df.get('door_width_m', np.nan)
        return features

# ============================================================================
# TEMPORAL ATOMIC RELATIONS (Vectorized)
# ============================================================================

class TemporalAtomicRelations:
    def __init__(self):
        self.WALL_DANGER_THRESHOLD = 0.25
        self.WALL_TIGHT_THRESHOLD = 0.40
        self.OBSTACLE_CLOSE_THRESHOLD = 0.40
        self.OBSTACLE_NEAR_THRESHOLD = 0.80
        self.GOAL_NEAR_THRESHOLD = 0.80
        self.DOOR_TIGHT_THRESHOLD = 0.40
        self.STOPPED_THRESHOLD = 0.01
        self.VERY_SLOW_THRESHOLD = 0.05
        self.HIGH_ANGULAR_VEL = 0.5
        self.QUICK_RECOVERY_TIME = 2.0
        self.SHORT_DURATION = 5.0
        self.MODERATE_DURATION = 10.0
        self.LONG_DURATION = 20.0
        self.CRITICAL_DURATION = 30.0
        self.NO_PROGRESS_THRESHOLD = 0.01
        self.MINIMAL_PROGRESS_THRESHOLD = 0.05
        self.POOR_LOCALIZATION = 0.5
        self.HIGH_LIDAR_NOISE = 0.1

    def compute_all_relations_df(self, features: pd.DataFrame) -> pd.DataFrame:
        f = features
        r = pd.DataFrame(index=f.index)
        # Vectorized boolean relations
        r['r_dangerously_close_to_wall'] = f['f_distance_to_closest_wall'] < self.WALL_DANGER_THRESHOLD
        r['r_tight_wall_clearance'] = f['f_distance_to_closest_wall'] < self.WALL_TIGHT_THRESHOLD
        r['r_obstacle_very_close'] = f['f_distance_to_obstacle'] < self.OBSTACLE_CLOSE_THRESHOLD
        r['r_near_obstacle'] = f['f_distance_to_obstacle'] < self.OBSTACLE_NEAR_THRESHOLD
        r['r_near_goal'] = f['f_distance_to_goal'] < self.GOAL_NEAR_THRESHOLD
        r['r_door_too_narrow'] = f['f_door_width'] < self.DOOR_TIGHT_THRESHOLD
        r['r_stopped'] = f['f_velocity_magnitude'] < self.STOPPED_THRESHOLD
        r['r_very_slow'] = (f['f_velocity_magnitude'] < self.VERY_SLOW_THRESHOLD) & (f['f_velocity_magnitude'] >= self.STOPPED_THRESHOLD)
        r['r_turning'] = f['f_angular_velocity'] > self.HIGH_ANGULAR_VEL
        r['r_no_progress'] = f['f_progress_rate'] < self.NO_PROGRESS_THRESHOLD
        r['r_minimal_progress'] = (f['f_progress_rate'] < self.MINIMAL_PROGRESS_THRESHOLD) & (f['f_progress_rate'] >= self.NO_PROGRESS_THRESHOLD)
        time_in_state = f['f_time_in_current_state']
        r['r_quick_recovery'] = time_in_state < self.QUICK_RECOVERY_TIME
        r['r_short_duration_anomaly'] = (time_in_state >= self.QUICK_RECOVERY_TIME) & (time_in_state < self.SHORT_DURATION)
        r['r_moderate_duration_anomaly'] = (time_in_state >= self.SHORT_DURATION) & (time_in_state < self.MODERATE_DURATION)
        r['r_long_duration_anomaly'] = (time_in_state >= self.MODERATE_DURATION) & (time_in_state < self.LONG_DURATION)
        r['r_critical_duration_anomaly'] = time_in_state >= self.CRITICAL_DURATION
        r['r_stuck_stopped'] = r['r_stopped'] & (time_in_state > self.LONG_DURATION)
        r['r_stuck_slow_movement'] = r['r_very_slow'] & (time_in_state > self.MODERATE_DURATION)
        r['r_stuck_no_recovery'] = r['r_no_progress'] & (time_in_state > self.LONG_DURATION)
        r['r_oscillating_no_progress'] = r['r_turning'] & r['r_no_progress'] & (time_in_state > self.MODERATE_DURATION)
        r['r_prolonged_door_struggle'] = r['r_door_too_narrow'] & (r['r_stopped'] | r['r_very_slow']) & (time_in_state > self.MODERATE_DURATION)
        r['r_stuck_near_obstacle'] = r['r_near_obstacle'] & r['r_no_progress'] & (time_in_state > self.MODERATE_DURATION)
        r['r_stuck_along_wall'] = r['r_tight_wall_clearance'] & r['r_minimal_progress'] & (time_in_state > self.MODERATE_DURATION)
        r['r_poor_localization'] = f['f_localization_uncertainty'] > self.POOR_LOCALIZATION
        r['r_high_sensor_noise'] = f['f_lidar_noise_level'] > self.HIGH_LIDAR_NOISE
        r['r_successful_recovery'] = (r['r_near_obstacle'] | r['r_tight_wall_clearance']) & r['r_quick_recovery']
        r['r_recovering_with_progress'] = (~r['r_no_progress']) & (time_in_state < self.SHORT_DURATION)
        return r.astype(int)

# ============================================================================
# CONTEXT-AWARE FEATURE EXTRACTOR (Vectorized)
# ============================================================================

class ContextAwareFeatureExtractor:
    def __init__(self):
        self.feature_defs = TemporalAwareFeatureDefinitions()
        self.relation_computer = TemporalAtomicRelations()

    def extract_features_with_context(self, df_with_contexts: pd.DataFrame) -> pd.DataFrame:
        features = self.feature_defs.compute_all_features_df(df_with_contexts)
        relations = self.relation_computer.compute_all_relations_df(features)
        result = pd.concat([features, relations], axis=1)
        result['active_contexts'] = df_with_contexts.get('active_contexts', '')
        result['success'] = df_with_contexts.get('success', None)
        return result

    def compute_temporal_statistics_per_context(self, df_with_contexts: pd.DataFrame, feature_relation_df: pd.DataFrame) -> pd.DataFrame:
        context_cols = [col for col in df_with_contexts.columns if col.startswith('ctx_')]
        stats = []
        for context_name in context_cols:
            context_mask = df_with_contexts[context_name] == 1
            if not context_mask.any():
                continue
            context_data = feature_relation_df[context_mask]
            n_total = len(context_data)
            n_success = (context_data['success'] == True).sum()
            n_failure = (context_data['success'] == False).sum()
            if n_success + n_failure == 0:
                continue
            stat = {
                'context': context_name,
                'n_total': n_total,
                'n_success': n_success,
                'n_failure': n_failure,
                'failure_rate': (n_failure / (n_success + n_failure) * 100) if (n_success + n_failure) > 0 else 0,
            }
            if 'f_time_in_current_state' in context_data.columns:
                stat['avg_time_success_s'] = context_data.loc[context_data['success'] == True, 'f_time_in_current_state'].mean() or 0
                stat['avg_time_failure_s'] = context_data.loc[context_data['success'] == False, 'f_time_in_current_state'].mean() or 0
                stat['time_difference_s'] = stat['avg_time_failure_s'] - stat['avg_time_success_s']
            relation_cols = [col for col in context_data.columns if col.startswith('r_')]
            for rel in relation_cols:
                stat[f'{rel}_success_rate'] = context_data.loc[context_data['success'] == True, rel].mean() * 100 if n_success > 0 else 0
                stat[f'{rel}_failure_rate'] = context_data.loc[context_data['success'] == False, rel].mean() * 100 if n_failure > 0 else 0
            stats.append(stat)
        context_stats_df = pd.DataFrame(stats)
        if 'time_difference_s' in context_stats_df.columns:
            context_stats_df = context_stats_df.sort_values('time_difference_s', ascending=False)
        return context_stats_df

# ============================================================================
# OPTIMIZED ANOMALY DETECTION
# ============================================================================

class OptimizedAnomalyDetector:
    """Vectorized anomaly detection for faster processing"""
    
    def __init__(self):
        self.STOPPED_THRESHOLD = 0.01
        self.STOPPED_DURATION = 5.0
        self.VERY_SLOW_THRESHOLD = 0.05
        self.SLOW_DURATION = 10.0
        self.NO_PROGRESS_THRESHOLD = 0.01
        self.NO_PROGRESS_DURATION = 5.0
        self.OSCILLATING_ANGULAR_VEL = 0.5
        self.OSCILLATING_DURATION = 5.0
        self.STUCK_TIME_SINCE_PROGRESS = 10.0
        self.WRONG_WAY_HEADING_ERROR = 90
        self.NEAR_GOAL_DISTANCE = 1.0
        
    def detect_anomalies(self, df: pd.DataFrame) -> pd.DataFrame:
        """Vectorized anomaly detection - much faster than row-by-row"""
        print("Detecting anomalies using vectorized operations...")
        df = df.copy()
        
        # Initialize columns efficiently
        df['has_anomaly'] = False
        df['anomaly_type'] = 'none'
        df['anomaly_severity'] = 0.0
        
        # Pre-compute common conditions once
        velocity = df['velocity_magnitude_mps'].fillna(0)
        time_state = df['time_since_state_change_s'].fillna(0)
        time_progress = df['time_since_progress_s'].fillna(0)
        dist_goal = df['dist_to_goal_m'].fillna(np.inf)
        wall_clearance = df['wall_clearance_m'].fillna(np.inf)
        heading_error = df['heading_error_deg'].fillna(0)
        position_var = df['position_variance_10s'].fillna(0)
        recovery_count = df['recovery_attempt_count_20s'].fillna(0)
        
        # Define all masks at once (vectorized operations)
        masks = {
            'stuck_stopped': (
                (velocity < self.STOPPED_THRESHOLD) &
                (time_state > self.STOPPED_DURATION)
            ),
            'stuck_no_progress': (
                (time_progress > self.STUCK_TIME_SINCE_PROGRESS) &
                (dist_goal > self.NEAR_GOAL_DISTANCE)
            ),
            'oscillating_no_progress': (
                (recovery_count > 5) &
                (position_var < 0.1) &
                (velocity > 0.01)
            ),
            'overspeed_near_obstacle': (
                (velocity > 0.3) &
                (wall_clearance < 0.4) &
                (wall_clearance != np.inf)
            ),
            'wrong_way_to_goal': (
                (heading_error > self.WRONG_WAY_HEADING_ERROR) &
                (dist_goal > self.NEAR_GOAL_DISTANCE) &
                (velocity > 0.05)
            ),
            'near_goal_not_reached': (
                (dist_goal < self.NEAR_GOAL_DISTANCE) &
                (dist_goal > 0.2) &
                (time_progress > 5.0)
            ),
            'localization_jump': (
                position_var > 1.0
            )
        }
        
        # Apply masks in priority order
        priority_order = ['stuck_stopped', 'stuck_no_progress', 'near_goal_not_reached', 
                         'oscillating_no_progress', 'wrong_way_to_goal', 'overspeed_near_obstacle', 'localization_jump']
        
        remaining_mask = df['anomaly_type'] == 'none'
        
        for anomaly_type in priority_order:
            current_mask = masks[anomaly_type] & remaining_mask
            
            if current_mask.any():
                df.loc[current_mask, 'has_anomaly'] = True
                df.loc[current_mask, 'anomaly_type'] = anomaly_type
                
                # Compute severity vectorized
                if anomaly_type in ['stuck_stopped', 'stuck_no_progress', 'near_goal_not_reached']:
                    severity_col = time_state if 'stuck_stopped' in anomaly_type else time_progress
                    df.loc[current_mask, 'anomaly_severity'] = np.minimum(severity_col[current_mask] / 30.0, 1.0)
                elif anomaly_type == 'oscillating_no_progress':
                    df.loc[current_mask, 'anomaly_severity'] = np.minimum(recovery_count[current_mask] / 10.0, 1.0)
                elif anomaly_type == 'overspeed_near_obstacle':
                    df.loc[current_mask, 'anomaly_severity'] = np.minimum(velocity[current_mask] / 0.5, 1.0)
                elif anomaly_type == 'wrong_way_to_goal':
                    df.loc[current_mask, 'anomaly_severity'] = np.minimum(heading_error[current_mask] / 180.0, 1.0)
                elif anomaly_type == 'localization_jump':
                    df.loc[current_mask, 'anomaly_severity'] = np.minimum(position_var[current_mask] / 5.0, 1.0)
                
                remaining_mask = remaining_mask & ~current_mask
        
        return df

# ============================================================================
# OPTIMIZED FEATURE VECTOR CREATOR
# ============================================================================

class OptimizedAnomalyFeatureVectorCreator:
    """Optimized feature vector extraction with batch processing"""
    
    def __init__(self, feature_definitions, relation_computer):
        self.feature_defs = feature_definitions
        self.relation_computer = relation_computer
        self.continuous_features = [
            'dist_to_goal_m', 'wall_clearance_m', 'velocity_magnitude_mps',
            'angular_velocity_radps', 'time_since_state_change_s', 'progress_rate_mps',
            'time_since_progress_s', 'cumulative_stopped_time_30s', 'time_in_current_room_s',
            'heading_error_deg', 'path_efficiency', 'position_variance_10s',
            'recovery_attempt_count_20s', 'wall_following_duration_s', 'backward_motion_ratio_30s'
        ]
    
    def extract_anomaly_feature_vectors(self, df_with_anomalies: pd.DataFrame, 
                                      df_with_contexts: pd.DataFrame) -> pd.DataFrame:
        """Optimized batch feature extraction"""
        print("=" * 80)
        print("CREATING FEATURE VECTORS AT ANOMALY TIMESTAMPS")
        print("=" * 80)
        
        # Filter anomalies efficiently
        anomaly_rows = df_with_anomalies[df_with_anomalies['has_anomaly']].copy()
        print(f"\nTotal anomalies detected: {len(anomaly_rows)}")
        
        if len(anomaly_rows) == 0:
            return pd.DataFrame()
        
        # Show anomaly distribution
        print("\nAnomaly type distribution:")
        print(anomaly_rows['anomaly_type'].value_counts())
        
        # Get context columns once
        context_cols = [col for col in df_with_contexts.columns if col.startswith('ctx_')]
        
        # Batch extract metadata
        print("\nExtracting metadata and contexts...")
        metadata_df = anomaly_rows[['timestamp', 'scenario_id', 'run_id', 'anomaly_type', 'anomaly_severity']].copy()
        metadata_df.index.name = 'anomaly_id'
        metadata_df = metadata_df.reset_index()
        
        # Add map_name and success if available
        for col in ['map_name', 'success']:
            if col in anomaly_rows.columns:
                metadata_df[col] = anomaly_rows[col].values
            else:
                metadata_df[col] = 'unknown' if col == 'map_name' else None
        
        # Batch extract contexts
        context_data = df_with_contexts.loc[anomaly_rows.index, context_cols].fillna(0)
        
        # Create active contexts string efficiently
        active_contexts_list = []
        for idx in context_data.index:
            active = context_data.loc[idx]
            active_ctx = [col for col, val in active.items() if val == 1]
            active_contexts_list.append(','.join(active_ctx))
        
        metadata_df['active_contexts'] = active_contexts_list
        metadata_df['num_active_contexts'] = [len(ctx.split(',')) if ctx else 0 for ctx in active_contexts_list]
        
        # Add context columns
        for col in context_cols:
            metadata_df[col] = context_data[col].values
        
        # Batch compute features and relations
        print("Computing features and relations...")
        features_df = self.feature_defs.compute_all_features_df(anomaly_rows)
        relations_df = self.relation_computer.compute_all_relations_df(features_df)
        
        # Extract raw continuous features efficiently
        print("Extracting continuous features...")
        continuous_df = pd.DataFrame(index=anomaly_rows.index)
        for feat_name in self.continuous_features:
            if feat_name in anomaly_rows.columns:
                continuous_df[f'{feat_name}_raw'] = anomaly_rows[feat_name]
        
        # Combine all DataFrames efficiently
        print("Combining feature vectors...")
        result_df = pd.concat([
            metadata_df.set_index('anomaly_id'),
            relations_df,
            continuous_df
        ], axis=1).reset_index()
        
        # Normalize continuous features
        print("Normalizing continuous features...")
        result_df = self._normalize_continuous_features_batch(result_df)
        
        # Summary
        print("\n" + "=" * 80)
        print("FEATURE VECTOR EXTRACTION COMPLETE")
        print("=" * 80)
        print(f"Total feature vectors: {len(result_df):,}")
        print(f"Features per vector:")
        print(f"  - Metadata: 8")
        print(f"  - Contexts: {len(context_cols)}")
        print(f"  - Relations: {len([c for c in result_df.columns if c.startswith('r_')])}")
        print(f"  - Continuous (raw): {len([c for c in result_df.columns if c.endswith('_raw')])}")
        print(f"  - Continuous (norm): {len([c for c in result_df.columns if c.endswith('_norm')])}")
        print(f"  - Total columns: {len(result_df.columns)}")
        
        return result_df
    
    def _normalize_continuous_features_batch(self, df: pd.DataFrame) -> pd.DataFrame:
        """Vectorized normalization - much faster than row-by-row"""
        print("  Applying Min-Max normalization [0, 1]...")
        
        raw_cols = [col for col in df.columns if col.endswith('_raw')]
        
        for raw_col in raw_cols:
            feat_name = raw_col.replace('_raw', '')
            norm_col = f'{feat_name}_norm'
            
            values = df[raw_col].replace([np.inf, -np.inf], np.nan)
            
            # Vectorized min-max normalization
            min_val = values.min()
            max_val = values.max()
            
            if pd.isna(min_val) or pd.isna(max_val) or (max_val - min_val) < 1e-10:
                df[norm_col] = 0.5  # Constant or all NaN
            else:
                df[norm_col] = ((values - min_val) / (max_val - min_val)).fillna(0.0).clip(0.0, 1.0)
            
            print(f"    {feat_name:40s} [{min_val:8.3f}, {max_val:8.3f}] -> [0.000, 1.000]")
        
        return df
