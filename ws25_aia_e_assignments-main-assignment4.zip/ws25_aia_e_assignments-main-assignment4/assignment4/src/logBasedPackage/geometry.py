from setup.config import *

class MapGeometry:
    def __init__(self, yaml_path):
        """Initializes geometry engine from ROS map metadata."""
        with open(yaml_path, 'r') as f:
            self.metadata = yaml.safe_load(f)
        
        self.resolution = self.metadata['resolution']
        self.origin = np.array(self.metadata['origin'][:2]) # [x, y]
        
        # Load the PGM image as a numpy array
        pgm_path = Path(yaml_path).parent / self.metadata['image']
        img = Image.open(pgm_path)
        self.grid = np.array(img)
        
        # Binary mask: True where there is an obstacle (0 is usually black/wall)
        self.wall_mask = self.grid < 10 
        
        # Euclidean Distance Transform: f1(t) = distance(robot, closest_wall)
        # Precomputing this allows O(1) lookup during feature extraction
        self.dist_transform = distance_transform_edt(~self.wall_mask) * self.resolution

    def world_to_pixel(self, x, y):
        """Converts meters to pixel indices."""
        px = int((x - self.origin[0]) / self.resolution)
        # Flip Y because images are top-down while ROS is bottom-up
        py = self.grid.shape[0] - int((y - self.origin[1]) / self.resolution)
        return px, py

    def get_distance_to_wall(self, x, y):
        """Computable function f1 from the assignment."""
        px, py = self.world_to_pixel(x, y)
        if 0 <= px < self.grid.shape[1] and 0 <= py < self.grid.shape[0]:
            return self.dist_transform[py, px]
        return 0.0 # Out of bounds
    
def identify_spatial_context(x, y, door_anchors, threshold=1.2):
    """
    Determines if the robot is in Context C = {robot_near_door}.
    door_anchors: List of (x, y) centers for each doorway in the map.
    """
    for dx, dy in door_anchors:
        dist = np.sqrt((x - dx)**2 + (y - dy)**2)
        if dist < threshold:
            return "robot_near_door"
    return "robot_in_corridor"

def plot_alignment_check(run_data, map_geometry, goal_poses, start_pose=None):
    """
    Overlays the robot trajectory, start pose, and goal poses on the static map geometry.
    Used to verify that world_to_pixel alignment is accurate.
    goal_poses: list of dicts, each with 'position' (with 'x' and 'y').
    start_pose: dict with 'position' (with 'x' and 'y').
    """
    plt.figure(figsize=(12, 10))
    plt.imshow(map_geometry.wall_mask, cmap='Greys', origin='upper', alpha=0.8)

    # Plot robot trajectory
    if run_data.poses is not None:
        path_x, path_y = [], []
        for _, row in run_data.poses.iterrows():
            px, py = map_geometry.world_to_pixel(row['position.x'], row['position.y'])
            path_x.append(px)
            path_y.append(py)
        plt.plot(path_x, path_y, color='blue', linewidth=1.5, label='Robot Path', alpha=0.6)
        plt.scatter(path_x[-1], path_y[-1], color='red', marker='X', s=150, label='Final Position (Failure)', zorder=5)

    # Plot start pose (from dictionary)
    if start_pose is not None and 'position' in start_pose:
        sx = start_pose['position'].get('x', None)
        sy = start_pose['position'].get('y', None)
        if sx is not None and sy is not None:
            spx, spy = map_geometry.world_to_pixel(sx, sy)
            plt.scatter(spx, spy, color='lime', s=140, marker='o', label='Start Pose', zorder=6)

    # Plot goal poses
    for idx, goal in enumerate(goal_poses):
        gx = goal['position']['x']
        gy = goal['position']['y']
        px, py = map_geometry.world_to_pixel(gx, gy)
        plt.scatter(px, py, color='orange', s=120, marker='*', label='Goal' if idx == 0 else None, zorder=6)

    for idx, ts in enumerate(run_data.anomaly_timestamps_and_poses):
        if ts["gt_pose_x"] is not None and ts["gt_pose_y"] is not None:
            ax, ay = map_geometry.world_to_pixel(ts["gt_pose_x"], ts["gt_pose_y"])
            label = 'Anomaly Trigger' if idx == 0 else None
            plt.scatter(ax, ay, edgecolors='orange', facecolors='none', s=200, linewidths=2, label=label, zorder=7)
        
    plt.title(f"Alignment Check: {run_data.scenario_id} - Run {run_data.run_id}")
    plt.xlabel("Map Pixel X")
    plt.ylabel("Map Pixel Y")
    plt.legend(loc='upper right')
    plt.tight_layout()
    save_figure(f"LOG_BASED_Alignment Check: {run_data.scenario_id} - Run {run_data.run_id}.png")
    plt.close()
