from setup.config import *

def prerpocess_rosbag(rosbag_df: pd.DataFrame) -> pd.DataFrame:
    if rosbag_df is None:
        return None

    left_wheel_width = rosbag_df[rosbag_df["transforms[0].child_frame_id"] == "left_wheel"]["transforms[0].transform.translation.y"].unique()[0]
    robot_width = abs(left_wheel_width) * 2.0
    
    preproessed_rosbag = rosbag_df[rosbag_df["topic"].isin(["/amcl_pose"])]
    preproessed_rosbag = preproessed_rosbag[["timestamp","pose.covariance","pose.pose.position.x",
                                             "pose.pose.position.y","pose.pose.orientation.z","pose.pose.orientation.w"]]
    preproessed_rosbag = preproessed_rosbag.rename(columns={
        "pose.covariance": "covariance_amcl",
        "pose.pose.position.x": "position_x_amcl",
        "pose.pose.position.y": "position_y_amcl",
        "pose.pose.orientation.z": "orientation_z_amcl",
        "pose.pose.orientation.w": "orientation_w_amcl"
    })
    preproessed_rosbag["robot_width"] = robot_width
    preproessed_rosbag["timestamp"] = preproessed_rosbag["timestamp"]/ 1e9  # Convert to seconds
    
    return preproessed_rosbag

def preprocess_poses(poses_df: pd.DataFrame) -> pd.DataFrame:
    if poses_df is None:
        return None
    preprocessed_poses = poses_df[poses_df["frame"] == "nav2_turtlebot4_base_link_gt"]
    preprocessed_poses.rename(columns={
        "position.x": "position_x_gt",
        "position.y": "position_y_gt",
        "position.z": "position.z_gt",
        "orientation.roll": "orientation_roll_gt",
        "orientation.pitch": "orientation_pitch_gt",
        "orientation.yaw": "orientation_yaw_gt"
    }, inplace=True)
    preprocessed_poses.drop(columns=["frame"], inplace=True)
    return preprocessed_poses

def merge_rosbag_with_poses(rosbag_df: pd.DataFrame, poses_df: pd.DataFrame) -> pd.DataFrame:
    """
    Merges rosbag data with poses data based on nearest timestamps.
    """
    preproessed_rosbag = prerpocess_rosbag(rosbag_df)
    preproessed_poses = preprocess_poses(poses_df)
    if preproessed_rosbag is None or preproessed_poses is None:
        return None

    merged_df = pd.merge_asof(
        preproessed_poses.sort_values('timestamp'),
        preproessed_rosbag.sort_values('timestamp'), 
        on='timestamp', 
        direction='nearest'
    )

    return merged_df

def preprocess_data(scenarios):
    """Main preprocessing pipeline."""
    with open(MAPS_DETAILS_PATH, 'r') as f:
        map_details = json.load(f)
    
    final_df_list = []
    for scenario in scenarios:
        map_name = scenario.map_variations[0].get("label")
        for run in scenario.runs:
            merged_df = merge_rosbag_with_poses(run.rosbag, run.poses)
            if merged_df is not None:
                merged_df["scenario_id"] = scenario.scenario_id
                merged_df["run_id"] = run.run_id
                merged_df["map_name"] = map_name
                final_df_list.append(merged_df)
    
    final_df = pd.concat(final_df_list, ignore_index=True)
    final_df["loc_error"] = np.sqrt(
        (final_df["position_x_gt"] - final_df["position_x_amcl"])**2 +
        (final_df["position_y_gt"] - final_df["position_y_amcl"])**2
    )
    return final_df