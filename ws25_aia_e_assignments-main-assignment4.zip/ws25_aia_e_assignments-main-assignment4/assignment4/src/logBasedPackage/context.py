from setup.config import *
from src.data_loading import scenario_name_to_label
class SpatialContextMapper:
    def __init__(self, map_details):
        """Initialize with precomputed polygons and spatial indexing."""
        self.maps_json = map_details
        
        # Pre-compute all polygons for faster lookup
        self.polygon_cache = {}
        self.map_polygons = defaultdict(list)
        
        for map_info in self.maps_json['maps']:
            map_name = map_info['map']
            self.map_polygons[map_name] = []
            
            for space in map_info.get('spaces', []):
                corners = space.get('corners', [])
                if len(corners) >= 3:
                    poly = Polygon(corners)
                    space_name = space.get('space_name', 'Unnamed_Space')
                    
                    # Store polygon with metadata
                    self.map_polygons[map_name].append({
                        'polygon': poly,
                        'space_name': space_name,
                        'bounds': poly.bounds  # For quick bbox filtering
                    })

    def get_context(self, x_coords, y_coords, map_name):
        """Vectorized spatial context identification."""
        if map_name not in self.map_polygons:
            return ["Unknown_Map"] * len(x_coords)
        
        results = ["Corridor_or_Transition"] * len(x_coords)
        
        # Convert to numpy arrays for faster computation
        x_arr = np.array(x_coords)
        y_arr = np.array(y_coords)
        
        # Check each polygon for this map
        for space_info in self.map_polygons[map_name]:
            poly = space_info['polygon']
            space_name = space_info['space_name']
            bounds = space_info['bounds']
            
            # Quick bbox filter to reduce polygon checks
            minx, miny, maxx, maxy = bounds
            bbox_mask = ((x_arr >= minx) & (x_arr <= maxx) & 
                        (y_arr >= miny) & (y_arr <= maxy))
            
            if not bbox_mask.any():
                continue
                
            # Only check points within bounding box
            bbox_indices = np.where(bbox_mask)[0]
            if len(bbox_indices) > 0:
                # Vectorized contains check for efficiency
                contains_mask = contains(poly, x_arr[bbox_indices], y_arr[bbox_indices])
                
                # Update results for points inside this polygon
                for i, idx in enumerate(bbox_indices):
                    if contains_mask[i]:
                        results[idx] = space_name
        
        return results

    def apply_spatial_context_optimized(self, final_df):

        results = []
        
        for map_name, group in final_df.groupby('map_name'):
            x_coords = group['position_x_gt'].values
            y_coords = group['position_y_gt'].values
            
            # Get spatial context for this group
            spatial_contexts = self.get_context(x_coords, y_coords, map_name)
            
            # Create a temporary dataframe with results
            temp_df = group.copy()
            temp_df['spatial_context'] = spatial_contexts
            results.append(temp_df)
        
        # Concatenate all results
        return pd.concat(results, ignore_index=True)

class SpatialContextExtractor:
    """
    Extracts contexts based on spatial_context (room locations) in final_df
    plus additional robot state information.
    Does NOT create _stopped contexts.
    """
    
    def __init__(self):
        # Define context rules based on spatial location and robot state
        self.context_rules = {
            'velocity_very_slow': 0.05,
            'near_obstacle_dist': 0.80,
            'close_obstacle_dist': 0.40,
            'near_goal_dist': 0.80,
            'tight_wall_clearance': 0.40,
            'poor_localization': 0.5,
        }
    
    def extract_contexts(self, row: pd.Series) -> List[str]:
        """
        Extract all active contexts for a single row
        
        Returns list of context strings like:
        - 'ctx_room_2_51'
        - 'ctx_room_2_51_very_slow'
        - 'ctx_corridor_near_obstacle'
        - 'ctx_global'
        
        NOTE: No _stopped contexts are created
        """
        contexts = []
        
        # 1. BASE SPATIAL CONTEXT (from spatial_context column)
        spatial_ctx = str(row.get('spatial_context', 'unknown'))
        if spatial_ctx != 'unknown' and spatial_ctx != 'nan':
            # Create base room context
            base_ctx = f"ctx_{spatial_ctx.replace(' ', '_').replace('.', '_')}"
            contexts.append(base_ctx)
            
            # 2. ADD MOTION STATE TO SPATIAL CONTEXT (only very_slow, no stopped)
            velocity = row.get('velocity_magnitude_mps', 0)
            if velocity < self.context_rules['velocity_very_slow']:
                contexts.append(f"{base_ctx}_very_slow")
            
            # 3. ADD OBSTACLE PROXIMITY TO SPATIAL CONTEXT
            obs_dist = row.get('nearest_obstacle_dist_m', np.inf)
            if np.isfinite(obs_dist):
                if obs_dist < self.context_rules['close_obstacle_dist']:
                    contexts.append(f"{base_ctx}_close_to_obstacle")
                elif obs_dist < self.context_rules['near_obstacle_dist']:
                    contexts.append(f"{base_ctx}_near_obstacle")
            
            # 4. ADD WALL CLEARANCE TO SPATIAL CONTEXT
            wall_dist = row.get('wall_clearance_m', np.inf)
            if np.isfinite(wall_dist) and wall_dist < self.context_rules['tight_wall_clearance']:
                contexts.append(f"{base_ctx}_tight_clearance")
            
            # 5. ADD GOAL PROXIMITY TO SPATIAL CONTEXT
            goal_dist = row.get('dist_to_goal_m', np.inf)
            if np.isfinite(goal_dist) and goal_dist < self.context_rules['near_goal_dist']:
                contexts.append(f"{base_ctx}_near_goal")
            
            # 6. ADD LOCALIZATION QUALITY TO SPATIAL CONTEXT
            loc_cov = row.get('amcl_cov_trace', 0)
            if np.isfinite(loc_cov) and loc_cov > self.context_rules['poor_localization']:
                contexts.append(f"{base_ctx}_poor_localization")
        
        # 7. GENERAL MOTION CONTEXTS (only very_slow, no stopped)
        velocity = row.get('velocity_magnitude_mps', 0)
        if velocity < self.context_rules['velocity_very_slow']:
            contexts.append('ctx_very_slow')
        
        # 8. GENERAL OBSTACLE CONTEXTS
        obs_dist = row.get('nearest_obstacle_dist_m', np.inf)
        if np.isfinite(obs_dist) and obs_dist < self.context_rules['near_obstacle_dist']:
            contexts.append('ctx_near_obstacle')
        
        # 9. GOAL CONTEXT
        goal_dist = row.get('dist_to_goal_m', np.inf)
        if np.isfinite(goal_dist) and goal_dist < self.context_rules['near_goal_dist']:
            contexts.append('ctx_near_goal')
        
        # 10. ALWAYS ADD GLOBAL CONTEXT
        contexts.append('ctx_global')
        
        return contexts
    
    def extract_contexts_batch(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Extract contexts for entire dataframe
        
        Returns dataframe with additional columns:
        - 'active_contexts': comma-separated string of all active contexts
        - 'ctx_X': binary columns for each unique context found
        """
        print("Extracting contexts from spatial_context (no _stopped contexts)...")
        
        # Extract contexts for each row
        all_contexts_list = []
        for idx, row in df.iterrows():
            contexts = self.extract_contexts(row)
            all_contexts_list.append(contexts)
        
        # Add as comma-separated string
        df['active_contexts'] = [','.join(contexts) for contexts in all_contexts_list]
        
        # Get all unique contexts (filter out any _stopped if they somehow appear)
        unique_contexts = set()
        for contexts in all_contexts_list:
            unique_contexts.update(contexts)
        
        # Extra safety: remove any context with '_stopped' in name
        unique_contexts = {ctx for ctx in unique_contexts if '_stopped' not in ctx}
        
        print(f"Found {len(unique_contexts)} unique contexts (no _stopped)")
        
        # Create binary columns for each context
        for context in sorted(unique_contexts):
            df[context] = [int(context in contexts) for contexts in all_contexts_list]
        
        return df

# Add helper function:
def apply_spatial_context_class(final_df, maps_details):
    mapper = SpatialContextMapper(maps_details)
    return mapper.apply_spatial_context_optimized(final_df)

def plot_final_trajectory(df, map_mapper, target_scenario, target_run):
    """
    Plots the robot trajectory for a specific scenario, 
    coloring the path by spatial context and showing doors.
    """
    # 1. Filter for the specific scenario to visualize
    run_df = df[(df['scenario_id'] == target_scenario)&(df['run_id'] == target_run)].copy()
    
    if run_df.empty:
        print(f"No data found for scenario {target_scenario}, run {target_run}")
        return
    
    # 2. Get the specific map geometry from JSON
    print(f"Data shape: {run_df.shape}")
    map_label = run_df['map_name'].iloc[0]
    map_info = map_mapper.get(map_label)
    
    if not map_info:
        print(f"No map info found for {map_label}")
        return

    plt.figure(figsize=(14, 12))
    
    # 3. Draw the Map Layout (Rooms and Doors)
    for space in map_info['spaces']:
        corners = space['corners']
        # Close the polygon for plotting
        closed_corners = corners + [corners[0]]
        mx, my = zip(*closed_corners)
        
        plt.plot(mx, my, color='black', alpha=0.3, linestyle='-', linewidth=1.5)
        plt.fill(mx, my, alpha=0.08, color='lightblue')
        
        # Label each room
        cx = sum(p[0] for p in corners) / len(corners)
        cy = sum(p[1] for p in corners) / len(corners)
        plt.text(cx, cy, space['space_name'], fontsize=9, ha='center', 
                va='center', alpha=0.7, bbox=dict(boxstyle="round,pad=0.3", 
                facecolor='white', alpha=0.8))
        
        # 4. Draw Doors
        if 'door' in space and space['door']:
            door_coords = space['door']
            if len(door_coords) >= 2:
                # Door is typically defined as two points forming a line
                door_x = [door_coords[0][0], door_coords[1][0]]
                door_y = [door_coords[0][1], door_coords[1][1]]
                plt.plot(door_x, door_y, color='red', linewidth=4, 
                        alpha=0.8, label='Doors' if space == map_info['spaces'][0] else "")

    # 5. Draw the Robot Path colored by the detected Context
    contexts = run_df['spatial_context'].unique()
    colors = plt.cm.Set3(np.linspace(0, 1, len(contexts)))  # Generate distinct colors
    
    for idx, ctx in enumerate(contexts):
        subset = run_df[run_df['spatial_context'] == ctx]
        if not subset.empty:
            plt.scatter(subset['position_x_gt'], subset['position_y_gt'], 
                       label=f"In {ctx}", s=12, c=[colors[idx]], alpha=0.7)

    # 6. Mark start and end points of trajectory
    if not run_df.empty:
        start_point = run_df.iloc[0]
        end_point = run_df.iloc[-1]
        
        plt.scatter(start_point['position_x_gt'], start_point['position_y_gt'], 
                   color='green', s=100, marker='o', label='Start', 
                   edgecolors='black', linewidth=2, zorder=5)
        plt.scatter(end_point['position_x_gt'], end_point['position_y_gt'], 
                   color='red', s=100, marker='X', label='End', 
                   edgecolors='black', linewidth=2, zorder=5)

    # 7. Highlight Potential Anomalies (Physics-Based)
    if 'dist_to_wall' in run_df.columns:
        collisions = run_df[run_df['dist_to_wall'] <= 0.18]
        if not collisions.empty:
            plt.scatter(collisions['position_x_gt'], collisions['position_y_gt'], 
                       color='orange', marker='x', s=60, label='Collision Point', 
                       edgecolors='darkred', linewidth=1)

    plt.title(f"Trajectory Analysis: {target_scenario} - Run {target_run}")
    plt.xlabel("X (meters)")
    plt.ylabel("Y (meters)")
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.axis('equal')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    save_figure(f"LOG_BASED_Trajectory Analysis: {target_scenario} - Run {target_run}.png")
    plt.close()

class ContextMapVisualizer:
    """
    Visualize contexts as bounding boxes on the actual map
    Works with maps_details.json structure
    """
    
    def __init__(self, map_details, scenarios):
        """
        Parameters:
        - map_details: Loaded maps_details.json
        - scenarios: List of ScenarioData objects to find map images
        """
        self.map_details = map_details
        self.scenarios = scenarios
        
        # Create map lookup by name
        self.map_lookup = {map_info['map']: map_info for map_info in map_details['maps']}
        
        # Create mapping from map names to image paths
        self.map_images = self._find_map_images()
    
    def _find_map_images(self):
        """
        Find map image files from scenario folders
        """
        map_images = {}
        
        for scenario in self.scenarios:
            # Get map label from scenario name
            map_label = scenario_name_to_label(scenario.scenario_id)
            
            # Check if we have map variations for this scenario
            if scenario.map_variations:
                for map_var in scenario.map_variations:
                    if map_var['map_pgm'] and Path(map_var['map_pgm']).exists():
                        map_images[map_label] = str(map_var['map_pgm'])
                        break
        
        return map_images
    
    def get_map_bounds(self, map_name):
        """
        Get the coordinate bounds from map geometry
        """
        if map_name not in self.map_lookup:
            return None
        
        map_info = self.map_lookup[map_name]
        
        # Get all corner points from all spaces
        all_x = []
        all_y = []
        
        for space in map_info['spaces']:
            for corner in space['corners']:
                all_x.append(corner[0])
                all_y.append(corner[1])
        
        return {
            'x_min': min(all_x),
            'x_max': max(all_x),
            'y_min': min(all_y),
            'y_max': max(all_y)
        }
    
    def get_context_bounds(self, df_with_contexts, context_name):
        """
        Get the bounding box for a context based on where it occurs
        Returns: (x_min, x_max, y_min, y_max, n_points, failure_rate)
        """
        context_data = df_with_contexts[df_with_contexts[context_name] == 1].copy()
        
        if len(context_data) == 0:
            return None
        
        x_min = context_data['position_x_gt'].min()
        x_max = context_data['position_x_gt'].max()
        y_min = context_data['position_y_gt'].min()
        y_max = context_data['position_y_gt'].max()
        
        n_points = len(context_data)
        n_failures = (~context_data['success']).sum()
        failure_rate = (n_failures / n_points * 100) if n_points > 0 else 0
        
        return {
            'x_min': x_min,
            'x_max': x_max,
            'y_min': y_min,
            'y_max': y_max,
            'n_points': n_points,
            'n_failures': n_failures,
            'failure_rate': failure_rate
        }
    
    def plot_context_boxes(self, df_with_contexts, context_names, map_name, 
                          figsize=(15, 15), save_path=None, show_labels=True):
        """
        Plot bounding boxes for multiple contexts on the map
        
        Parameters:
        - df_with_contexts: DataFrame with context columns
        - context_names: List of context names to visualize
        - map_name: Map name from maps_details.json
        - figsize: Figure size
        - save_path: If provided, save figure to this path
        - show_labels: Whether to show labels inside boxes
        """
        
        # Check if map exists
        if map_name not in self.map_lookup:
            print(f"Map '{map_name}' not found in map_details")
            print(f"Available maps: {list(self.map_lookup.keys())}")
            return
        
        # Get map image
        if map_name not in self.map_images:
            print(f"Map image not found for '{map_name}'")
            print(f"Available map images: {list(self.map_images.keys())}")
            return
        
        map_path = Path(self.map_images[map_name])
        if not map_path.exists():
            print(f"Map image file not found: {map_path}")
            return
        
        map_img = Image.open(map_path)
        bounds = self.get_map_bounds(map_name)
        
        # Create figure
        fig, ax = plt.subplots(figsize=figsize)
        
        # Show map as background with proper extent
        if bounds:
            extent = [bounds['x_min'], bounds['x_max'], bounds['y_min'], bounds['y_max']]
            ax.imshow(map_img, cmap='gray', alpha=0.6, extent=extent, origin='lower', aspect='auto')
        else:
            ax.imshow(map_img, cmap='gray', alpha=0.6)
        
        # Draw room boundaries from map_details
        map_info = self.map_lookup[map_name]
        for space in map_info['spaces']:
            corners = space['corners']
            corners_closed = corners + [corners[0]]
            xs = [c[0] for c in corners_closed]
            ys = [c[1] for c in corners_closed]
            ax.plot(xs, ys, 'b-', alpha=0.2, linewidth=1)
            
            # Add space name
            center_x = np.mean([c[0] for c in corners])
            center_y = np.mean([c[1] for c in corners])
            ax.text(center_x, center_y, space['space_name'], 
                   fontsize=7, ha='center', va='center', alpha=0.4,
                   bbox=dict(boxstyle='round,pad=0.2', facecolor='lightblue', alpha=0.3))
        
        # Color map for contexts (use a colormap for variety)
        colors = plt.cm.Set3(np.linspace(0, 1, len(context_names)))
        
        # Draw bounding box for each context
        for idx, context_name in enumerate(context_names):
            context_bounds = self.get_context_bounds(df_with_contexts, context_name)
            
            if context_bounds is None:
                print(f"No data for context: {context_name}")
                continue
            
            # Choose color based on failure rate
            failure_rate = context_bounds['failure_rate']
            if failure_rate > 70:
                color = 'red'
                alpha = 0.4
            elif failure_rate > 40:
                color = 'orange'
                alpha = 0.3
            elif failure_rate > 20:
                color = 'yellow'
                alpha = 0.25
            else:
                color = 'green'
                alpha = 0.2
            
            # Draw rectangle
            width = context_bounds['x_max'] - context_bounds['x_min']
            height = context_bounds['y_max'] - context_bounds['y_min']
            
            rect = plt.Rectangle(
                (context_bounds['x_min'], context_bounds['y_min']),
                width, height,
                linewidth=2,
                edgecolor=color,
                facecolor=color,
                alpha=alpha,
                label=f"{context_name} ({failure_rate:.1f}% fail)"
            )
            ax.add_patch(rect)
            
            # Add label inside box if requested
            if show_labels:
                center_x = (context_bounds['x_min'] + context_bounds['x_max']) / 2
                center_y = (context_bounds['y_min'] + context_bounds['y_max']) / 2
                
                label_text = f"{context_name}\n{context_bounds['n_points']} pts\n{failure_rate:.1f}% fail"
                ax.text(center_x, center_y, label_text,
                       fontsize=8, ha='center', va='center',
                       bbox=dict(boxstyle='round,pad=0.3', 
                                facecolor='white', 
                                edgecolor=color,
                                alpha=0.8, linewidth=2))
        
        # Add title
        ax.set_title(f'Context Bounding Boxes - {map_name}\n'
                    f'Showing {len(context_names)} contexts',
                    fontsize=14, fontweight='bold')
        ax.set_xlabel('X Position (m)', fontsize=12)
        ax.set_ylabel('Y Position (m)', fontsize=12)
        
        # Add legend (might be crowded, so place it outside)
        ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=8)
        
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        
        if save_path:
            save_figure(save_path)
        plt.close()
    
    def plot_single_context_box(self, df_with_contexts, context_name, map_name,
                                figsize=(15, 15), save_path=None):
        """
        Plot a single context's bounding box with detailed info
        """
        
        # Check if map exists
        if map_name not in self.map_lookup:
            print(f"Map '{map_name}' not found in map_details")
            return
        
        if map_name not in self.map_images:
            print(f"Map image not found for '{map_name}'")
            return
        
        map_path = Path(self.map_images[map_name])
        if not map_path.exists():
            print(f"Map image file not found: {map_path}")
            return
        
        map_img = Image.open(map_path)
        bounds = self.get_map_bounds(map_name)
        
        # Get context bounds
        context_bounds = self.get_context_bounds(df_with_contexts, context_name)
        
        if context_bounds is None:
            print(f"No data for context: {context_name}")
            return
        
        # Create figure
        fig, ax = plt.subplots(figsize=figsize)
        
        # Show map
        if bounds:
            extent = [bounds['x_min'], bounds['x_max'], bounds['y_min'], bounds['y_max']]
            ax.imshow(map_img, cmap='gray', alpha=0.6, extent=extent, origin='lower', aspect='auto')
        else:
            ax.imshow(map_img, cmap='gray', alpha=0.6)
        
        # Draw room boundaries
        map_info = self.map_lookup[map_name]
        for space in map_info['spaces']:
            corners = space['corners']
            corners_closed = corners + [corners[0]]
            xs = [c[0] for c in corners_closed]
            ys = [c[1] for c in corners_closed]
            ax.plot(xs, ys, 'b-', alpha=0.3, linewidth=1.5)
            
            center_x = np.mean([c[0] for c in corners])
            center_y = np.mean([c[1] for c in corners])
            ax.text(center_x, center_y, space['space_name'], 
                   fontsize=9, ha='center', va='center', alpha=0.5,
                   bbox=dict(boxstyle='round,pad=0.3', facecolor='lightblue', alpha=0.4))
        
        # Choose color based on failure rate
        failure_rate = context_bounds['failure_rate']
        if failure_rate > 70:
            color = 'darkred'
        elif failure_rate > 40:
            color = 'orangered'
        elif failure_rate > 20:
            color = 'gold'
        else:
            color = 'darkgreen'
        
        # Draw bounding box
        width = context_bounds['x_max'] - context_bounds['x_min']
        height = context_bounds['y_max'] - context_bounds['y_min']
        
        rect = plt.Rectangle(
            (context_bounds['x_min'], context_bounds['y_min']),
            width, height,
            linewidth=3,
            edgecolor=color,
            facecolor=color,
            alpha=0.3
        )
        ax.add_patch(rect)
        
        # Add detailed label
        center_x = (context_bounds['x_min'] + context_bounds['x_max']) / 2
        center_y = (context_bounds['y_min'] + context_bounds['y_max']) / 2
        
        label_text = (f"{context_name}\n\n"
                     f"Points: {context_bounds['n_points']}\n"
                     f"Failures: {context_bounds['n_failures']}\n"
                     f"Failure Rate: {failure_rate:.1f}%\n"
                     f"Area: {width:.2f}m × {height:.2f}m")
        
        ax.text(center_x, center_y, label_text,
               fontsize=11, ha='center', va='center', fontweight='bold',
               bbox=dict(boxstyle='round,pad=0.5', 
                        facecolor='white', 
                        edgecolor=color,
                        alpha=0.9, linewidth=3))
        
        # Add title
        ax.set_title(f'Context: {context_name}\n'
                    f'Map: {map_name}',
                    fontsize=14, fontweight='bold')
        ax.set_xlabel('X Position (m)', fontsize=12)
        ax.set_ylabel('Y Position (m)', fontsize=12)
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            save_figure(save_path)
        plt.close()

    def plot_contexts_by_failure_rate(self, df_with_contexts, context_stats_df, 
                                      map_name, min_activations=50, top_n=10,
                                      figsize=(15, 15), save_path=None):
        """
        Plot the top N contexts with highest failure rates as bounding boxes
        """
        
        # Filter contexts with minimum activations
        high_activity = context_stats_df[context_stats_df['Activations'] >= min_activations].copy()
        high_activity['Failure_Rate_Numeric'] = high_activity['Failure_Rate'].str.rstrip('%').astype(float)
        
        # Get top N by failure rate
        top_contexts = high_activity.nlargest(top_n, 'Failure_Rate_Numeric')
        context_names = top_contexts['Context'].tolist()
        
        print(f"Plotting top {len(context_names)} high-failure contexts as bounding boxes...")
        
        self.plot_context_boxes(
            df_with_contexts, context_names, map_name, 
            figsize=figsize, save_path=save_path, show_labels=True
        )
    
    def plot_all_room_contexts(self, df_with_contexts, map_name,
                               figsize=(15, 15), save_path=None):
        """
        Plot all room-based contexts (ctx_room_X_XX) as bounding boxes
        """
        # Get all context columns that are room-based
        all_context_cols = [col for col in df_with_contexts.columns if col.startswith('ctx_room_')]
        
        # Filter to only base room contexts (not augmented ones like _stopped)
        base_room_contexts = []
        for ctx in all_context_cols:
            # Check if it's a base context (no underscore after room number)
            parts = ctx.split('_')
            if len(parts) == 3:  # ctx_room_2_51 has 4 parts but after split: ['ctx', 'room', '2', '51']
                # Actually we need to check if there are more suffixes
                if df_with_contexts[ctx].sum() > 0:
                    base_room_contexts.append(ctx)
        
        # Get unique base rooms
        room_pattern = re.compile(r'(ctx_room_\d+_\d+)(?:_|$)')
        unique_rooms = set()
        for ctx in all_context_cols:
            match = room_pattern.match(ctx)
            if match:
                unique_rooms.add(match.group(1))
        
        unique_rooms = sorted(list(unique_rooms))
        
        if not unique_rooms:
            print("No room contexts found")
            return
        
        print(f"Found {len(unique_rooms)} unique room contexts")
        
        self.plot_context_boxes(
            df_with_contexts, unique_rooms, map_name,
            figsize=figsize, save_path=save_path, show_labels=True
        )

