from setup.config import *

class RelationGeneralizationAnalyzer:
    """
    Analyzes how well derived atomic relations generalize across the dataset.
    
    Reports:
    1. Frequency of each relation across all scenarios and contexts
    2. Correlation between relations and anomalies vs success
    3. Predictive power (TP, FP, TN, FN, precision, recall, F1)
    """
    
    def __init__(self, anomaly_feature_vectors: pd.DataFrame, full_dataset: pd.DataFrame):
        """
        Parameters:
        - anomaly_feature_vectors: DataFrame with feature vectors at anomalies
        - full_dataset: Complete dataset with all data points (for negatives)
        """
        self.anomaly_vectors = anomaly_feature_vectors
        self.full_dataset = full_dataset
        
        # Get relation columns
        self.relation_cols = [col for col in anomaly_feature_vectors.columns 
                             if col.startswith('r_')]
        
        # Get context columns
        self.context_cols = [col for col in anomaly_feature_vectors.columns 
                            if col.startswith('ctx_')]
        
        print(f"Initialized analyzer with:")
        print(f"  - {len(anomaly_feature_vectors):,} anomaly points")
        print(f"  - {len(full_dataset):,} total data points")
        print(f"  - {len(self.relation_cols)} relations")
        print(f"  - {len(self.context_cols)} contexts")
    
    def analyze_relation_frequency(self) -> pd.DataFrame:
        """
        Analyze how frequently each relation appears across all scenarios.
        
        Returns: DataFrame with relation frequency statistics
        """
        print("\n" + "=" * 80)
        print("RELATION FREQUENCY ANALYSIS")
        print("=" * 80)
        
        relation_stats = []
        
        for relation in self.relation_cols:
            # Overall frequency
            total_count = self.anomaly_vectors[relation].sum()
            total_rate = total_count / len(self.anomaly_vectors) * 100
            
            # Frequency per scenario
            scenario_counts = self.anomaly_vectors.groupby('scenario_id')[relation].agg([
                ('count', 'count'),
                ('true_count', 'sum'),
                ('rate', lambda x: x.sum() / len(x) * 100 if len(x) > 0 else 0)
            ])
            
            n_scenarios_present = (scenario_counts['true_count'] > 0).sum()
            avg_rate_when_present = scenario_counts[scenario_counts['true_count'] > 0]['rate'].mean()
            
            # Frequency per context (if context info available)
            context_frequencies = {}
            for context in self.context_cols:
                if context in self.anomaly_vectors.columns:
                    # Get rows where context is active
                    context_mask = self.anomaly_vectors[context] == 1
                    if context_mask.sum() > 0:
                        rel_in_context = self.anomaly_vectors.loc[context_mask, relation].sum()
                        rel_rate_in_context = rel_in_context / context_mask.sum() * 100
                        if rel_rate_in_context > 5:  # Only store if >5%
                            context_frequencies[context] = rel_rate_in_context
            
            # Find top contexts
            top_contexts = sorted(context_frequencies.items(), 
                                 key=lambda x: x[1], reverse=True)[:3]
            top_contexts_str = ', '.join([f"{ctx.replace('ctx_', '')}: {rate:.1f}%" 
                                         for ctx, rate in top_contexts])
            
            relation_stats.append({
                'relation': relation.replace('r_', ''),
                'total_occurrences': int(total_count),
                'overall_frequency': f"{total_rate:.2f}%",
                'scenarios_with_relation': f"{n_scenarios_present}/{scenario_counts.shape[0]}",
                'avg_frequency_when_present': f"{avg_rate_when_present:.2f}%",
                'top_contexts': top_contexts_str if top_contexts_str else 'N/A',
                'n_relevant_contexts': len(context_frequencies)
            })
        
        relation_freq_df = pd.DataFrame(relation_stats)
        relation_freq_df = relation_freq_df.sort_values('total_occurrences', ascending=False)
        
        print(f"\nAnalyzed {len(self.relation_cols)} relations")
        print("\nTop 15 most frequent relations:")
        print(relation_freq_df.head(15).to_string(index=False))
        
        # Save to file
        save_dataframe(relation_freq_df, 'LOG_BASED_relation_frequency_analysis.csv')        
        return relation_freq_df
    
    def analyze_relation_anomaly_correlation(self) -> pd.DataFrame:
        """
        Analyze correlation between relations and anomalies vs success.
        
        Returns: DataFrame with correlation statistics
        """
        print("\n" + "=" * 80)
        print("RELATION-ANOMALY CORRELATION ANALYSIS")
        print("=" * 80)
        
        if 'success' not in self.anomaly_vectors.columns:
            print("Warning: 'success' column not found. Skipping correlation analysis.")
            return pd.DataFrame()
        
        correlation_stats = []
        
        # Separate success and failure anomalies
        failures = self.anomaly_vectors[~self.anomaly_vectors['success']]
        successes = self.anomaly_vectors[self.anomaly_vectors['success']]
        
        print(f"\nAnalyzing {len(failures):,} failure anomalies vs {len(successes):,} success anomalies...")
        
        for relation in self.relation_cols:
            # Count in failures
            failure_count = failures[relation].sum()
            failure_rate = failure_count / len(failures) * 100 if len(failures) > 0 else 0
            
            # Count in successes
            success_count = successes[relation].sum()
            success_rate = success_count / len(successes) * 100 if len(successes) > 0 else 0
            
            # Compute lift (how much more likely in failures vs successes)
            if success_rate > 0:
                lift = failure_rate / success_rate
            else:
                lift = float('inf') if failure_rate > 0 else 1.0
            
            # Chi-square test (approximation)
            # Contingency table: [failure_with, failure_without, success_with, success_without]
            failure_without = len(failures) - failure_count
            success_without = len(successes) - success_count
            
            # Expected frequencies
            total = len(failures) + len(successes)
            total_with_rel = failure_count + success_count
            total_without_rel = failure_without + success_without
            
            expected_failure_with = len(failures) * total_with_rel / total
            expected_success_with = len(successes) * total_with_rel / total
            
            # Chi-square statistic (simplified)
            if expected_failure_with > 0 and expected_success_with > 0:
                chi_square = (
                    (failure_count - expected_failure_with) ** 2 / expected_failure_with +
                    (success_count - expected_success_with) ** 2 / expected_success_with
                )
            else:
                chi_square = 0
            
            # Categorize importance
            if lift > 2.0 and failure_rate > 10:
                importance = 'High'
            elif lift > 1.5 and failure_rate > 5:
                importance = 'Medium'
            else:
                importance = 'Low'
            
            correlation_stats.append({
                'relation': relation.replace('r_', ''),
                'failure_occurrences': int(failure_count),
                'failure_rate': f"{failure_rate:.2f}%",
                'success_occurrences': int(success_count),
                'success_rate': f"{success_rate:.2f}%",
                'lift': f"{lift:.2f}x" if lift != float('inf') else 'INF',
                'chi_square': f"{chi_square:.2f}",
                'importance': importance
            })
        
        correlation_df = pd.DataFrame(correlation_stats)
        correlation_df = correlation_df.sort_values('importance', 
                                                    key=lambda x: x.map({'High': 0, 'Medium': 1, 'Low': 2}))
        
        print(f"\nAnalyzed correlations for {len(self.relation_cols)} relations")
        print("\nTop 15 relations most correlated with failures:")
        print(correlation_df.head(15).to_string(index=False))
        
        # Save to file
        save_dataframe(correlation_df, 'LOG_BASED_relation_anomaly_correlation.csv')        
        return correlation_df
    
    def analyze_predictive_power(self, use_full_dataset: bool = False) -> pd.DataFrame:
        """
        Analyze predictive power of relations (TP, FP, TN, FN, precision, recall, F1).
        
        Parameters:
        - use_full_dataset: If True, use full dataset for negatives. If False, use only anomaly points.
        
        Returns: DataFrame with predictive metrics
        """
        print("\n" + "=" * 80)
        print("RELATION PREDICTIVE POWER ANALYSIS")
        print("=" * 80)
        
        if 'has_anomaly' not in self.full_dataset.columns and use_full_dataset:
            print("Warning: 'has_anomaly' column not found in full dataset.")
            use_full_dataset = False
        
        # Prepare dataset
        if use_full_dataset:
            print("\nUsing full dataset (including non-anomaly points)...")
            # Check if relations exist in full dataset
            missing_rels = [r for r in self.relation_cols if r not in self.full_dataset.columns]
            if missing_rels:
                print(f"Warning: {len(missing_rels)} relations not in full dataset. Using anomaly data only.")
                use_full_dataset = False
        
        if use_full_dataset:
            eval_data = self.full_dataset.copy()
            ground_truth = eval_data['has_anomaly'].astype(bool).values
            print(f"  Total points: {len(eval_data):,}")
            print(f"  Anomalies: {ground_truth.sum():,}")
            print(f"  Normal: {(~ground_truth).sum():,}")
        else:
            print("\nUsing anomaly data only (anomaly vs success)...")
            if 'success' not in self.anomaly_vectors.columns:
                print("Error: 'success' column not found. Cannot evaluate predictive power.")
                return pd.DataFrame()
            
            eval_data = self.anomaly_vectors.copy()
            ground_truth = (~eval_data['success']).values  # True = failure, False = success
            print(f"  Total anomaly points: {len(eval_data):,}")
            print(f"  Failures: {ground_truth.sum():,}")
            print(f"  Successes: {(~ground_truth).sum():,}")
        
        predictive_stats = []
        
        for relation in self.relation_cols:
            if relation not in eval_data.columns:
                continue
            
            # Get predictions (relation = True means predicting anomaly/failure)
            predictions = eval_data[relation].astype(bool).values
            
            # Compute confusion matrix
            tn, fp, fn, tp = confusion_matrix(ground_truth, predictions, labels=[False, True]).ravel()
            
            # Compute metrics
            accuracy = (tp + tn) / (tp + tn + fp + fn) if (tp + tn + fp + fn) > 0 else 0
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0
            f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
            specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
            
            # Balanced accuracy (useful for imbalanced data)
            balanced_acc = (recall + specificity) / 2
            
            # Matthews Correlation Coefficient (good for imbalanced data)
            mcc_denom = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
            mcc = (tp * tn - fp * fn) / mcc_denom if mcc_denom > 0 else 0
            
            # Categorize quality
            if f1 > 0.7:
                quality = 'Excellent'
            elif f1 > 0.5:
                quality = 'Good'
            elif f1 > 0.3:
                quality = 'Fair'
            else:
                quality = 'Poor'
            
            predictive_stats.append({
                'relation': relation.replace('r_', ''),
                'TP': int(tp),
                'FP': int(fp),
                'TN': int(tn),
                'FN': int(fn),
                'accuracy': f"{accuracy:.3f}",
                'precision': f"{precision:.3f}",
                'recall': f"{recall:.3f}",
                'f1_score': f"{f1:.3f}",
                'balanced_accuracy': f"{balanced_acc:.3f}",
                'mcc': f"{mcc:.3f}",
                'quality': quality
            })
        
        predictive_df = pd.DataFrame(predictive_stats)
        predictive_df = predictive_df.sort_values('quality', 
                                                  key=lambda x: x.map({'Excellent': 0, 'Good': 1, 'Fair': 2, 'Poor': 3}))
        
        print(f"\nEvaluated {len(self.relation_cols)} relations")
        print("\nTop 15 relations with best predictive power:")
        display_cols = ['relation', 'TP', 'FP', 'FN', 'precision', 'recall', 'f1_score', 'quality']
        print(predictive_df[display_cols].head(15).to_string(index=False))
        
        # Save to file
        save_dataframe(predictive_df, 'LOG_BASED_relation_predictive_power.csv')

        return predictive_df
    
    def analyze_context_specific_performance(self) -> pd.DataFrame:
        """
        Analyze how relations perform in different contexts.
        
        Returns: DataFrame with context-specific metrics
        """
        print("\n" + "=" * 80)
        print("CONTEXT-SPECIFIC RELATION PERFORMANCE")
        print("=" * 80)
        
        if 'success' not in self.anomaly_vectors.columns:
            print("Warning: 'success' column not found. Skipping context analysis.")
            return pd.DataFrame()
        
        context_perf_stats = []
        
        # Analyze top relations in top contexts
        top_relations = self.relation_cols[:10]  # Top 10 relations
        top_contexts = self.context_cols[:10]    # Top 10 contexts
        
        print(f"\nAnalyzing top {len(top_relations)} relations in top {len(top_contexts)} contexts...")
        
        for context in top_contexts:
            # Get data points in this context
            context_mask = self.anomaly_vectors[context] == 1
            context_data = self.anomaly_vectors[context_mask]
            
            if len(context_data) < 10:  # Skip sparse contexts
                continue
            
            context_failures = context_data[~context_data['success']]
            context_successes = context_data[context_data['success']]
            
            for relation in top_relations:
                if relation not in context_data.columns:
                    continue
                
                # Compute metrics in this context
                rel_in_failures = context_failures[relation].sum()
                rel_in_successes = context_successes[relation].sum()
                
                failure_rate = rel_in_failures / len(context_failures) * 100 if len(context_failures) > 0 else 0
                success_rate = rel_in_successes / len(context_successes) * 100 if len(context_successes) > 0 else 0
                
                if success_rate > 0:
                    lift = failure_rate / success_rate
                else:
                    lift = float('inf') if failure_rate > 0 else 1.0
                
                # Only store if significant
                if lift > 1.5 and failure_rate > 10:
                    context_perf_stats.append({
                        'context': context.replace('ctx_', ''),
                        'relation': relation.replace('r_', ''),
                        'context_size': len(context_data),
                        'failures': len(context_failures),
                        'successes': len(context_successes),
                        'failure_rate': f"{failure_rate:.2f}%",
                        'success_rate': f"{success_rate:.2f}%",
                        'lift': f"{lift:.2f}x" if lift != float('inf') else 'INF'
                    })
        
        if not context_perf_stats:
            print("No significant context-specific patterns found.")
            return pd.DataFrame()
        
        context_perf_df = pd.DataFrame(context_perf_stats)
        context_perf_df = context_perf_df.sort_values(['context', 'lift'], ascending=[True, False])
        
        print(f"\nFound {len(context_perf_df)} significant context-relation combinations")
        print("\nTop 20 context-relation combinations:")
        print(context_perf_df.head(20).to_string(index=False))
        
        # Save to file
        save_dataframe(context_perf_df, 'LOG_BASED_context_specific_relation_performance.csv')

        return context_perf_df
    
    def create_comprehensive_visualizations(
        self,
        relation_freq_df: pd.DataFrame,
        correlation_df: pd.DataFrame,
        predictive_df: pd.DataFrame,
        save_prefix: str = 'relation_analysis'
    ):
        """
        Create comprehensive visualizations of all analyses.
        """
        print("\n" + "=" * 80)
        print("CREATING VISUALIZATIONS")
        print("=" * 80)
        
        # Figure 1: Relation Frequency and Correlation
        fig1, axes1 = plt.subplots(2, 2, figsize=(18, 14))
        fig1.suptitle('Relation Generalization Analysis', fontsize=16, fontweight='bold')
        
        # Plot 1: Top 15 most frequent relations
        ax1 = axes1[0, 0]
        top_freq = relation_freq_df.head(15).copy()
        top_freq['overall_frequency_num'] = top_freq['overall_frequency'].str.rstrip('%').astype(float)
        ax1.barh(
            range(len(top_freq)),
            top_freq['overall_frequency_num'],
            color='steelblue'
        )
        ax1.set_yticks(range(len(top_freq)))
        ax1.set_yticklabels(top_freq['relation'], fontsize=9)
        ax1.set_xlabel('Frequency (%)', fontsize=11)
        ax1.set_title('Top 15 Most Frequent Relations', fontsize=12, fontweight='bold')
        ax1.grid(True, alpha=0.3, axis='x')
        ax1.invert_yaxis()
        
        # Plot 2: Relations by importance (correlation)
        ax2 = axes1[0, 1]
        importance_counts = correlation_df['importance'].value_counts()
        colors_importance = {'High': 'red', 'Medium': 'orange', 'Low': 'yellow'}
        ax2.bar(
            importance_counts.index,
            importance_counts.values,
            color=[colors_importance.get(k, 'gray') for k in importance_counts.index]
        )
        ax2.set_xlabel('Importance Level', fontsize=11)
        ax2.set_ylabel('Number of Relations', fontsize=11)
        ax2.set_title('Relations by Failure Correlation', fontsize=12, fontweight='bold')
        ax2.grid(True, alpha=0.3, axis='y')
        
        # Add counts on bars
        for i, (idx, val) in enumerate(importance_counts.items()):
            ax2.text(i, val + 0.5, str(val), ha='center', fontsize=11, fontweight='bold')
        
        # Plot 3: Predictive quality distribution
        ax3 = axes1[1, 0]
        quality_counts = predictive_df['quality'].value_counts()
        colors_quality = {'Excellent': 'green', 'Good': 'lightgreen', 'Fair': 'orange', 'Poor': 'red'}
        ax3.bar(
            quality_counts.index,
            quality_counts.values,
            color=[colors_quality.get(k, 'gray') for k in quality_counts.index]
        )
        ax3.set_xlabel('Predictive Quality', fontsize=11)
        ax3.set_ylabel('Number of Relations', fontsize=11)
        ax3.set_title('Relations by Predictive Power', fontsize=12, fontweight='bold')
        ax3.grid(True, alpha=0.3, axis='y')
        
        # Add counts on bars
        for i, (idx, val) in enumerate(quality_counts.items()):
            ax3.text(i, val + 0.5, str(val), ha='center', fontsize=11, fontweight='bold')
        
        # Plot 4: Precision-Recall scatter
        ax4 = axes1[1, 1]
        if not predictive_df.empty:
            predictive_df_copy = predictive_df.copy()
            predictive_df_copy['precision_num'] = predictive_df_copy['precision'].astype(float)
            predictive_df_copy['recall_num'] = predictive_df_copy['recall'].astype(float)
            predictive_df_copy['f1_num'] = predictive_df_copy['f1_score'].astype(float)
            
            scatter = ax4.scatter(
                predictive_df_copy['recall_num'],
                predictive_df_copy['precision_num'],
                c=predictive_df_copy['f1_num'],
                s=100,
                cmap='RdYlGn',
                vmin=0,
                vmax=1,
                edgecolors='black',
                linewidth=0.5,
                alpha=0.7
            )
            plt.colorbar(scatter, ax=ax4, label='F1 Score')
            
            # Add diagonal line (F1 = 0.5)
            ax4.plot([0, 1], [0, 1], 'k--', alpha=0.3, linewidth=1)
            
            ax4.set_xlabel('Recall', fontsize=11)
            ax4.set_ylabel('Precision', fontsize=11)
            ax4.set_title('Precision-Recall Trade-off', fontsize=12, fontweight='bold')
            ax4.grid(True, alpha=0.3)
            ax4.set_xlim(-0.05, 1.05)
            ax4.set_ylim(-0.05, 1.05)
        
        plt.tight_layout()
        save_figure(f'LOG_BASED_{save_prefix}_overview.png')
        plt.close()
        
        # Figure 2: Detailed predictive metrics
        fig2, axes2 = plt.subplots(1, 2, figsize=(16, 6))
        fig2.suptitle('Detailed Predictive Metrics', fontsize=16, fontweight='bold')
        
        # Plot 1: Top relations by F1 score
        ax1 = axes2[0]
        top_f1 = predictive_df.head(15).copy()
        top_f1['f1_num'] = top_f1['f1_score'].astype(float)
        colors_f1 = plt.cm.RdYlGn(top_f1['f1_num'])
        
        ax1.barh(
            range(len(top_f1)),
            top_f1['f1_num'],
            color=colors_f1
        )
        ax1.set_yticks(range(len(top_f1)))
        ax1.set_yticklabels(top_f1['relation'], fontsize=9)
        ax1.set_xlabel('F1 Score', fontsize=11)
        ax1.set_title('Top 15 Relations by F1 Score', fontsize=12, fontweight='bold')
        ax1.grid(True, alpha=0.3, axis='x')
        ax1.set_xlim(0, 1)
        ax1.invert_yaxis()
        
        # Plot 2: Confusion matrix for best relation
        ax2 = axes2[1]
        if not predictive_df.empty:
            best_rel = predictive_df.iloc[0]
            cm_data = [
                [int(best_rel['TN']), int(best_rel['FP'])],
                [int(best_rel['FN']), int(best_rel['TP'])]
            ]
            
            sns.heatmap(
                cm_data,
                annot=True,
                fmt='d',
                cmap='Blues',
                xticklabels=['Predicted Normal', 'Predicted Anomaly'],
                yticklabels=['Actual Normal', 'Actual Anomaly'],
                ax=ax2,
                cbar_kws={'label': 'Count'}
            )
            ax2.set_title(f'Best Relation: {best_rel["relation"]}\n'
                         f'F1={best_rel["f1_score"]}, Precision={best_rel["precision"]}, Recall={best_rel["recall"]}',
                         fontsize=12, fontweight='bold')
        
        plt.tight_layout()
        save_figure(f'LOG_BASED_{save_prefix}_predictive_detail.png')
        plt.close()
    
    def generate_summary_report(
        self,
        relation_freq_df: pd.DataFrame,
        correlation_df: pd.DataFrame,
        predictive_df: pd.DataFrame,
        context_perf_df: Optional[pd.DataFrame] = None
    ) -> str:
        """
        Generate a comprehensive text summary report.
        
        Returns: Report text
        """
        report_lines = []
        report_lines.append("=" * 80)
        report_lines.append("RELATION GENERALIZATION SUMMARY REPORT")
        report_lines.append("=" * 80)
        report_lines.append("")
        
        # Overall statistics
        report_lines.append("OVERALL STATISTICS:")
        report_lines.append("-" * 80)
        report_lines.append(f"Total relations analyzed: {len(self.relation_cols)}")
        report_lines.append(f"Total anomaly data points: {len(self.anomaly_vectors):,}")
        report_lines.append(f"Total scenarios: {self.anomaly_vectors['scenario_id'].nunique()}")
        report_lines.append(f"Total contexts: {len(self.context_cols)}")
        report_lines.append("")
        
        # Frequency insights
        report_lines.append("FREQUENCY INSIGHTS:")
        report_lines.append("-" * 80)
        top_5_freq = relation_freq_df.head(5)
        report_lines.append("Top 5 most frequent relations:")
        for idx, row in top_5_freq.iterrows():
            report_lines.append(f"  {idx+1}. {row['relation']}: {row['overall_frequency']} "
                              f"({row['total_occurrences']:,} occurrences)")
        report_lines.append("")
        
        # Correlation insights
        report_lines.append("CORRELATION INSIGHTS:")
        report_lines.append("-" * 80)
        high_importance = correlation_df[correlation_df['importance'] == 'High']
        report_lines.append(f"Relations highly correlated with failures: {len(high_importance)}")
        report_lines.append("Top 5 failure predictors:")
        for idx, row in high_importance.head(5).iterrows():
            report_lines.append(f"  {idx+1}. {row['relation']}: "
                              f"{row['failure_rate']} in failures vs {row['success_rate']} in successes "
                              f"(lift: {row['lift']})")
        report_lines.append("")
        
        # Predictive power insights
        report_lines.append("PREDICTIVE POWER INSIGHTS:")
        report_lines.append("-" * 80)
        excellent_rels = predictive_df[predictive_df['quality'] == 'Excellent']
        good_rels = predictive_df[predictive_df['quality'] == 'Good']
        report_lines.append(f"Excellent predictors: {len(excellent_rels)}")
        report_lines.append(f"Good predictors: {len(good_rels)}")
        report_lines.append("Top 5 relations by F1 score:")
        for idx, row in predictive_df.head(5).iterrows():
            report_lines.append(f"  {idx+1}. {row['relation']}: "
                              f"F1={row['f1_score']}, Precision={row['precision']}, Recall={row['recall']}")
        report_lines.append("")
        
        # Context-specific insights
        if context_perf_df is not None and not context_perf_df.empty:
            report_lines.append("CONTEXT-SPECIFIC INSIGHTS:")
            report_lines.append("-" * 80)
            report_lines.append(f"Significant context-relation combinations: {len(context_perf_df)}")
            report_lines.append("Top 5 context-relation patterns:")
            for idx, row in context_perf_df.head(5).iterrows():
                report_lines.append(f"  {idx+1}. {row['context']} + {row['relation']}: "
                                  f"{row['failure_rate']} (lift: {row['lift']})")
            report_lines.append("")
        
        # Recommendations
        report_lines.append("RECOMMENDATIONS:")
        report_lines.append("-" * 80)
        
        # Best relations for monitoring
        best_overall = set(high_importance.head(5)['relation'].values) & set(excellent_rels.head(5)['relation'].values)
        if best_overall:
            report_lines.append("Relations recommended for monitoring systems:")
            for rel in best_overall:
                report_lines.append(f"  - {rel}")
        
        # Relations needing improvement
        poor_rels = predictive_df[predictive_df['quality'] == 'Poor']
        if len(poor_rels) > 0:
            report_lines.append(f"\nRelations with poor predictive power ({len(poor_rels)}): Consider refinement or removal")
        
        report_lines.append("")
        report_lines.append("=" * 80)
        
        report_text = "\n".join(report_lines)
        
        # Save to file
        with open(OUTPUT_DIR / 'LOG_BASED_relation_generalization_report.txt', 'w') as f:
            f.write(report_text)

        print("\n Saved: LOG_BASED_relation_generalization_report.txt")

        return report_text

