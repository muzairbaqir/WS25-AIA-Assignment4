from setup.config import *
 
# =========================
# Data Classes
# =========================

class RunData:
    def __init__(self, run_id, scenario_id, run_path):
        self.run_id = run_id
        self.scenario_id = scenario_id
        self.run_path = run_path

        # Lazy loading caches
        self._poses = None
        self._behaviors = None
        self._rosbag = None
        self._logs = None   

        # Outcome caches
        self._success = None           # Strictly based on behaviors.csv
        self._classification = None   # Semantic reason from logs
        self._anomalies = None        # List of detected patterns from logs
        self._anomaly_timestamps_and_poses = None   # List of dictionaries contains the anomaly timestamp and postion

    @property
    def logs(self):
        if self._logs is None:
            self._logs = load_csv_if_exists(self.run_path /"logs"/ "system.log")
        return self._logs

    @property
    def poses(self):
        if self._poses is None:
            self._poses = load_csv_if_exists(self.run_path / "poses.csv")
        return self._poses

    @property
    def behaviors(self):
        if self._behaviors is None:
            self._behaviors = load_csv_if_exists(self.run_path / "behaviors.csv")
        return self._behaviors

    @property
    def rosbag(self):
        if self._rosbag is None:
            self._rosbag = load_csv_if_exists(self.run_path / "rosbag2.csv")
        return self._rosbag

    @property
    def success(self):
        """Strictly follows the Old Code: Outcome based on behaviors.csv last row."""
        if self._success is None:
            behaviors_df = self.behaviors
            if behaviors_df is not None and not behaviors_df.empty:
                last_row = behaviors_df.iloc[-1]
                # Check for 'fail' or 'failure' in any column of the last row
                last_row_str = ' '.join(str(val).lower() for val in last_row.values)
                if "fail" in last_row_str or "failure" in last_row_str:
                    self._success = False
                else:
                    self._success = True
            else:
                self._success = None
        return self._success

    def _parse_logs_metadata(self):
        """Processes logs for semantic info (classification) without affecting success label."""
        if self._classification is None:
            _, log_class, log_anomalies, log_anomaly_timestamps_and_poses = parse_system_log(self.run_path / "logs")
            self._classification = log_class
            self._anomalies = log_anomalies
            self._anomaly_timestamps_and_poses = log_anomaly_timestamps_and_poses

    @property
    def classification(self):
        """Returns semantic failure mode (e.g. 'Planner Error') for Assignment 03 analysis."""
        self._parse_logs_metadata()
        return self._classification

    @property
    def anomaly_types(self):
        """Returns specific anomaly patterns found in logs."""
        self._parse_logs_metadata()
        return self._anomalies
    
    @property
    def anomaly_timestamps_and_poses(self):
        self._parse_logs_metadata()
        return self._anomaly_timestamps_and_poses

class ScenarioData:
    def __init__(self, scenario_id, scenario_path):
        self.scenario_id = scenario_id
        self.scenario_path = scenario_path
        self.map_variations = []
        self.parameters = {}
        self.runs = []

# =========================
# Loaders
# =========================

def load_dataset(root_dir: str):
    root = Path(root_dir)
    scenarios = []
    for scenario_path in sorted(root.iterdir()):
        if scenario_path.is_dir():
            scenario = load_scenario(scenario_path)
            scenarios.append(scenario)
    return scenarios

def load_scenario(scenario_path: Path) -> ScenarioData:
    scenario = ScenarioData(scenario_id=scenario_path.name, scenario_path=scenario_path)
    config_path = scenario_path /"0"/"scenario.config"
    if config_path.exists():
        scenario.parameters = parse_scenario_config(config_path)
    scenario.map_variations = discover_maps(scenario_path,scenario.parameters)
    for run_path in sorted(scenario_path.iterdir()):
        if run_path.is_dir() and run_path.name.isdigit():
            run = RunData(run_id=run_path.name, scenario_id=scenario.scenario_id, run_path=run_path)
            scenario.runs.append(run)
    return scenario

#####################################################
def scenario_name_to_label(scenario_name: str) -> str:
    """
    Converts scenario folder names to a human-readable label:
    - 'small-dataset-maps-0-3-door-width-1f1-1'   -> '0.3 door width'
    - 'small-dataset-maps-0-33-door-width-1f1-2'  -> '0.33 door width'
    - 'small-dataset-maps-door-size-0-5-1f1-6'    -> 'door_size_0.5'
    """
    if "0-3-door-width" in scenario_name:
        return "0.3 door width"
    elif "0-33-door-width" in scenario_name:
        return "0.33 door width"
    elif "0-36-door-width" in scenario_name:
        return "0.36 door width"
    elif "0-44-door-width" in scenario_name:
        return "0.44 door width"
    elif "0-47-door-width" in scenario_name:
        return "0.47 door width"
    elif "door-size-0-5" in scenario_name:
        return "door_size_0.5"
    elif "hallway-window-0-2" in scenario_name:
        return "hallway_window_0.2"
    elif "room-size-less-50" in scenario_name:
        return "room_size_less_50"
    
    return scenario_name


def discover_maps(scenario_path: Path, scenario_parameters: dict) -> List[dict]:
    """
    Looks for a subfolder in small_dataset_maps whose label matches the scenario's label,
    and collects map files from that subfolder. Adds a human-readable label for each variation.
    """
    maps = []
    maps_root = scenario_path / "0" / "small_dataset_maps"
    if not maps_root.exists():
        return maps

    scenario_label = scenario_name_to_label(scenario_path.name)
    matching_folder = maps_root / scenario_label 
    
    if matching_folder.exists() and matching_folder.is_dir():
        map_path = matching_folder/"maps"
        yaml_files = list(map_path.glob("*.yaml"))
        pgm_files = list(map_path.glob("*.pgm"))
        door_width = parse_door_width_from_name(matching_folder.name)
        label = scenario_name_to_label(matching_folder.name)
        maps.append({
            "label": label,
            "map_yaml": yaml_files[0] if yaml_files else None,
            "map_pgm": pgm_files[0] if pgm_files else None,
            "door_width": door_width
        })
    else:
        pass
    return maps

def parse_door_width_from_name(folder_name: str):
    match = re.search(r"(\d+(\.\d+)?)", folder_name)
    if match:
        return float(match.group(1))
    return None

def parse_scenario_config(config_path):
    """
    Parses a scenario.config YAML file and returns a dictionary with scenario details.
    """
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)

    scenario = config.get('test_scenario', {})

    # Extract start pose
    start_pose = scenario.get('start_pose', {})
    start_position = start_pose.get('position', {})
    start_orientation = start_pose.get('orientation', {})

    # Extract goal poses
    goal_poses = []
    for goal in scenario.get('goal_poses', []):
        position = goal.get('position', {})
        orientation = goal.get('orientation', {})
        goal_poses.append({
            'position': position,
            'orientation': orientation
        })

    # Extract other fields
    laserscan_gaussian_noise_std_deviation = float(scenario.get('laserscan_gaussian_noise_std_deviation', 0.0))
    laserscan_random_drop_percentage = float(scenario.get('laserscan_random_drop_percentage', 0.0))
    map_file = scenario.get('map_file', '')
    mesh_file = scenario.get('mesh_file', '')

    return {
        'start_pose': {
            'position': start_position,
            'orientation': start_orientation
        },
        'goal_poses': goal_poses,
        'laserscan_gaussian_noise_std_deviation': laserscan_gaussian_noise_std_deviation,
        'laserscan_random_drop_percentage': laserscan_random_drop_percentage,
        'map_file': map_file,
        'mesh_file': mesh_file
    }

# =========================
# Log Classification Logic (For semantic context)
# =========================

def classify_outcome(anomalies: List[str]) -> Tuple[str, str]:
    """Classify outcome based on anomalies."""
    if not anomalies:
        return "UNKNOWN", "No anomalies detected"
    if any("Goal reached" in a for a in anomalies):
        return "SUCCESS", "Goal reached"
    if any("Planning Failure" in a for a in anomalies):
        return "FAILED", "RUNTIME ERROR - Planner Error"
    if any("Spin Timeout" in a for a in anomalies):
        return "FAILED", "RUNTIME ERROR - Movement Error"
    if any("No Progress" in a or "Sim Timeout" in a or "Scenario Abort" in a for a in anomalies):
        return "FAILED", "RUNTIME ERROR - Execution Error"
    if any("Invalid Model or sdf" in a or "Missing mesh or world" in a for a in anomalies):
        return "FAILED", "CONFIG ERROR - Setup Error"
    if any("Map load failure" in a or "tf tree missing" in a for a in anomalies):
        return "FAILED", "CONFIG ERROR - Bringup Error"
    
    return "FAILED", "Unclassified Failure"

def quaternion_to_yaw(qw, qx, qy, qz):
    yaw = math.atan2(
        2.0 * (qw * qz + qx * qy),
        1.0 - 2.0 * (qy * qy + qz * qz)
    )
    return yaw  # radians

def get_gt_pose_from_csv(csv_path: Path, timestamp: float) -> dict:
    gt_pose = {"gt_pose_x": None, "gt_pose_y": None, "gt_orientation_yaw": None}
    if csv_path.exists():
        gt_df = pd.read_csv(csv_path)
        if 'transforms[0].header.stamp.sec' in gt_df.columns and 'transforms[0].header.stamp.nanosec' in gt_df.columns:
            gt_df['timestamp'] = gt_df['transforms[0].header.stamp.sec'] + gt_df['transforms[0].header.stamp.nanosec'] * 1e-9
            time_diffs = np.abs(gt_df['timestamp'] - timestamp)
            closest_idx = time_diffs.idxmin()
            closest_row = gt_df.iloc[closest_idx]
            qw = closest_row['transforms[0].transform.rotation.w']
            qx = closest_row['transforms[0].transform.rotation.x']
            qy = closest_row['transforms[0].transform.rotation.y']
            qz = closest_row['transforms[0].transform.rotation.z']
            yaw = quaternion_to_yaw(qw, qx, qy, qz)
            gt_pose["gt_pose_x"] = round(float(closest_row['transforms[0].transform.translation.x']), 3)
            gt_pose["gt_pose_y"] = round(float(closest_row['transforms[0].transform.translation.y']), 3)
            gt_pose["gt_orientation_yaw"] = round(float(yaw), 3)
        return gt_pose

def parse_system_log(logs_dir: Path) -> Tuple[str, str, List[str], List[dict]]:
    anomalies = []
    system_log_path = logs_dir / "system.log"
    if system_log_path.exists():
        with open(system_log_path, "r", errors="ignore") as f:
                    for line in f:
                        for pat, anomaly_type in LOG_RULES:
                            if pat.search(line):
                                match = re.search(r"\[([0-9]+\.[0-9]+)\]", line)
                                if match:
                                    timestamp = float(match.group(1))
                                    csv_path = logs_dir.parent / "rosbag2.csv"
                                    gt_pose = get_gt_pose_from_csv(csv_path, timestamp)
                                    timestamp = round(timestamp, 3)
                                else :
                                    timestamp = None
                                    gt_pose = {"gt_pose_x": None, "gt_pose_y": None, "gt_orientation_yaw": None}
                                anomalies.append({
                                    "anomaly_type": anomaly_type,
                                    "timestamp": timestamp,
                                    "gt_pose_x": gt_pose["gt_pose_x"],
                                    "gt_pose_y": gt_pose["gt_pose_y"],
                                    "gt_orientation_yaw": gt_pose["gt_orientation_yaw"]
                                })
    if not anomalies:
        return "UNKNOWN", "No anomalies detected", [], []
    else:
        unique_anomaly_types = list({a["anomaly_type"] for a in anomalies})
        run_result, result_class = classify_outcome(unique_anomaly_types)
        return run_result, result_class, unique_anomaly_types, anomalies