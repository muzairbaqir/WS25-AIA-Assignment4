from setup.config import *

def build_scenario_gt_from_logs(
    logs_csv: str | Path,
    gt_anomaly_type: str = "No Progress",
) -> pd.DataFrame:
    """
    Builds scenario-level *ground truth* from the log-based anomaly CSV.

    For each scenario:
        gt_no_progress_any = 1
            if ANY run in that scenario has anomaly_type == gt_anomaly_type
        else 0

    This collapses many runs into one label per scenario.
    """

    logs_csv = Path(logs_csv)
    if not logs_csv.exists():
        raise FileNotFoundError(f"Missing: {logs_csv}")

    # Load log-based anomalies
    logs_df = pd.read_csv(logs_csv)

    # Validate required columns
    need = {"scenario_id", "anomaly_type"}
    if not need.issubset(set(logs_df.columns)):
        raise ValueError(f"{logs_csv} must contain columns: {sorted(need)}")

    # Mark rows where the target anomaly appears
    logs_df["is_hit"] = (
        logs_df["anomaly_type"]
        .astype(str)
        .eq(gt_anomaly_type)
        .astype(int)
    )

    # Aggregate per scenario: if ANY run has the anomaly → 1
    gt = (
        logs_df
        .groupby("scenario_id", as_index=False)["is_hit"]
        .max()
        .rename(columns={"is_hit": "gt_no_progress_any"})
    )

    return gt


def build_pred_df(
    scenario_predictions: List[Dict[str, Any]],
) -> pd.DataFrame:
    """
    Converts scenario-based model outputs into a DataFrame.

    Each dict in scenario_predictions must contain:
        - scenario_id
        - pred_stuck_any (0 or 1)

    Returns:
        DataFrame with columns: [scenario_id, pred_stuck_any]
    """

    if not scenario_predictions:
        # Return empty but valid schema
        return pd.DataFrame(columns=["scenario_id", "pred_stuck_any"])

    pred_df = pd.DataFrame(scenario_predictions)

    # Validate required fields
    need = {"scenario_id", "pred_stuck_any"}
    if not need.issubset(set(pred_df.columns)):
        raise ValueError(f"scenario_predictions must contain keys: {sorted(need)}")

    # Keep only relevant columns and normalize types
    pred_df = pred_df[["scenario_id", "pred_stuck_any"]].copy()
    pred_df["scenario_id"] = pred_df["scenario_id"].astype(str)
    pred_df["pred_stuck_any"] = pred_df["pred_stuck_any"].fillna(0).astype(int)

    return pred_df


def compute_confusion(cmp_df: pd.DataFrame) -> Tuple[int, int, int, int, float, float]:
    """
    Computes confusion-matrix metrics from the merged comparison table.

    Returns:
        tp, fp, fn, tn, precision, recall
    """

    tp = int(((cmp_df.gt_no_progress_any == 1) & (cmp_df.pred_stuck_any == 1)).sum())
    fp = int(((cmp_df.gt_no_progress_any == 0) & (cmp_df.pred_stuck_any == 1)).sum())
    fn = int(((cmp_df.gt_no_progress_any == 1) & (cmp_df.pred_stuck_any == 0)).sum())
    tn = int(((cmp_df.gt_no_progress_any == 0) & (cmp_df.pred_stuck_any == 0)).sum())

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0

    return tp, fp, fn, tn, precision, recall


def evaluate_scenario_level(
    logs_csv: str | Path,
    scenario_predictions: List[Dict[str, Any]],
    out_csv: str | Path = "scenario_level_comparison.csv",
    gt_anomaly_type: str = "No Progress",
) -> dict:
    """
    Full scenario-level evaluation pipeline.

    Steps:
        1) Build ground truth from logs (ANY No Progress per scenario)
        2) Build predictions from scenario-based model
        3) Merge GT and predictions on scenario_id
        4) Compute confusion matrix metrics
        5) Save merged table to CSV

    Returns:
        dict with metrics + output CSV path
    """

    out_csv = OUTPUT_DIR / out_csv
    logs_csv = OUTPUT_DIR / logs_csv
    # Build GT from logs
    gt = build_scenario_gt_from_logs(logs_csv, gt_anomaly_type=gt_anomaly_type)

    # Build predictions from scenario-based model
    pred_df = build_pred_df(scenario_predictions)

    # Merge both into one table
    cmp_df = gt.merge(pred_df, on="scenario_id", how="outer")

    # Fill missing values (scenarios not present in one side)
    cmp_df["gt_no_progress_any"] = cmp_df["gt_no_progress_any"].fillna(0).astype(int)
    cmp_df["pred_stuck_any"] = cmp_df["pred_stuck_any"].fillna(0).astype(int)

    # Save merged comparison
    cmp_df.to_csv(out_csv, index=False)

    # Compute metrics
    tp, fp, fn, tn, precision, recall = compute_confusion(cmp_df)

    return {
        "out_csv": str(out_csv),
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "precision": round(float(precision), 3),
        "recall": round(float(recall), 3),
    }