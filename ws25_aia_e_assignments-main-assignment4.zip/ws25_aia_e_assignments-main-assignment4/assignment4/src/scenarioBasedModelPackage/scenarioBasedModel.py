from setup.config import *
from src.logBasedPackage.context import SpatialContextMapper
from .scenarioHelper.helper import (
    start_out_of_map, goal_out_of_map, start_obs_overlap, goal_obs_overlap,
    infer_map_name_from_map_file,
    parse_length_to_m,
    get_map_info,
    get_space_name_for_point,
    min_wall_clearance,
    list_doors,
    euclidean_xy,
)

"""
This module defines the scenarioBasedModelClass which provides functionality
to analyze and predict navigation anomalies in robot scenarios based on
map, robot, and scenario configuration data. It performs checks on the scenario,
extracts environmental features, and applies heuristic rules to detect
potential navigation risks or anomalies before actual path execution.
"""

class scenarioBasedModelClass:
    WALL_TIGHT_THRESHOLD = 0.40
    WALL_DANGER_THRESHOLD = 0.25
    HIGH_LIDAR_NOISE = 0.05
    FAIL_SCORE_THRESHOLD = 0.5  # tune later


    def __init__(self,allConfigs):
        """
        Initialize the scenario model with configuration dictionaries containing
        scenario, map, and robot details. Also initializes a SpatialContextMapper
        for spatial queries related to the map.
        """
        # Store configuration dictionaries and scenario identifiers
        self.config = allConfigs["config"]
        self.map_details = allConfigs["map_details"]
        self.robot_details = allConfigs["robot_details"]
        self.scenario_path = allConfigs.get("scenario_path")
        self.scenario_id = allConfigs.get("scenario_id")
        # Initialize spatial context mapper for map-related queries
        self.mapper = SpatialContextMapper(self.map_details)

    def basicMapChecks(self):
        """
        Perform basic presence checks to ensure that the essential configuration
        files (config, map_details, robot_details) are loaded and not None.
        Returns True if all required data are present, False otherwise.
        """
        # Retrieve references to config data
        configFile = self.config
        mapDetailsFile = self.map_details
        robotDetailsFile = self.robot_details

        # Check presence of all required configuration data
        if configFile != None and mapDetailsFile != None and robotDetailsFile != None:
            #logger.info("All the data are Present. Can run Scenario Based Model")
            return True
        else:
            return False

    def basicInformationChecks(self):
        """
        Perform initial sanity checks on scenario spatial information:
        - Verify that start and goal positions lie within the map boundaries.
        - Check that start and goal poses do not overlap with static obstacles.
        Returns a dictionary with status and reasons for failure if any.
        """
        # Infer map name from the map file specified in config
        map_name = infer_map_name_from_map_file(self.config["map_file"])

        # Extract start pose, goal poses, and static obstacles from config
        start_pose = self.config["start_pose"]
        goal_poses = self.config["goal_poses"]
        static_objects = self.config.get("static_objects", [])
        
        reasons = []

        # Check if start position is outside map boundaries
        if start_out_of_map(start_pose, self.mapper, map_name):
            reasons.append("Start out of map")

        # Check if any goal position is outside map boundaries
        if goal_out_of_map(goal_poses, self.mapper, map_name):
            reasons.append("Goal out of map")

        # Check if any goal position overlaps with static obstacles
        if goal_obs_overlap(goal_poses, self.mapper, map_name, static_objects):
            reasons.append("Goal obs overlap")

        # Check if start position overlaps with static obstacles
        if start_obs_overlap(start_pose, self.mapper, map_name, static_objects):
            reasons.append("Start obs overlap")

        # If any checks failed, return failure status with reasons
        if reasons:
            return {
                "Status": "Failure",
                "Scenario": self.scenario_id,
                "map_name" : map_name,
                "Reasons": reasons,
            }

        # All checks passed
        return {
            "Run Status": "OK",
            "Scenario": self.scenario_id,
            "map_name" : map_name,
        }

    def makeEnvFeatures(self):
        """
        Extract and compute a set of environmental features from the scenario,
        map, and robot configurations. These features characterize the scenario's
        spatial complexity, robot geometry constraints, door widths, clearance
        near walls, and estimated path length (geometric proxy).
        Returns a dictionary of environment features or failure status.
        """
        # Determine the map name from the config's map file
        map_name = infer_map_name_from_map_file(self.config.get("map_file", ""))
        # Retrieve detailed map information from map_details by map name
        map_info = get_map_info(self.map_details, map_name)
        if map_info is None:
            return {
                "Status": "Failure",
                "Scenario": self.scenario_id,
                "map_name": map_name,
                "Reasons": ["Unknown map_name (not found in maps_details.json)"],
            }

        # Parse robot geometry dimensions (width, length, height) in meters
        # Defaults provided just in case
        robot_w = parse_length_to_m(self.robot_details.get("width")) or 0.339
        robot_l = parse_length_to_m(self.robot_details.get("length")) or 0.342
        robot_h = parse_length_to_m(self.robot_details.get("height")) or 0.192

        # side_margin_m defines a safety margin on each side of the robot (3cm)
        # required_door_width_m is the minimum door width needed for robot clearance
        side_margin_m = 0.03  # 3cm per side
        required_door_width_m = robot_w + 2 * side_margin_m

        # Extract start and goal poses from config
        start_pose = self.config.get("start_pose", {})
        goal_poses = self.config.get("goal_poses", [])

        # Extract x,y coordinates of start pose
        sx = float(start_pose.get("position", {}).get("x", 0.0))
        sy = float(start_pose.get("position", {}).get("y", 0.0))

        # Construct a list of (x,y) tuples for each goal pose
        # This represents the target waypoints for the robot
        goals_xy = []
        for g in goal_poses:
            gx = float(g.get("position", {}).get("x", 0.0))
            gy = float(g.get("position", {}).get("y", 0.0))
            goals_xy.append((gx, gy))

        # Determine the room/space name for start and goal positions
        # These provide contextual information about spatial layout
        start_room = get_space_name_for_point(self.mapper, map_name, sx, sy)
        goal_rooms = [get_space_name_for_point(self.mapper, map_name, gx, gy) for gx, gy in goals_xy]
        # Sequence of rooms the robot will traverse: start room + all goal rooms
        seq_rooms = [start_room] + goal_rooms
        # Count how many times the robot transitions between different rooms
        n_room_transitions = sum(1 for i in range(1, len(seq_rooms)) if seq_rooms[i] != seq_rooms[i - 1])
        # Set of unique rooms in the sequence, excluding unknown or invalid map names
        unique_rooms = sorted(set(r for r in seq_rooms if r not in ("Unknown_Map",)))

        # Retrieve door information from the map
        doors = list_doors(map_info)
        # Extract door widths in meters
        door_widths = [d["width_m"] for d in doors]
        # Minimum door width among all doors, or None if no doors
        min_door_w = min(door_widths) if door_widths else None
        # Count how many doors are narrower than the required door width
        n_narrow_doors = sum(1 for w in door_widths if w < required_door_width_m) if door_widths else 0
        # Boolean indicating if there exists at least one impassable door (too narrow)
        has_impassable_door = (min_door_w is not None) and (min_door_w < required_door_width_m)

        # Compute minimum clearance from walls at start and goal positions
        start_clear = min_wall_clearance(map_info, sx, sy)
        goal_clears = [min_wall_clearance(map_info, gx, gy) for gx, gy in goals_xy]
        # Filter out None clearances at goals
        goal_clears_num = [c for c in goal_clears if c is not None]
        # Minimum clearance among all goals
        min_goal_clear = min(goal_clears_num) if goal_clears_num else None

        # Compute estimated path length as sum of straight-line distances between waypoints
        # This is a geometric proxy for path length; no actual path planning performed here
        waypoints = [(sx, sy)] + goals_xy
        seg_lengths = [
            euclidean_xy(waypoints[i][0], waypoints[i][1], waypoints[i+1][0], waypoints[i+1][1])
            for i in range(len(waypoints) - 1)
        ]
        estimated_path_length_m = float(sum(seg_lengths)) if seg_lengths else 0.0

        # ------------------------------------------------------------
        # Door widths per space (room) for "start-room door" / "goal-room door" rules
        # ------------------------------------------------------------
        door_widths_by_space = {}
        for d in doors:
            sname = d.get("space_name", "unknown")
            w = d.get("width_m", None)
            if w is None:
                continue
            door_widths_by_space.setdefault(sname, []).append(float(w))

        # Minimum door width for the START room (None if no door info for that space)
        start_room_door_widths = door_widths_by_space.get(start_room, [])
        start_room_min_door_width_m = min(start_room_door_widths) if start_room_door_widths else None

        # Minimum door width for EACH GOAL room (aligned with goal_rooms list)
        goal_room_min_door_widths_m = []
        for gr in goal_rooms:
            ws = door_widths_by_space.get(gr, [])
            goal_room_min_door_widths_m.append(min(ws) if ws else None)

        # start_room != goal_room (otherwise do not activate)
        # and BOTH start-room and goal-room doors are narrower than robot width
        # Here we implement the condition: door_width < robot_width_m.
        start_goal_room_doors_too_narrow = []
        for gr, gr_min_w in zip(goal_rooms, goal_room_min_door_widths_m):
            if gr == start_room:
                start_goal_room_doors_too_narrow.append(False)  # explicitly disabled if same room
                continue
            if start_room_min_door_width_m is None or gr_min_w is None:
                start_goal_room_doors_too_narrow.append(False)  # no info => don't claim 100% failure
                continue
            start_goal_room_doors_too_narrow.append(
                (start_room_min_door_width_m < robot_w) or (gr_min_w < robot_w)
            )

        # Any goal triggers the "100% failure" clause
        any_start_goal_room_doors_too_narrow = any(start_goal_room_doors_too_narrow)

        # Compose environment features dictionary to return
        env = {
            "Status": "OK",
            "Scenario": self.scenario_id,
            "map_name": map_name,

            "robot_width_m": robot_w,
            "robot_length_m": robot_l,
            "robot_height_m": robot_h,
            "side_margin_m": side_margin_m,
            "required_door_width_m": required_door_width_m,

            "n_goals": len(goals_xy),
            "start_room": start_room,
            "goal_rooms": goal_rooms,
            "unique_rooms_on_sequence": unique_rooms,
            "n_room_transitions": n_room_transitions,

            "n_doors": len(doors),
            "min_door_width_m": min_door_w,
            "n_narrow_doors": n_narrow_doors,
            "has_impassable_door": bool(has_impassable_door),

            "start_wall_clearance_m": start_clear,
            "min_goal_wall_clearance_m": min_goal_clear,

            "estimated_path_length_m": estimated_path_length_m,

            # Include laser scan noise parameters from config for anomaly detection
            "lidar_noise_std": float(self.config.get("laserscan_gaussian_noise_std_deviation", 0.0) or 0.0),
            "lidar_random_drop_pct": float(self.config.get("laserscan_random_drop_percentage", 0.0) or 0.0),

            # Per-room door info
            "start_room_min_door_width_m": start_room_min_door_width_m,
            "goal_room_min_door_widths_m": goal_room_min_door_widths_m,
            "start_goal_room_doors_too_narrow_flags": start_goal_room_doors_too_narrow,
            "any_start_goal_room_doors_too_narrow": bool(any_start_goal_room_doors_too_narrow),
        }

        #logger.info("\n" + pformat(env, width=120) + "\n")
        return env

    def detectPossibleAnomalies(self, env: dict):
        """
        Perform scenario-level possible-anomalies prediction based on extracted
        environmental features. Applies heuristic rules that map feature predicates
        to predicted anomaly types, along with explanations and evidence.
        Returns a dictionary summarizing predicted anomalies and a heuristic risk score.
        """
        # Return failure if environment features are missing or invalid
        if not env or env.get("Status") != "OK":
            return {
                "Status": "Failure",
                "Scenario": self.scenario_id,
                "Reasons": ["No env features available (makeEnvFeatures failed)"],
            }

        predicted = []        # List of predicted anomaly types
        explanations = {}     # Textual explanations for each predicted anomaly
        evidence = {}         # Supporting data for each predicted anomaly

        # --- atomic scenario relations (boolean predicates derived from env features) ---

        # Whether there is at least one door too narrow for the robot to pass
        sr_impassable_door = bool(env.get("has_impassable_door", False))
        # Whether the scenario involves many room transitions (>=2)
        sr_many_transitions = (env.get("n_room_transitions", 0) >= 2)
        # Whether there are multiple narrow doors (>=1)
        sr_multi_narrow_doors = (env.get("n_narrow_doors", 0) >= 1)

        # Wall clearance at start and minimum clearance at goals
        start_clear = env.get("start_wall_clearance_m", None)
        goal_clear = env.get("min_goal_wall_clearance_m", None)

        # Whether goal is dangerously close to wall (less than danger threshold)
        sr_goal_near_wall_danger = (goal_clear is not None and goal_clear < self.WALL_DANGER_THRESHOLD)

        # Laser noise level and high noise predicate
        lidar_noise = env.get("lidar_noise_std", 0.0)
        sr_high_noise = (lidar_noise is not None and float(lidar_noise) > self.HIGH_LIDAR_NOISE)
        
        sr_start_goal_room_doors_too_narrow = bool(env.get("any_start_goal_room_doors_too_narrow", False))

        # --- rules mapping scenario predicates to predicted anomalies ---

        # 0) hard fail: start-room or goal-room doors are narrower than robot width
        # Only applies when start_room != goal_room (handled in makeEnvFeatures flags)
        if sr_start_goal_room_doors_too_narrow:
            predicted.append("hard_stuck")
            explanations["hard_stuck"] = (
                "Start-room door OR goal-room door are narrower than robot width; path is considered impossible."
            )
            evidence["hard_stuck"] = {
                "robot_width_m": env.get("robot_width_m"),
                "start_room": env.get("start_room"),
                "goal_rooms": env.get("goal_rooms"),
                "start_room_min_door_width_m": env.get("start_room_min_door_width_m"),
                "goal_room_min_door_widths_m": env.get("goal_room_min_door_widths_m"),
                "start_goal_room_doors_too_narrow_flags": env.get("start_goal_room_doors_too_narrow_flags"),
            }

        # 1) stuck_stopped: robot physically cannot pass due to narrow door(s)
        if sr_impassable_door:
            predicted.append("stuck_stopped")
            explanations["stuck_stopped"] = (
                "At least one door is narrower than required_door_width_m; the robot may not physically pass."
            )
            # Record evidence including door widths and counts
            evidence["stuck_stopped"] = {
                "min_door_width_m": env.get("min_door_width_m"),
                "required_door_width_m": env.get("required_door_width_m"),
                "n_narrow_doors": env.get("n_narrow_doors"),
            }

        # 2) oscillating_no_progress: multiple narrow doors combined with many room transitions
        # may cause repeated recoveries and oscillation in navigation
        if sr_multi_narrow_doors and sr_many_transitions:
            predicted.append("oscillating_no_progress")
            explanations["oscillating_no_progress"] = (
                "Multiple narrow doors across many room transitions; high risk of repeated recoveries and oscillation."
            )
            # Evidence includes counts of narrow doors and room transitions
            evidence["oscillating_no_progress"] = {
                "n_narrow_doors": env.get("n_narrow_doors"),
                "n_room_transitions": env.get("n_room_transitions"),
                "unique_rooms_on_sequence": env.get("unique_rooms_on_sequence"),
            }

        # 3) near_goal_not_reached: goal dangerously close to wall may cause final approach failure
        if sr_goal_near_wall_danger:
            predicted.append("near_goal_not_reached")
            explanations["near_goal_not_reached"] = (
                "Goal is very close to a wall; final approach may fail or take long due to collision avoidance."
            )
            # Evidence includes clearance and danger threshold
            evidence["near_goal_not_reached"] = {
                "min_goal_wall_clearance_m": goal_clear,
                "wall_danger_threshold": self.WALL_DANGER_THRESHOLD,
            }

        # 4) localization issues: high lidar noise may cause localization instability
        if sr_high_noise:
            predicted.append("localization_jump")
            explanations["localization_jump"] = (
                "High laser noise configured; increased risk of localization instability and navigation failure."
            )
            # Evidence includes lidar noise level and threshold
            evidence["localization_jump"] = {
                "lidar_noise_std": lidar_noise,
                "high_lidar_noise_threshold": self.HIGH_LIDAR_NOISE,
            }

        # Simple risk score (0..1)
        score = 0.0
        if "stuck_stopped" in predicted: score += 0.3
        if "oscillating_no_progress" in predicted: score += 0.1
        if "near_goal_not_reached" in predicted: score += 0.1
        if "localization_jump" in predicted: score += 0.1
        score = min(score, 1.0)

        out = {
            "Status": "OK",
            "Scenario": self.scenario_id,
            "map_name": env.get("map_name"),
            "predicted_anomalies": predicted,
            "risk_score": round(score, 3),
            "explanations": explanations,
            "evidence": evidence,
        }

        #logger.info("\n" + pformat(out, width=120) + "\n")
        return out
    
    def predict_run_outcome(self, basic: dict, anom: dict) -> dict:
        """
        Convert basic checks + anomaly predictions + risk score into a run outcome label.
        Output is a small dict you can print/store.
        """
        # If basic checks failed -> fail
        if (basic or {}).get("Status") == "Failure":
            return {
                "predicted_outcome": "FAIL",
                "reason": "basic_information_checks_failed",
                "details": (basic or {}).get("Reasons", []),
            }

        preds = (anom or {}).get("predicted_anomalies", []) or []
        score = float((anom or {}).get("risk_score", 0.0) or 0.0)

        # Hard failure types override everything
        if "hard_stuck" in preds:
            return {
                "predicted_outcome": "FAIL",
                "reason": "hard_stuck",
                "details": (anom or {}).get("explanations", {}).get("hard_stuck", ""),
            }

        # High-risk threshold -> fail
        if score >= self.FAIL_SCORE_THRESHOLD:
            return {
                "predicted_outcome": "FAIL",
                "reason": "risk_score_threshold",
                "details": {"risk_score": score, "threshold": self.FAIL_SCORE_THRESHOLD, "preds": preds},
            }

        # Otherwise likely succeed
        return {
            "predicted_outcome": "SUCCESS",
            "reason": "low_risk",
            "details": {"risk_score": score, "preds": preds},
        }