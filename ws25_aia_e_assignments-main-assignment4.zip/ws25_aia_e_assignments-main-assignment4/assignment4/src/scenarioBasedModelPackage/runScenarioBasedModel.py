from setup.config import *
from src.scenarioBasedModelPackage.scenarioBasedModel import scenarioBasedModelClass
from src.scenarioBasedModelPackage.scenarioHelper.helper import _append_block_txt
from src.scenarioBasedModelPackage.aggregator import ScenarioBasedAggregator

def run_scenario_based(allConfigs, agg: ScenarioBasedAggregator | None = None):
    """
    Entry point for scenario-based execution.
    """
    classObj = scenarioBasedModelClass(allConfigs)
    scenario_id = allConfigs.get("scenario_id", "unknown_scenario")

    if not classObj.basicMapChecks():
        logger.error("Basic Checks Failed: missing config/map_details/robot_details")
        return False

    result = classObj.basicInformationChecks()
    if result.get("Run Status") == "Failure":
        logger.error(result)
        return False
    else:
        logger.info(result)

    env = classObj.makeEnvFeatures()
    if env.get("Status") != "OK":
        logger.error(env)
        return False
    # else:
    #     logger.info({"basic_checks": result, "env_features": env})

    # ---- write env features to env txt ----
    _append_block_txt(
        "SCENARIO_BASED_env_features.txt",
        title=f"ENV FEATURES | scenario_id={allConfigs.get('scenario_id')} | map={env.get('map_name')}",
        data=env
    )


    anom = classObj.detectPossibleAnomalies(env)
    # ---- write anomaly prediction to anomaly txt ----
    _append_block_txt(
        "SCENARIO_BASED_anomaly_predictions.txt",
        title=f"ANOMALY PREDICTION | scenario_id={allConfigs.get('scenario_id')} | map={env.get('map_name')}",
        data=anom
    )

    outcome = classObj.predict_run_outcome(result, anom)
    print(f"[{scenario_id}] predicted_outcome={outcome['predicted_outcome']} risk_score={anom.get('risk_score')} predicted_anomalies={anom.get('predicted_anomalies')}")

    # accumulate
    if agg is not None:
        agg.update(env, anom, outcome)
    
    return True
