from setup.config import *

@dataclass
class ScenarioBasedAggregator:
    # total anomaly counts across all processed items (scenarios or runs)
    anomaly_counter: Counter = field(default_factory=Counter)
    outcome_counter: Counter = field(default_factory=Counter)

    # counts per map_name
    anomaly_counter_by_map: Dict[str, Counter] = field(default_factory=lambda: defaultdict(Counter))

    # store risk scores
    risk_scores: List[float] = field(default_factory=list)

    # store scenario-level prediction rows (one row per scenario)
    # schema: {"scenario_id": str, "pred_stuck_any": int}
    scenario_predictions: List[Dict[str, Any]] = field(default_factory=list)

    # how many items processed
    n_items: int = 0

    def update(self, env: Dict[str, Any], anom: Dict[str, Any], outcome: Optional[Dict[str, Any]] = None) -> None:
        """Call once per processed item (scenario or run)."""
        self.n_items += 1

        scenario_id = (env or {}).get("Scenario") or (env or {}).get("scenario_id") or "unknown_scenario"
        map_name = (env or {}).get("map_name", "unknown_map")

        preds = (anom or {}).get("predicted_anomalies", []) or []
        score = (anom or {}).get("risk_score", None)

        # ---- scenario-level "stuck any" flag for comparison ----
        pred_stuck_any = int(("stuck_stopped" in preds) or ("hard_stuck" in preds))
        self.scenario_predictions.append({
            "scenario_id": str(scenario_id),
            "pred_stuck_any": pred_stuck_any,
        })

        # ---- count anomalies for distribution plots ----
        if len(preds) > 0:
            self.anomaly_counter.update(preds)
            self.anomaly_counter_by_map[map_name].update(preds)

        # ---- risk scores ----
        if score is not None:
            try:
                self.risk_scores.append(float(score))
            except Exception:
                pass

        # ---- predicted outcomes ----
        if outcome:
            self.outcome_counter.update([outcome.get("predicted_outcome", "UNKNOWN")])

    def save_anomaly_distribution_bar(self, out_img: str | Path) -> Path:
        """Saves ONE bar chart: anomaly counts across all items."""
        out_path = IMAGES_DIR / out_img

        labels = list(self.anomaly_counter.keys())
        values = [self.anomaly_counter[k] for k in labels]

        fig = plt.figure(figsize=(10, 4.5))
        ax = plt.gca()
        ax.bar(range(len(values)), values)
        ax.set_xticks(range(len(labels)))
        ax.set_xticklabels(labels, rotation=30, ha="right")
        ax.set_ylabel("count")
        ax.set_title(f"Scenario-based predicted anomaly distribution (n={self.n_items})")

        for i, v in enumerate(values):
            ax.text(i, v, str(v), ha="center", va="bottom", fontsize=9)

        plt.tight_layout()
        plt.savefig(out_path, dpi=200, bbox_inches="tight")
        plt.close(fig)
        return out_path
    
    def plot_confusion_matrix(self, cmp_df, out_png="LOG_BASED_cmp_confusion_matrix.png"):
        out_png = IMAGES_DIR / out_png

        tp = int(((cmp_df.gt_no_progress_any == 1) & (cmp_df.pred_stuck_any == 1)).sum())
        fp = int(((cmp_df.gt_no_progress_any == 0) & (cmp_df.pred_stuck_any == 1)).sum())
        fn = int(((cmp_df.gt_no_progress_any == 1) & (cmp_df.pred_stuck_any == 0)).sum())
        tn = int(((cmp_df.gt_no_progress_any == 0) & (cmp_df.pred_stuck_any == 0)).sum())

        # rows = GT, cols = Pred
        mat = np.array([[tp, fn],
                        [fp, tn]], dtype=int)

        fig, ax = plt.subplots(figsize=(8.5, 5.5))

        vmax = int(mat.max()) if mat.size else 1
        im = ax.imshow(mat, cmap="YlGnBu", vmin=0, vmax=max(vmax, 1))

        # Colorbar
        cbar = fig.colorbar(im, ax=ax)
        cbar.set_label("Number of Scenarios", rotation=90)

        # Axis ticks/labels
        ax.set_xticks([0, 1])
        ax.set_yticks([0, 1])
        ax.set_xticklabels(["Pred: stuck_any = 1", "Pred: stuck_any = 0"], rotation=15, ha="right")
        ax.set_yticklabels(["GT: No Progress = 1", "GT: No Progress = 0"])

        ax.set_xlabel("Scenario-based prediction")
        ax.set_ylabel("Ground truth (from logs)")

        ax.set_title("Scenario-level Confusion Matrix (Logs vs Scenario-based)")

        # Gridlines between cells
        ax.set_xticks(np.arange(-0.5, 2, 1), minor=True)
        ax.set_yticks(np.arange(-0.5, 2, 1), minor=True)
        ax.grid(which="minor", linestyle="-", linewidth=1)
        ax.tick_params(which="minor", bottom=False, left=False)

        # Annotations (auto text color based on intensity)
        thresh = (mat.max() / 2.0) if mat.size else 0
        for i in range(mat.shape[0]):
            for j in range(mat.shape[1]):
                val = mat[i, j]
                txt_color = "white" if val > thresh else "black"
                ax.text(j, i, f"{val}", ha="center", va="center", fontsize=12, color=txt_color)

        plt.tight_layout()
        plt.savefig(out_png, dpi=200, bbox_inches="tight")
        plt.close(fig)
        return out_png