from setup.config import *

def _get_map_polygons(mapper, map_name):
    """
    Returns the list of Shapely polygons for a given map name from the SpatialContextMapper.
    - If the map is unknown (not present), returns an empty list.
    """
    if map_name not in mapper.map_polygons:
        return []
    return [p["polygon"] for p in mapper.map_polygons[map_name]]


def _inside_any_polygon(x, y, polygons):
    """
    Checks whether a point (x, y) lies inside at least one polygon in a given list.

    Used by out-of-map checks to confirm that start/goal positions are inside
    the defined navigable spaces (rooms) of the map.
    """
    pt = Point(x, y)
    return any(poly.contains(pt) for poly in polygons)


# -------------------------
# OUT OF MAP CHECKS
# -------------------------

def start_out_of_map(start_pose: dict, mapper, map_name: str) -> bool:
    """
    Returns True if the start position is outside all known space polygons of the map.

    Fail-safe behavior:
    - If the map has no polygons (unknown map_name), returns True (treat as out-of-map).
    """
    x = start_pose["position"]["x"]
    y = start_pose["position"]["y"]

    polygons = _get_map_polygons(mapper, map_name)
    if not polygons:
        return True  # unknown map → fail safe

    return not _inside_any_polygon(x, y, polygons)


def goal_out_of_map(goal_poses: list, mapper, map_name: str) -> bool:
    """
    Returns True if ANY goal position is outside all known space polygons of the map.

    Fail-safe behavior:
    - If the map has no polygons (unknown map_name), returns True.
    """
    polygons = _get_map_polygons(mapper, map_name)
    if not polygons:
        return True

    for g in goal_poses:
        x = g["position"]["x"]
        y = g["position"]["y"]
        if not _inside_any_polygon(x, y, polygons):
            return True

    return False


# -------------------------
# OBSTACLE OVERLAP CHECKS
# -------------------------

def _distance(p1, p2):
    """
    Computes Euclidean distance between two 2D points p1=(x1,y1), p2=(x2,y2).
    """
    return math.hypot(p1[0] - p2[0], p1[1] - p2[1])


def start_obs_overlap(start_pose: dict, mapper, map_name: str,
                        static_objects: list | None = None,
                        threshold_m: float = 0.25) -> bool:
    """
    Returns True if the start position is too close to any static object.

    This treats static objects as POINTS (no size/shape), and flags overlap if:
        distance(start, object) <= threshold_m

    Notes:
    - mapper and map_name are not used here; they are included to keep signature consistent.
    - If static_objects is empty/None, returns False.
    """
    if not static_objects:
        return False

    sx = start_pose["position"]["x"]
    sy = start_pose["position"]["y"]

    for obj in static_objects:
        pos = obj["spawn_pose"]["position"]
        ox, oy = pos["x"], pos["y"]
        if _distance((sx, sy), (ox, oy)) <= threshold_m:
            return True

    return False


def goal_obs_overlap(goal_poses: list, mapper, map_name: str,
                        static_objects: list | None = None,
                        threshold_m: float = 0.25) -> bool:
    """
    Returns True if ANY goal position is too close to any static object.

    Same modeling as start_obs_overlap:
    - objects are treated as points
    - overlap if distance(goal, object) <= threshold_m

    Notes:
    - mapper and map_name are not used here; they are included to keep signature consistent.
    - If static_objects is empty/None, returns False.
    """
    if not static_objects:
        return False

    for g in goal_poses:
        gx = g["position"]["x"]
        gy = g["position"]["y"]
        for obj in static_objects:
            pos = obj["spawn_pose"]["position"]
            ox, oy = pos["x"], pos["y"]
            if _distance((gx, gy), (ox, oy)) <= threshold_m:
                return True

    return False


# -------------------------
# MAP NAME
# -------------------------

def infer_map_name_from_map_file(map_file: str) -> str:
    """
    Extracts the map name from a map_file path string.

    Current rule:
        - split by "/"
        - return parts[1] if possible

    If the string does not contain "/", returns "".
    """
    parts = map_file.split("/")
    return parts[1] if len(parts) > 1 else ""


# -------------------------
# FOR ENVIRONMENTAL FEATURES
# -------------------------

def parse_length_to_m(value: Any) -> Optional[float]:
    """
    Parses a length into meters.

    Returns:
        - float meters
        - None if parsing fails
    """
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)

    s = str(value).strip().lower().replace(" ", "")
    m = re.match(r"^([0-9]*\.?[0-9]+)(mm|cm|m)?$", s)
    if not m:
        return None

    num = float(m.group(1))
    unit = m.group(2) or "m"

    if unit == "mm":
        return num / 1000.0
    if unit == "cm":
        return num / 100.0
    return num


def euclidean_xy(x1: float, y1: float, x2: float, y2: float) -> float:
    """
    Computes Euclidean distance between (x1,y1) and (x2,y2).
    Used for door width computation and waypoint distance approximation.
    """
    return math.hypot(x2 - x1, y2 - y1)


def get_map_info(map_details: Dict[str, Any], map_name: str) -> Optional[Dict[str, Any]]:
    """
    Looks up and returns the map entry from maps_details.json-like dict structure.

    Returns:
        - the matching map dict if found
        - None otherwise
    """
    for mi in map_details.get("maps", []):
        if mi.get("map") == map_name:
            return mi
    return None


def get_space_polygons(map_info: Dict[str, Any]) -> List[Polygon]:
    """
    Converts each space's 'corners' list into a Shapely Polygon.

    Returns:
      - list of polygons for all valid spaces
      - invalid spaces (bad corner lists) are skipped
    """
    polys: List[Polygon] = []
    for space in map_info.get("spaces", []):
        corners = space.get("corners", [])
        if isinstance(corners, list) and len(corners) >= 3:
            try:
                polys.append(Polygon(corners))
            except Exception:
                pass
    return polys


def min_wall_clearance(map_info: Dict[str, Any], x: float, y: float) -> Optional[float]:
    """
    Computes minimum distance from point (x,y) to any room boundary across all spaces.

    Interpretation:
    - Treats each space polygon boundary as a "wall"
    - Returns the minimum boundary distance across spaces
    - Returns None if no polygons exist or distance cannot be computed

    Used by near-wall / goal-near-wall rules.
    """
    p = Point(x, y)
    best = math.inf
    for poly in get_space_polygons(map_info):
        try:
            d = p.distance(poly.boundary)
            best = min(best, d)
        except Exception:
            continue
    return None if not math.isfinite(best) else float(best)


def list_doors(map_info: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extracts door segments from each space and returns them with derived width.

    Notes:
    - This assumes the door "width" can be approximated by the distance
      between the two points given in maps_details.json.
    - Spaces without a valid door are skipped.
    """
    doors = []
    for space in map_info.get("spaces", []):
        door = space.get("door")
        if not door or not isinstance(door, list) or len(door) < 2:
            continue
        try:
            (x1, y1), (x2, y2) = door[0], door[1]
            doors.append({
                "space_name": space.get("space_name", "unknown"),
                "width_m": euclidean_xy(x1, y1, x2, y2),
                "p1": (float(x1), float(y1)),
                "p2": (float(x2), float(y2)),
            })
        except Exception:
            continue
    return doors


def straight_line_blocked(map_info: Dict[str, Any], x1: float, y1: float, x2: float, y2: float) -> Optional[bool]:
    """
    Approximates whether the straight-line segment from (x1,y1) to (x2,y2)
    is "blocked" by leaving the union of all room polygons.

    Implementation:
    - Build union of all space polygons
    - Check if the LineString is fully within this union
    - Return True if not within (i.e., blocked), False if within

    Returns:
      - None if polygons don't exist or geometry operations fail

    Note:
    - This is a coarse proxy and does NOT account for doors explicitly or obstacles.
    """
    polys = get_space_polygons(map_info)
    if not polys:
        return None
    union = unary_union(polys)
    seg = LineString([(x1, y1), (x2, y2)])
    try:
        return not seg.within(union)
    except Exception:
        return None


def get_space_name_for_point(mapper, map_name: str, x: float, y: float) -> str:
    """
    Returns the space/room label for point (x,y) using SpatialContextMapper.

    Returns:
      - first returned context label if available
      - "Unknown_Map" if no context could be assigned
    """
    ctx = mapper.get_context([x], [y], map_name)
    return ctx[0] if ctx else "Unknown_Map"


def flatten_dict(d, parent_key="", sep="."):
    """
    Flattens nested dictionaries into a single-level dictionary with dotted keys.

    Used for logging/debug output to write compact key-value blocks.
    If the input is not a dict, wraps it under 'value' or parent_key.
    """
    items = []
    if not isinstance(d, dict):
        return {parent_key: d} if parent_key else {"value": d}

    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else str(k)
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def _append_block_txt(path: Path, title: str, data: dict) -> None:
    """
    Appends a formatted debug block to a text file.

    - Ensures parent directory exists
    - Flattens the dict (so nested structures become dotted keys)

    Useful for scenario-by-scenario logging of extracted env features and predictions.
    """
    path = OUTPUT_DIR / path

    flat = flatten_dict(data)
    lines = [f"{k}: {flat[k]}" for k in sorted(flat.keys())]

    block = (
        "\n" + "=" * 100 + "\n"
        f"{title}\n"
        + "-" * 100 + "\n"
        + "\n".join(lines) + "\n"
    )

    with open(path, "a", encoding="utf-8") as f:
        f.write(block)