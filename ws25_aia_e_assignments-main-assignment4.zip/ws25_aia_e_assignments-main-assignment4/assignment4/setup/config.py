"""
Shared configuration and imports for robot navigation analysis.
"""
from __future__ import annotations
import pandas as pd
import numpy as np
from pathlib import Path
import yaml
import gc
import re
import os 
import json
import sys
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import math
warnings.filterwarnings('ignore')
from PIL import Image
from scipy.ndimage import distance_transform_edt
from shapely.geometry import Point, Polygon, LineString
from shapely.vectorized import contains
from shapely.ops import unary_union
from collections import defaultdict, Counter
from sklearn.cluster import DBSCAN
from sklearn.decomposition import IncrementalPCA
from typing import Optional, List, Tuple, Dict, Any
from sklearn.metrics import confusion_matrix, classification_report
import logging as logger
from dataclasses import dataclass, field
from pprint import pformat

# =========================
# Global Configuration
# =========================
ASSIGN4_ROOT = Path(__file__).resolve().parent.parent
print(f"Project Root: {ASSIGN4_ROOT}")

logger.basicConfig(
    level=logger.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

# TODO: Update these paths to match your system
DATA_ROOT = ASSIGN4_ROOT / "../ws25_aia_te_dataset/ws25_aia_complete_data"
MAPS_DETAILS_PATH = ASSIGN4_ROOT / "../ws25_aia_te_dataset/maps_details.json"

# No need to change the following paths
CUSTOM_DATA_ROOT = ASSIGN4_ROOT / "src/scenarioBasedModelPackage/customScenarios"
CUSTOM_MAPS_DETAILS_PATH = ASSIGN4_ROOT / "src/scenarioBasedModelPackage/customScenarios/maps_details.json"

OUTPUT_DIR = ASSIGN4_ROOT / "output"
IMAGES_DIR = ASSIGN4_ROOT / "images"

# Create output directory if it doesn't exist
OUTPUT_DIR.mkdir(exist_ok=True)
IMAGES_DIR.mkdir(exist_ok=True)

ROBOT_INFO = {"length": "342mm", "width":"339mm", "height":"192mm"}

# =========================
# Log Parsing Rules
# =========================

LOG_RULES = [
    (re.compile(r"goal reached|succeeded|reached goal", re.I), "Goal reached"),
    (re.compile(r"GridBased plugin failed to plan", re.I), "Planning Failure"),
    (re.compile(r"Exceeded time allowance before reaching the Spin goal|spin failed|backup failed", re.I), "Spin Timeout"),
    (re.compile(r"Failed to make progress", re.I), "No Progress"),
    (re.compile(r"Timeout waiting for simulation|wait_for_sim", re.I), "Sim Timeout"),
    (re.compile(r"execution failed|child finished before timeout", re.I), "Scenario Abort"),
    (re.compile(r"Setup failed|Invalid model specified|unrecognized model", re.I), "Invalid Model or sdf"),
    (re.compile(r"could not be resolved|Failed to load a world", re.I), "Missing mesh or world"),
    (re.compile(r"Failed to load map yaml file|bad file", re.I), "Map load failure"),
    (re.compile(r"Invalid frame ID \"odom\"|Timed out waiting for transform", re.I), "tf tree missing"),
    (re.compile(r"inflation", re.I), "Inflation too large")
]


# =========================
# Helper Functions
# =========================

def get_output_path(filename: str) -> Path:
    """Get full path for output file."""
    return OUTPUT_DIR / filename

def get_image_path(filename: str) -> Path:
    """Get full path for image file."""
    return IMAGES_DIR / filename

def load_csv_if_exists(path: Path) -> Optional[pd.DataFrame]:
    """Load CSV file if it exists."""
    if path.exists():
        return pd.read_csv(path)
    return None

def save_dataframe(df: pd.DataFrame, filename: str) -> None:
    """Save dataframe to output directory."""
    output_path = get_output_path(filename)
    df.to_csv(output_path, index=False)
    print(f"✓ Saved: {output_path}")

def save_figure(filename: str, dpi: int = 300) -> None:
    """Save matplotlib figure to output directory."""
    output_path = get_image_path(filename)
    plt.savefig(output_path, dpi=dpi, bbox_inches='tight')
    print(f"✓ Saved: {output_path}")
