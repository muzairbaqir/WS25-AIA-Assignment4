"""
Test script to verify package setup and configuration.

Run this after updating config.py to ensure everything is configured correctly.

Usage:
    python test_setup.py
"""

import sys
from pathlib import Path

def test_imports():
    """Test that all required packages are installed."""
    print("=" * 80)
    print("TESTING PACKAGE IMPORTS")
    print("=" * 80)
    
    required_packages = [
        'pandas',
        'numpy',
        'matplotlib',
        'seaborn',
        'sklearn',
        'yaml',
        'PIL',
        'scipy',
        'shapely'
    ]
    
    failed = []
    for package in required_packages:
        try:
            __import__(package)
            print(f"✓ {package}")
        except ImportError:
            print(f"✗ {package} - NOT INSTALLED")
            failed.append(package)
    
    if failed:
        print(f"\nMissing packages: {', '.join(failed)}")
        print("Install with: pip install -r requirements.txt")
        return False
    else:
        print("\nAll packages installed")
        return True


def test_config():
    """Test that config.py is properly configured."""
    print("\n" + "=" * 80)
    print("TESTING CONFIGURATION")
    print("=" * 80)
    
    try:
        from config import DATA_ROOT, MAPS_DETAILS_PATH, OUTPUT_DIR, IMAGES_DIR
        
        # Check DATA_ROOT
        data_path = Path(DATA_ROOT)
        if data_path.exists():
            print(f"✓ DATA_ROOT exists: {DATA_ROOT}")
            
            # Count scenarios
            scenarios = [d for d in data_path.iterdir() if d.is_dir()]
            print(f"  Found {len(scenarios)} potential scenarios")
        else:
            print(f"✗ DATA_ROOT does not exist: {DATA_ROOT}")
            print("  → Update DATA_ROOT in config.py")
            return False
        
        # Check MAPS_DETAILS_PATH
        maps_path = Path(MAPS_DETAILS_PATH)
        if maps_path.exists():
            print(f"✓ MAPS_DETAILS_PATH exists: {MAPS_DETAILS_PATH}")
        else:
            print(f"✗ MAPS_DETAILS_PATH does not exist: {MAPS_DETAILS_PATH}")
            print("  → Update MAPS_DETAILS_PATH in config.py")
            return False
        
        # Check OUTPUT_DIR
        if OUTPUT_DIR.exists():
            print(f"✓ OUTPUT_DIR exists: {OUTPUT_DIR}")
        else:
            print(f"⚠ OUTPUT_DIR does not exist: {OUTPUT_DIR}")
            print("  Creating OUTPUT_DIR...")
            OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
            print(f"✓ Created: {OUTPUT_DIR}")
        
        # Check OUTPUT_DIR
        if IMAGES_DIR.exists():
            print(f"✓ IMAGES_DIR exists: {IMAGES_DIR}")
        else:
            print(f"⚠ IMAGES_DIR does not exist: {IMAGES_DIR}")
            print("  Creating IMAGES_DIR...")
            IMAGES_DIR.mkdir(parents=True, exist_ok=True)
            print(f"✓ Created: {IMAGES_DIR}")
        
        print("\nConfiguration is correct")
        return True
        
    except ImportError as e:
        print(f"✗ Cannot import config.py: {e}")
        return False
    except Exception as e:
        print(f"✗ Configuration error: {e}")
        return False

def main():
    """Run all tests."""
    print("\n")
    print("╔" + "═" * 78 + "╗")
    print("║" + " " * 20 + "SETUP VERIFICATION TEST" + " " * 35 + "║")
    print("╚" + "═" * 78 + "╝")
    print()
    
    results = []
    
    # Test imports
    results.append(("Package Imports", test_imports()))
    
    # Test configuration
    results.append(("Configuration", test_config()))
    
    # Summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    
    for test_name, passed in results:
        status = "PASS" if passed else "FAIL"
        print(f"{test_name:30s} {status}")
    
    all_passed = all(r[1] for r in results)
    
    print("\n" + "=" * 80)
    if all_passed:
        print("ALL TESTS PASSED!")
        print("=" * 80)
        print("\nYou can now run the main pipeline:")
        print("  python main.py")
        print("\nOr run with options, check readme for details")
        return 0
    else:
        print("SOME TESTS FAILED")
        print("=" * 80)
        print("\nPlease fix the issues above before running the pipeline.")
        print("\nCommon fixes:")
        print("  1. Update DATA_ROOT in config.py")
        print("  2. Update MAPS_DETAILS_PATH in config.py")
        print("  3. Install missing packages: pip install -r requirements.txt")
        return 1


if __name__ == "__main__":
    sys.exit(main())
