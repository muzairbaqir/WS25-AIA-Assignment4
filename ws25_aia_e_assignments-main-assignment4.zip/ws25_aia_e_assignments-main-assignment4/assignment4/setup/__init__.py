"""
Setup package for robot navigation analysis.
"""

from .config import *
