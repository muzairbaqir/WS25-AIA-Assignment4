"""
Main execution script for robot navigation analysis.

This script orchestrates the entire analysis pipeline:
1. Load data
2. Analyze runs
3. Preprocess data
4. Extract contexts
5. Engineer features
6. Detect anomalies
7. Mine patterns
8. Analyze relations

Usage:
    python main.py [--scenario-based] [--log-based] [--skip-log-analysis]
"""

import argparse
from setup.config import *

# Import all modules
from src.data_loading import load_dataset, scenario_name_to_label
from src.logBasedPackage.log_analysis import LogAnalyzer
from src.logBasedPackage.preprocessing import preprocess_data
from src.logBasedPackage.context import SpatialContextExtractor, ContextMapVisualizer, SpatialContextMapper, apply_spatial_context_class, plot_final_trajectory
from src.logBasedPackage.features import EnhancedRawFeatureComputer
from src.logBasedPackage.anomaly import ContextAwareFeatureExtractor, TemporalAwareFeatureDefinitions, TemporalAtomicRelations, OptimizedAnomalyDetector, OptimizedAnomalyFeatureVectorCreator
from src.logBasedPackage.pattern_mining import MemoryEfficientPatternMiner
from src.logBasedPackage.relation_analysis import RelationGeneralizationAnalyzer
from src.logBasedPackage.geometry import MapGeometry, plot_alignment_check
from src.scenarioBasedModelPackage.runScenarioBasedModel import run_scenario_based
from src.scenarioBasedModelPackage.aggregator import ScenarioBasedAggregator
from src.scenarioBasedModelPackage.scenario_level_eval import evaluate_scenario_level
import datetime
import platform

def print_start_header():
    start_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    header = f"""
    __________________________________________________________
    ROBOT NAVIGATION PIPELINE
    Started: {start_time}                      
    System:  {platform.system()} ({platform.machine()})            
    __________________________________________________________
    """
    print(header)

def print_finish_footer(success=True):
    status = "SUCCESS" if success else "FAILED"
    end_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    footer = f"""
    __________________________________________________________
    [ SYSTEM SHUTDOWN ]
    Status: {status}
    Finished: {end_time}
    __________________________________________________________
    """
    print(footer)

def print_banner(mode_name):
    banner = f"█ {' ' * 5} STARTING MODE: {mode_name.upper()} {' ' * 5} █"
    border = "█" * len(banner)
    print(f"\n{border}\n{banner}\n{border}\n")

def main(args):
    """Main execution function."""
    # =========================
    # Loading Data
    # =========================
    print("=" * 80)
    print("Loading dataset...")
    print("=" * 80)

    if args.custom_scenario_based:
        dataset_root = CUSTOM_DATA_ROOT
    else:
        dataset_root = DATA_ROOT

    scenarios = load_dataset(dataset_root)
    for scenario in scenarios:
        print(f"  - {scenario.scenario_id}: {len(scenario.runs)} runs")
    print(f"Loaded {len(scenarios)} scenarios")
    print("=" * 80)

    # =========================
    # SCENARIO-BASED MODE
    # =========================
    if args.all or args.scenario_based or args.custom_scenario_based:
        print_banner("SCENARIO-BASED")

        agg = ScenarioBasedAggregator()

        # choose maps_details based on flags
        maps_path = CUSTOM_MAPS_DETAILS_PATH if args.custom_scenario_based else MAPS_DETAILS_PATH

        # Load map details
        with open(maps_path, 'r') as f:
            map_details = json.load(f)

        for scenario in scenarios:
            allConfigs = {
                "config": scenario.parameters,   # scenario.config
                "map_details": map_details,       # maps_details.json
                "robot_details": ROBOT_INFO,
                "scenario_path": scenario.scenario_path,
                "scenario_id": scenario.scenario_id,
                "mapper": SpatialContextMapper(map_details)
            }

            run_scenario_based(allConfigs, agg=agg)
        
        out_img = "CUSTOM_SCENARIO_BASED_anomaly_distribution.png" if args.custom_scenario_based else "SCENARIO_BASED_ALL_anomaly_distribution.png"
        agg.save_anomaly_distribution_bar(out_img)

        print("=" * 80)
        print("SCENARIO-BASED MODE FINISHED")
        print("=" * 80)
    else:
        print("=" * 80)
        print("Skipping scenario-based mode as per argument.")
        print("=" * 80)

    # =========================
    # LOG-BASED MODE
    # =========================
    if args.all or args.log_based:
        print_banner("LOG-BASED")
        # =========================
        # STEP 1: Analyzing logs
        # =========================
        print("1. Analyzing logs...")
        print("=" * 80)
        log_analyzer = LogAnalyzer(scenarios)
        log_analyzer.plot_scenario_stacked_bar()
        log_analyzer.plot_totals_bar()
        log_analyzer.plot_outcome_correlation()
        save_dataframe(log_analyzer.runs_df, 'LOG_BASED_analyzer_runs_df.csv')
        save_dataframe(log_analyzer.runs_anomalies, 'LOG_BASED_analyzer_runs_anomalies.csv')
        save_dataframe(log_analyzer.summary_df, 'LOG_BASED_analyzer_summary_df.csv')

        test_run = scenarios[0].runs[0]
        test_map = MapGeometry(scenarios[10].map_variations[0]['map_yaml'])
        goal_poses = scenarios[10].parameters.get('goal_poses', [])
        start_pose = scenarios[10].parameters.get('start_pose', [])

        plot_alignment_check(test_run, test_map, goal_poses, start_pose)
        print("Analysis complete")
        print("=" * 80)
        
        # =========================
        # STEP 2: reprocess Data
        # =========================
        print("2. Preprocessing data...")
        print("=" * 80)
        final_df = preprocess_data(scenarios)
        print(f"Preprocessed {len(final_df):,} data points")
        print("=" * 80)

        # =========================
        # STEP 3: Context Identification
        # =========================
        print("3. Identifying spatial contexts...")
        print("=" * 80)
        with open(MAPS_DETAILS_PATH, 'r') as f:
            map_details = json.load(f)
        
        final_df = apply_spatial_context_class(final_df, map_details)
        # Usage
        map_mapper = {map_info['map']: map_info for map_info in map_details['maps']}
        plot_final_trajectory(final_df, map_mapper, test_run.scenario_id, test_run.run_id)
        final_df.spatial_context.value_counts()
        
        # Extract context features
        context_extractor = SpatialContextExtractor()

        run_list = []
        scenario_list = []
        success_list = []

        for scenario in scenarios:
            for run in scenario.runs:
                run_list.append(run.run_id)
                scenario_list.append(scenario.scenario_id)
                success_list.append(run.success)

        status_df = pd.DataFrame({'scenario_id': scenario_list,
            'run_id': run_list,
            'success': success_list})
        status_df["run_id"] = status_df["run_id"].astype(str)   
        final_df["run_id"] = final_df["run_id"].astype(str)   
        final_df["success"] = pd.merge(final_df, status_df,
            on=['scenario_id', 'run_id'], how='left')['success']

        final_df_with_contexts = context_extractor.extract_contexts_batch(final_df.copy())
        print("\nContext extraction results:")
        print("-" * 60)
        context_cols = [col for col in final_df_with_contexts.columns if col.startswith('ctx_')]
        print(f"Total context columns created: {len(context_cols)}")

        print("\nContext activation statistics:")
        print("-" * 60)
        context_stats = []
        for ctx in sorted(context_cols):
            n_active = final_df_with_contexts[ctx].sum()
            pct_active = (n_active / len(final_df_with_contexts)) * 100
            
            if 'success' in final_df_with_contexts.columns:
                n_failures = final_df_with_contexts[~final_df_with_contexts['success'] & (final_df_with_contexts[ctx] == 1)].shape[0]
                n_successes = final_df_with_contexts[final_df_with_contexts['success'] & (final_df_with_contexts[ctx] == 1)].shape[0]
                failure_rate = (n_failures / (n_failures + n_successes) * 100) if (n_failures + n_successes) > 0 else 0
            else:
                n_failures = 0
                n_successes = 0
                failure_rate = 0
            
            context_stats.append({
                'Context': ctx,
                'Activations': int(n_active),
                'Activation_Rate': f"{pct_active:.1f}%",
                'Failures': n_failures,
                'Successes': n_successes,
                'Failure_Rate': f"{failure_rate:.1f}%"
            })

        context_stats_df = pd.DataFrame(context_stats)

        print("\nTop 30 most active contexts:")
        top_30 = context_stats_df.nlargest(30, 'Activations')
        print(top_30.to_string(index=False))

        print("\nContexts with highest failure rates (min 10 activations):")
        print("-" * 60)
        high_failure = context_stats_df[context_stats_df['Activations'] >= 10].copy()
        high_failure['Failure_Rate_Numeric'] = high_failure['Failure_Rate'].str.rstrip('%').astype(float)
        high_failure = high_failure.nlargest(20, 'Failure_Rate_Numeric')
        print(high_failure[['Context', 'Activations', 'Failures', 'Successes', 'Failure_Rate']].to_string(index=False))

        save_dataframe(final_df_with_contexts, 'LOG_BASED_final_df_with_contexts.csv')

        print("\nSample of active_contexts strings:")
        print("-" * 60)
        sample_contexts = final_df_with_contexts['active_contexts'].sample(3).values
        for i, ctx in enumerate(sample_contexts, 1):
            print(f"{i}. {ctx}")
        
        visualizer = ContextMapVisualizer(map_details, scenarios)

        print(f"\nFound {len(visualizer.map_images)} map images:")
        for map_name, map_path in visualizer.map_images.items():
            print(f"  - {map_name}: {Path(map_path).name}")

        # Find map name to use based on data
        if 'map_name' in final_df_with_contexts.columns:
            map_name_counts = final_df_with_contexts['map_name'].value_counts()
            print(f"\nMap names in data:")
            print(map_name_counts.head())
            
            # Use the most common map that we have an image for
            for map_name_candidate in map_name_counts.index:
                if map_name_candidate in visualizer.map_images:
                    sample_map = map_name_candidate
                    print(f"\n Using map: {sample_map}")
                    break
            else:
                print("\n⚠ No matching map found in data")
                sample_map = list(visualizer.map_images.keys())[0] if visualizer.map_images else None
                print(f"Using first available map: {sample_map}")
        else:
            # Use scenario_id to infer map name
            sample_scenario = final_df_with_contexts['scenario_id'].iloc[0]
            sample_map = scenario_name_to_label(sample_scenario)
            print(f"\n  Using map from scenario: {sample_map}")

        if sample_map:
            # Example 1: Plot all room contexts as bounding boxes
            print("\n" + "-" * 60)
            print("EXAMPLE 1: All Room Contexts as Bounding Boxes")
            print("-" * 60)
            
            visualizer.plot_all_room_contexts(
                final_df_with_contexts,
                map_name=sample_map,
                save_path='LOG_BASED_all_room_contexts_boxes.png'
            )
            
            # Example 2: Plot a single high-activity context in detail
            print("\n" + "-" * 60)
            print("EXAMPLE 2: Single Context Detailed View")
            print("-" * 60)
            
            high_activity_contexts = context_stats_df[context_stats_df['Activations'] > 100].nlargest(5, 'Activations')
            if len(high_activity_contexts) > 0:
                example_context = high_activity_contexts.iloc[0]['Context']
                print(f"Plotting context: {example_context}")
                
                visualizer.plot_single_context_box(
                    final_df_with_contexts,
                    context_name=example_context,
                    map_name=sample_map,
                    save_path=f'LOG_BASED_single_context_{example_context}.png'
                )
            
            # Example 3: Plot top failure-prone contexts
            print("\n" + "-" * 60)
            print("EXAMPLE 3: Top Failure-Prone Contexts")
            print("-" * 60)
            
            visualizer.plot_contexts_by_failure_rate(
                final_df_with_contexts,
                context_stats_df,
                map_name=sample_map,
                min_activations=30,
                top_n=8,
                save_path='LOG_BASED_top_failure_contexts_boxes.png'
            )
            
            # Example 4: Plot specific contexts of interest
            print("\n" + "-" * 60)
            print("EXAMPLE 4: Specific Contexts Comparison")
            print("-" * 60)
            
            corridor_contexts = [ctx for ctx in context_stats_df['Context'].tolist() 
                                if 'corridor' in ctx and context_stats_df[context_stats_df['Context'] == ctx]['Activations'].values[0] > 20][:3]
            
            if corridor_contexts:
                print(f"Comparing corridor contexts: {corridor_contexts}")
                visualizer.plot_context_boxes(
                    final_df_with_contexts,
                    context_names=corridor_contexts,
                    map_name=sample_map,
                    save_path='LOG_BASED_corridor_contexts_boxes.png'
                )
        print("=" * 80)
        # =========================
        # STEP 4: Feature Engineering
        # =========================
        print("\n 4. Engineering features...")
        print("=" * 80)
        feature_computer = EnhancedRawFeatureComputer(map_details, scenarios)
        final_df_with_features = feature_computer.compute_all_features(final_df)

        print("\n" + "-" * 60)
        print("FEATURE STATISTICS")
        print("-" * 60)

        top_10_features = [
            'time_since_progress_s',
            'cumulative_stopped_time_30s',
            'time_in_current_room_s',
            'heading_error_deg',
            'path_efficiency',
            'progress_rate_mps',
            'position_variance_10s',
            'recovery_attempt_count_20s',
            'wall_following_duration_s',
            'backward_motion_ratio_30s'
        ]
        
        # Compare success vs failure for key features
        if 'success' in final_df_with_features.columns:
            print("\n" + "-" * 60)
            print("SUCCESS VS FAILURE COMPARISON (KEY TEMPORAL FEATURES)")
            print("-" * 60)
            
            success_data = final_df_with_features[final_df_with_features['success'] == True]
            failure_data = final_df_with_features[final_df_with_features['success'] == False]
            
            key_features = [
                'time_since_progress_s',
                'cumulative_stopped_time_30s',
                'time_in_current_room_s',
                'heading_error_deg',
                'path_efficiency'
            ]
            
            print("\nFeature                          Success Mean    Failure Mean    Difference")
            print("-" * 60)
            for feat in key_features:
                success_mean = success_data[feat].mean()
                failure_mean = failure_data[feat].mean()
                diff = failure_mean - success_mean
                print(f"{feat:30s}  {success_mean:12.3f}  {failure_mean:12.3f}  {diff:12.3f}")

        save_dataframe(final_df_with_features, 'LOG_BASED_final_df_with_features.csv')
        
        # ============================================================================
        # APPLY FEATURE EXTRACTION (Optimized)
        # ============================================================================

        feature_extractor = ContextAwareFeatureExtractor()

        print("\nComputing features and relations for all data points...")
        print("-" * 60)
        feature_relation_df = feature_extractor.extract_features_with_context(final_df_with_features)

        print("\nSample of extracted features:")
        print("-" * 60)
        feature_cols = [col for col in feature_relation_df.columns if col.startswith('f_')]
        print(feature_relation_df[feature_cols].head())

        print("\nComputing temporal statistics per context...")
        print("-" * 60)
        context_temporal_stats = feature_extractor.compute_temporal_statistics_per_context(
            final_df_with_contexts, 
            feature_relation_df
        )

        print("\nTop 20 contexts by temporal difference (failure takes longer):")
        print("-" * 60)
        if 'time_difference_s' in context_temporal_stats.columns:
            top_temporal = context_temporal_stats.nlargest(20, 'time_difference_s')
            display_cols = ['context', 'n_total', 'failure_rate', 
                        'avg_time_success_s', 'avg_time_failure_s', 'time_difference_s']
            print(top_temporal[display_cols].to_string(index=False))
        else:
            print("No temporal statistics available")

        print("\nAnalyzing key failure patterns:")
        print("-" * 60)
        high_failure_contexts = context_temporal_stats[
            (context_temporal_stats['failure_rate'] > 50) & 
            (context_temporal_stats['n_total'] > 20)
        ].nlargest(5, 'failure_rate')

        if len(high_failure_contexts) > 0:
            example_context = high_failure_contexts.iloc[0]
            print(f"\nExample: {example_context['context']}")
            print(f"Failure rate: {example_context['failure_rate']:.1f}%")
            print(f"Avg time in success: {example_context.get('avg_time_success_s', 0):.2f}s")
            print(f"Avg time in failure: {example_context.get('avg_time_failure_s', 0):.2f}s")
            print(f"Time difference: {example_context.get('time_difference_s', 0):.2f}s")
            print("\nKey relations differentiating success/failure:")
            print("-" * 50)
            relation_diffs = []
            for col in context_temporal_stats.columns:
                if col.endswith('_success_rate'):
                    rel_name = col.replace('_success_rate', '')
                    failure_col = f"{rel_name}_failure_rate"
                    if failure_col in context_temporal_stats.columns:
                        success_rate = example_context[col]
                        failure_rate = example_context[failure_col]
                        diff = failure_rate - success_rate
                        relation_diffs.append({
                            'relation': rel_name,
                            'success_rate': success_rate,
                            'failure_rate': failure_rate,
                            'difference': diff
                        })
            relation_diffs_df = pd.DataFrame(relation_diffs)
            top_discriminators = relation_diffs_df.nlargest(10, 'difference')
            print(top_discriminators.to_string(index=False))

        print("\n Saving results...")
        print("-" * 60)
        save_dataframe( feature_relation_df, 'LOG_BASED_feature_relation_df.csv')
        save_dataframe( context_temporal_stats, 'LOG_BASED_context_temporal_stats.csv')
        print("=" * 80)

        # =========================
        # STEP 5: Anomaly Detection
        # =========================
        print("5. Detecting anomalies...")
        print("=" * 80)
        anomaly_detector = OptimizedAnomalyDetector()
        final_df_with_anomalies = anomaly_detector.detect_anomalies(final_df_with_features)
        
        # Extract feature vectors at anomalies
        feature_defs = TemporalAwareFeatureDefinitions()
        relation_computer = TemporalAtomicRelations()
        vector_creator = OptimizedAnomalyFeatureVectorCreator(feature_defs, relation_computer)
        
        anomaly_feature_vectors = vector_creator.extract_anomaly_feature_vectors(
            final_df_with_anomalies,
            final_df_with_contexts
        )
        save_dataframe(final_df_with_anomalies, 'LOG_BASED_final_df_with_anomalies.csv')
        save_dataframe(anomaly_feature_vectors, 'LOG_BASED_anomaly_feature_vectors.csv')

        # ============================================================================
        # OPTIMIZED ANALYSIS
        # ============================================================================

        print("\n" + "-" * 60)
        print("ANOMALY ANALYSIS")
        print("-" * 60)

        # Vectorized statistics
        total_points = len(final_df_with_anomalies)
        anomaly_count = final_df_with_anomalies['has_anomaly'].sum()

        print(f"\nOverall Statistics:")
        print("-" * 60)
        print(f"Total data points: {total_points:,}")
        print(f"Anomaly data points: {anomaly_count:,}")
        print(f"Anomaly rate: {anomaly_count/total_points*100:.2f}%")

        print("\nAnomaly Type Distribution:")
        print("-" * 60)
        anomaly_counts = final_df_with_anomalies[final_df_with_anomalies['has_anomaly']]['anomaly_type'].value_counts()
        for anom_type, count in anomaly_counts.items():
            pct = count / total_points * 100
            print(f"{anom_type:30s}: {count:6,} ({pct:5.2f}%)")

        # Success vs Failure analysis
        if 'success' in anomaly_feature_vectors.columns and not anomaly_feature_vectors['success'].isna().all():
            print("\nAnomalies by Run Outcome:")
            print("-" * 60)
            
            success_count = (anomaly_feature_vectors['success'] == True).sum()
            failure_count = (anomaly_feature_vectors['success'] == False).sum()
            
            print(f"Success runs: {success_count:,} anomalies")
            print(f"Failure runs: {failure_count:,} anomalies")

        # Context analysis (vectorized)
        print("\nTop 10 Contexts by Anomaly Frequency:")
        print("-" * 60)
        context_cols = [col for col in anomaly_feature_vectors.columns if col.startswith('ctx_')]
        if context_cols:
            context_sums = anomaly_feature_vectors[context_cols].sum().sort_values(ascending=False)
            for i, (ctx, count) in enumerate(context_sums.head(10).items(), 1):
                pct = count / len(anomaly_feature_vectors) * 100
                print(f"{i:2d}. {ctx:40s}: {int(count):6,} ({pct:5.2f}%)")

        # Relations analysis (vectorized)
        print("\nTop 10 Most Active Relations at Anomalies:")
        print("-" * 60)
        relation_cols = [col for col in anomaly_feature_vectors.columns if col.startswith('r_')]
        if relation_cols:
            relation_sums = anomaly_feature_vectors[relation_cols].sum().sort_values(ascending=False)
            for i, (rel, count) in enumerate(relation_sums.head(10).items(), 1):
                pct = count / len(anomaly_feature_vectors) * 100
                print(f"{i:2d}. {rel:40s}: {int(count):6,} ({pct:5.2f}%)")    
        print("=" * 80)
        # =========================
        # STEP 6: Pattern Mining
        # =========================
        print("\n 6. Mining patterns...")
        print("=" * 80)
        # Check current dataframe size
        print(f"\nInput data: {len(anomaly_feature_vectors):,} anomalies")
        mem_usage = anomaly_feature_vectors.memory_usage(deep=True).sum() / 1024 / 1024
        print(f"Memory usage: {mem_usage:.1f} MB")

        # Initialize with aggressive sampling for large datasets
        pattern_miner = MemoryEfficientPatternMiner(
            temporal_weight=0.6,
            max_samples=50000, # Limit to 50K samples (adjust based on your RAM)
            use_sampling=True,
            dtype='float32'
        )
        # ============================================================================
        # OPTION 1: GLOBAL PATTERN MINING
        # ============================================================================

        print("\n" + "-" * 60)
        print("GLOBAL PATTERN MINING")
        print("-" * 60)
        
        # Fill NaN values with 0 before mining patterns
        anomaly_feature_vectors.fillna(0, inplace=True)

        global_patterns, anomaly_feature_vectors = pattern_miner.mine_patterns(
            anomaly_feature_vectors,
            eps=0.35,
            min_samples=3
        )
        
        if global_patterns is not None and len(global_patterns) > 0:
            print("\n" + "-" * 60)
            print(f"DISCOVERED {len(global_patterns)} GLOBAL PATTERNS")
            print("-" * 60)
            
            # Show top 10 patterns only
            display_cols = ['cluster_id', 'size', 'failure_rate', 'dominant_anomaly_type']
            available_cols = [c for c in display_cols if c in global_patterns.columns]
            print("\nTop 10 patterns by failure rate:")
            print(global_patterns[available_cols].head(10).to_string(index=False))
            
            # Save (optimized dtypes)
            save_dataframe(global_patterns, 'LOG_BASED_global_patterns.csv')
            
            pattern_miner.analyze_pattern_quality(global_patterns)
        
        # Clean up
        gc.collect()

        # ============================================================================
        # OPTION 2: CONTEXT-SPECIFIC (TOP 5 CONTEXTS ONLY)
        # ============================================================================

        print("\n" + "-" * 60)
        print("CONTEXT-SPECIFIC MINING (TOP 5 CONTEXTS)")
        print("-" * 60)

        context_cols = [col for col in anomaly_feature_vectors.columns if col.startswith('ctx_')]

        if context_cols:
            # Get top 5 contexts (not 10) to save time
            context_anomaly_counts = anomaly_feature_vectors[context_cols].sum().to_dict()
            contexts_to_mine = [
                ctx for ctx, count in 
                sorted(context_anomaly_counts.items(), key=lambda x: x[1], reverse=True)[:5]  # Top 5 only
                if count >= 20  # Higher threshold
            ]
            
            print(f"\nMining {len(contexts_to_mine)} high-activity contexts:")
            for i, ctx in enumerate(contexts_to_mine, 1):
                print(f"  {i}. {ctx}: {context_anomaly_counts[ctx]:,} anomalies")
            
            if contexts_to_mine:
                context_patterns = pattern_miner.mine_patterns_per_context(
                    anomaly_feature_vectors,
                    contexts_to_mine,
                    eps=0.35,
                    min_samples=3
                )
                
                if len(context_patterns) > 0:
                    print(f"\n✓ Found {len(context_patterns)} context patterns")
                    
                    # Show top 10 only
                    print("\nTop 10 high-risk patterns:")
                    display_cols = ['context', 'cluster_id', 'size', 'failure_rate']
                    available_cols = [c for c in display_cols if c in context_patterns.columns]
                    print(context_patterns[available_cols].head(10).to_string(index=False))
                    
                    save_dataframe(context_patterns, 'LOG_BASED_context_specific_patterns.csv')

        # Clean up
        gc.collect()

        # ============================================================================
        # LIGHTWEIGHT VISUALIZATION (OPTIONAL - COMMENT OUT TO SAVE TIME/MEMORY)
        # ============================================================================

        if global_patterns is not None and len(global_patterns) > 0:
            print("\n" + "-" * 60)
            print("CREATING VISUALIZATION (LIGHTWEIGHT)")
            print("-" * 60)
            
            # Prepare features (will be sampled inside visualize)
            feature_matrix, feature_names = pattern_miner.prepare_features_for_clustering(
                anomaly_feature_vectors
            )
            
            cluster_labels = anomaly_feature_vectors['cluster'].fillna(-1).astype(int).values
            
            # Visualize (automatically samples to 10K points)
            pattern_miner.visualize_clusters_lite(
                anomaly_feature_vectors,
                feature_matrix,
                cluster_labels,
                save_path='LOG_BASED_cluster_visualization_lite.png',
                sample_size=10000  # Max 10K points in plot
            )
            
            del feature_matrix
            gc.collect()

        # ============================================================================
        # SAVE FINAL OUTPUT (OPTIMIZED)
        # ============================================================================

        # Save only essential columns to reduce file size
        essential_cols = [
            'anomaly_id', 'timestamp', 'scenario_id', 'run_id', 
            'anomaly_type', 'success', 'cluster'
        ]
        existing_cols = [c for c in essential_cols if c in anomaly_feature_vectors.columns]

        save_dataframe(anomaly_feature_vectors[existing_cols], 'LOG_BASED_anomaly_feature_vectors_clustered_lite.csv')

        print("\n" + "-" * 60)
        print("PATTERN MINING COMPLETE (OPTIMIZED MODE)")
        print("-" * 60)
        print("\nOutputs:")
        print("1. LOG_BASED_global_patterns.csv - Global cluster patterns")
        print("2. LOG_BASED_context_specific_patterns.csv - Context-specific patterns")
        print("3. LOG_BASED_anomaly_feature_vectors_clustered_lite.csv - Clustered anomalies (lite)")
        print("4. LOG_BASED_cluster_visualization_lite.png - Lightweight visualization")
        print("\nMemory optimizations applied:")
        print("- Sampling: Max 50K samples for clustering")
        print("- Dtype: float32 instead of float64 (50% memory savings)")
        print("- Contexts: Top 5 instead of 10")
        print("- Visualization: Max 10K points")
        print("- Output: Essential columns only")
        print("-" * 60)

        # Final cleanup
        gc.collect()
        print("=" * 80)
        # =========================
        # STEP 7: Relation Analysis
        # =========================
        print("7. Analyzing relations...")
        print("=" * 80)
        # Load feature vectors if needed
        if 'anomaly_feature_vectors' not in locals():
            anomaly_feature_vectors = pd.read_csv(get_output_path('anomaly_feature_vectors.csv'))
        
        analyzer = RelationGeneralizationAnalyzer(
            anomaly_feature_vectors=anomaly_feature_vectors,
            full_dataset=final_df_with_anomalies
        )
        
        # Run all analyses
        print("\n" + "-" * 60)
        print("RUNNING  ANALYSIS")
        print("-" * 60)

        # 1. Frequency analysis
        relation_freq_df = analyzer.analyze_relation_frequency()
        # 2. Correlation analysis
        correlation_df = analyzer.analyze_relation_anomaly_correlation()
        # 3. Predictive power analysis
        predictive_df = analyzer.analyze_predictive_power(use_full_dataset=True)
        # 4. Context-specific performance
        context_perf_df = analyzer.analyze_context_specific_performance()
        
        # Create visualizations
        print("\n" + "-" * 60)
        print("CREATING VISUALIZATIONS")
        print("-" * 60)

        # Create visualizations
        analyzer.create_comprehensive_visualizations(
            relation_freq_df,
            correlation_df,
            predictive_df,
            save_prefix='relation_generalization'
        )
        
        # Generate report
        report_text = analyzer.generate_summary_report(
            relation_freq_df,
            correlation_df,
            predictive_df,
            context_perf_df
        )
        
        print(" Relation analysis complete")
        print("=" * 80)

    else:
        print("=" * 80)
        print("Skipping log-based mode as per argument.")
        print("=" * 80)

    # =========================
    # Evaluation of Scenario-Based Model against Log-Based
    # =========================
    # ---- Scenario-level eval + confusion matrix (runs ONCE) ----
    if args.all or (args.log_based and args.scenario_based):
        print_banner("SCENARIO-LEVEL EVALUATION AGAINST LOGS")
        res = evaluate_scenario_level(
            logs_csv="LOG_BASED_analyzer_runs_anomalies.csv",
            scenario_predictions=agg.scenario_predictions,
            out_csv="SCENARIO_VS_LOG_level_comparison.csv",
            gt_anomaly_type="No Progress",
        )

        cmp_df = pd.read_csv(res["out_csv"])
        out_cm = agg.plot_confusion_matrix(cmp_df, out_png="SCENARIO_VS_LOG_cmp_confusion_matrix.png")

        print("[OK] scenario-level comparison:", res)
        print("[OK] confusion matrix saved:", out_cm)
    else:
        print("=" * 80)
        print("Skipping scenario-level evaluation against logs as per argument.")
        print("=" * 80)
    # =========================
    # Complete
    # =========================
    print("\n" + "=" * 80)
    print("ANALYSIS COMPLETE!")
    print("=" * 80)
    print(f"\nAll outputs saved to: {OUTPUT_DIR} and images to: {IMAGES_DIR}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Robot Navigation Analysis Pipeline")
    parser.add_argument('--scenario-based', action='store_true', 
                       help='Run Scenario-based Mode')
    parser.add_argument('--custom-scenario-based', action='store_true',
                    help='Run Scenario-based Mode on customScenarios')
    parser.add_argument('--log-based', action='store_true', 
                       help='Run Log-based Mode')
    args = parser.parse_args()
    args.all = len(sys.argv) == 1

    print_start_header()
 
    main(args)
    
    try:
        print_finish_footer(success=True)
    except Exception as e:
        print(f"\n[CRITICAL ERROR] {e}")
        print_finish_footer(success=False)
