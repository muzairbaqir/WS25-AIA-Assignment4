# Assignment 04


## 1. Traceability of requirements:

This detailed traceability report maps the robot navigation evaluation framework's requirements to specific design decisions, metrics, and algorithms implemented across Assignments 1, 2, 3 and 4.

### 1. Functional Requirements (FR) Traceability

The functional requirements define the core capabilities of the system, moving from raw data ingestion to predictive failure analysis.

*   **FR1: Sensor Data Collection**
    *   **Design Decision:** Implementation of the `TrajectoryDataset`, `ROSDatasetPreprocessor`, and `RunData` classes.
    *   **Implementation Detail:** To ensure a robust data foundation, the system uses automated discovery with `glob` to find CSV files across diverse environments. It uses "lazy loading" to cache poses, behaviors, and logs only when they are accessed, preventing memory exhaustion.
    *   **Justification:** These components automate the ingestion of LiDAR, odometry, and Ground Truth (GT) streams, fulfilling the requirement that the system gather all information relied upon for movement and environment details.

*   **FR2: Accurate Metric Computation**
    *   **Design Decision:** Development of the `merge_streams` and `merge_rosbag_with_poses` functions.
    *   **Implementation Detail:** Disparate data streams (AMCL estimated poses and GT) often have mismatched timestamps. The framework uses AMCL as the "backbone" and applies **linear interpolation** (`np.interp`) to pose data to ensure both streams exist on a synchronized timeline.
    *   **Metrics Selection:** Accuracy is quantified using **Mean Localization Error** (Euclidean distance between estimate and true pose), **Yaw Error** (absolute heading difference), and **Goal Success Rate**.
    *   **Justification:** Synchronization and specific mathematical formulas allow the robot to correctly calculate performance measures to evaluate how well it functions.

*   **FR3: Anomaly Detection**
    *   **Design Decision:** A hybrid approach using **Physics-Based Rules** and an unsupervised **Isolation Forest** model (from assign 2).
    *   **Implementation Detail:** Rule-based detection captures interpretable failure modes, such as **Stuck** (velocity < 0.01 m/s), **Oscillation**, and **Pose Jumps**. The Isolation Forest (300 estimators) learns "normalcy" from standard trajectories and flags deviations without requiring pre-labeled failure data.
    *   **Justification:** This meets the goal of noticing unusual readings or robot movements early to prevent bigger failures.

*   **FR4: Failure Prediction**
    *   **Design Decision:** Implementation of the `early_anomaly_score` and **Lead-Time Analysis**.
    *   **Implementation Detail:** The system computes a score by combining weighted Z-scores of curvature, "wobble" (angular velocity variance), and pose jumps. Lead-time analysis calculates the duration between the first detected anomaly and the run's end.
    *   **Justification:** Visual validation (Lead-Time Histogram) proves these scores spike significantly before a failure, allowing the system to foresee potential issues.

---

### 2. Quality / Non-Functional Requirements (NFR) Traceability

Non-functional requirements ensure the framework is efficient, scalable, and reliable for real-world application.

*   **NFR1: Performance Across Floor Types and Scenarios**
    *   **Design Decision:** Grouping by "Scenario Families" and using `MultiMapAnalysis`.
    *   **Implementation Detail:** The robot is tested across diverse environmental variations (e.g., door-width, hallway-window). The framework generates "Robot Failure Probability Across Environments" charts to ensure stability across complex geometries.
    *   **Justification:** This ensures navigation performance is maintained despite variations in surfaces or obstacle density.

*   **NFR2: Real-time / Low-Latency Computation**
    *   **Design Decision:** Vectorized operations in `OptimizedAnomalyDetector`.
    *   **Implementation Detail:** Instead of slow row-by-row loops, the system uses NumPy vectorized masks to detect anomalies across entire dataframes simultaneously. It also uses a pre-computed **Euclidean Distance Transform (EDT)** for wall distances to allow O(1) constant-time lookup during analysis.
    *   **Justification:** High-speed processing ensures metrics are available immediately for timely decision-making.

*   **NFR3: Minimum Training Possible**
    *   **Design Decision:** Use of unsupervised **DBSCAN clustering** and Isolation Forest.
    *   **Justification:** These algorithms learn patterns and failure modes directly from navigation data without a long or complicated training process, making them easy to set up.

*   **NFR4: Efficient Large Dataset Handling**
    *   **Design Decision:** `MemoryEfficientPatternMiner` implementation.
    *   **Implementation Detail:** To handle hundreds of scenarios, the miner applies aggressive optimizations: **Sampling** to 50,000 priority rows, **dtype optimization** (float32 saves 50% RAM), and **Incremental PCA** for dimensionality reduction without memory spikes.
    *   **Justification:** These techniques allow the system to process massive amounts of simulation data without slowing down or using excessive memory.

*   **NFR5/NFR6: Accuracy, Consistency, and Reproducibility**
    *   **Design Decision:** Standardized pipelines with fixed parameters.
    *   **Implementation Detail:** Preprocessing routines include sorting by time and dropping duplicates. All models and sampling routines use a fixed `random_state=42`.
    *   **Justification:** This ensures that re-running the same analysis yields identical results, building trust in the system's reliability.

---

### 3. Causal Reasoning and Root-Cause Identification

*   **Context Identification:**
    *   **Implementation:** The `SpatialContextMapper` identifies the robot's specific situation (e.g., "near door", "narrow corridor") by checking $(x, y)$ coordinates against map polygons extracted from `maps_details.json`.
    *   **Reasoning:** This focuses analysis on relevant conditions, improving interpretability.

*   **Atomic Relations and First-Order Logic (FOL):**
    *   **Implementation:** Dynamic functions (Velocity, DistToGoal) are converted into predicates like $\mathrm{Stuck}(run, t) \equiv \mathrm{Velocity} < 0.01$.
    *   **Causal Link:** These are combined into rules: $\forall run, t: \mathrm{Context}(\text{"narrow\_corridor"}) \wedge \mathrm{Stuck}(run, t) \implies \mathrm{Anomaly}(run, t)$.

*   **Validation through Lift and F1-Score:**
    *   **Implementation:** The system uses **Lift** to measure how much more likely a relation is in failures vs successes; **Lift > 2.0** indicates high causal importance.
    *   **Success Metric:** Predictive power is validated via **F1-Score**. Relations with an **F1 > 0.7** are categorized as "Excellent" predictors, justifying their use in automated safety systems.
    *   **Final Inference:** Confusion matrices for the best relations validate that the algorithms maximize correct detections (True Positives) and minimize dangerous missed failures (False Negatives).

## 2. Data understanding and summarization: 

This section provides an overview of the structure, contents, and characteristics of the available dataset. The dataset represents a recorded ROS 2–based simulation run and contains raw logs, configuration files, and post-processed artifacts derived from the execution of a navigation scenario.

### 2.1 Overall Dataset Structure

The overall dataset contains 100 scenarios along with all the maps details. For each scenario, 3 ROS runs were recoreded. A single run directory contains configuration files, ROS 2 bag recordings, extracted CSV files, and auxiliary assets. At a high level, it consists of:

- **ROS 2 bag data** capturing time-synchronized sensor and state information
- **Post-processed CSV files** derived from ROS topics
- **Scenario and run configuration files**
- **Simulation and launch-related resources**
- **Logs and auxiliary media files**

This structure supports both replay-based analysis (via rosbag2) and offline data analysis using tabular formats.

### 2.2 File Formats and Their Purpose

For the whole dataset, the following map details file was provided:

- **`maps_details.json`**  
  Contains data about each map used in the scenarios:
  - **Maps names**
  - **Spaces**: Each space (room or corridor) in a map with its corners.
  - **Doors**: Every door in a map with its corners.

A single run directory includes multiple file formats, each serving a specific role:

- **`.mcap`**  
  Binary ROS 2 bag file containing recorded topics (e.g., transforms, poses, sensor data). This is the primary raw data source.

- **`.yaml`**  
  Used for metadata and configuration:
  - `metadata.yaml`: rosbag2 metadata (duration, topics, message counts)
  - `run.yaml`: run-level configuration parameters
  - `tb4_bridge.yaml`: ROS–Gazebo or middleware bridge configuration

- **`.csv`**  
  Post-processed, human-readable representations of selected ROS topics:
  - `poses.csv`: robot pose information over time
  - `behaviors.csv`: high-level behavioral or state-related outputs
  - `rosbag2.csv`: aggregated or converted bag content

- **`.py`**  
  Python launch and utility scripts for simulation setup and execution.

- **`.sdf` / `.xacro`**  
  Simulation and world description files defining robot models, obstacles, and the environment.

- **`.md`**  
  Documentation files describing the dataset or simulation setup.

- **`.log` / `logs/` directory**  
  Runtime logs produced during execution, mainly for debugging, traceability and analyzing the run erros and warnings.

- **`.webm`**  
  Screen or simulation recordings for qualitative inspection.

### 2.3 Statistical Overview of the Dataset

A basic statistical characterization can be derived from the rosbag2 metadata and CSV files:

- **Temporal coverage**
  - Total simulation duration is defined in `rosbag2/metadata.yaml` (nanosecond resolution).
  - Timestamps are presented in both simuldation and system time.

- **Message-based statistics**
  - Number of recorded topics and message counts are listed in `metadata.yaml`.
  - CSV files typically contain:
    - One row per timestamped event
    - Columns representing state variables (e.g., position, orientation, behavior labels)
  - Log files typically contain:
    - One line per timestamped event
    - Direct info if the run succeeded or failed.
    - Errors and warnings detected during the run. This can be used to try to understand what anomalies could have been occured.

- **Sampling characteristics**
  - Sampling rates may vary per topic (e.g., transforms vs. behavior states).
  - CSV timestamps allow estimation of effective frequency and data gaps.

These statistics enable validation of data completeness, temporal consistency, and suitability for downstream analysis.

### 2.4 Sensor Logs and Recorded Signals

Sensor and state information is primarily stored in the ROS 2 bag file (`rosbag2_0.mcap`). Typical logged data includes:

- **TF / coordinate transforms**
  - Stored as time-stamped transforms with `header.stamp.sec` and `header.stamp.nanosec`
  - Represent spatial relationships between frames (e.g., map, odom, base_link)

- **Robot state and pose**
  - Extracted into `poses.csv` for easier numerical analysis
  - Includes position and orientation over simulation time

- **High-level behaviors**
  - Stored in `behaviors.csv`
  - Encodes behavioral states, planner modes, or task-level outputs

These logs collectively capture both low-level motion and high-level decision-making aspects of the run.

### 2.5 Scenario Description and Configuration Constituents

The scenario definition is distributed across multiple configuration and description files:

- **World and environment**
  - `world.sdf.xacro`: defines the simulated environment layout
  - Model files (`box.sdf.xacro`, `cylinder.sdf.xacro`) specify obstacles and objects

- **Robot and navigation setup**
  - `nav2/` directory and launch files configure the navigation stack
  - `nav2_launch.py`, `tb4_simulation_launch.py` define active nodes and parameters

- **Run-level configuration**
  - `scenario.config` : includes goal poses, start pose, map name and some info about sensor noise
  - `scenario.osc`: describes the logical structure of the scenario and its execution flow
  - `run.yaml`: specifies run parameters such as runs and scenarios IDs

Together, these constituents define **what was simulated**, **how it was executed**, and **under which parameters**, enabling reproducibility and interpretability of the recorded data.

---

## 3. **Feature identification and extraction**:

This section lists all identified features, functions, atomic relations, and contexts.

### 3.1 Static Features

For each scenario map, we extracted:

- **Spaces**: Each space (room or corridor) in the map with its corners and dimensions.
- **Doors**: Every door in the map with its location, corners, and dimensions.
- **Obstacles**: Every obstacle in the map with its room, corners, and dimensions.
- **Start pose**: The start pose (x, y, yaw) of the robot from the scenario.config file.
- **Goal poses**: The goal poses (x, y, yaw) the robot needs to reach from scenario.config. There can be more than one goal, so we locate them in order.
- **Laser noise params**: Gaussian noise std deviation and random drop percentage from scenario.config.
- **Robot footprint and radius**: TurtleBot4 length, width and height are based on [official specifications](https://turtlebot.github.io/turtlebot4-user-manual/overview/features.html#hardware-specifications). Radius is approximated as half the diagonal of the footprint.

### 3.2 Dynamic Functions

We use continuous and discrete functions to describe the robot's state and environment. These functions are also expressed in First-Order Logic (FOL) notation.

- **Distance to Goal**:
    $$
    \forall run, t:\ \mathrm{DistToGoal}(run, t) = d
    $$
    *Interpretation*: At time $t$ in run $run$, the robot is $d$ meters from the goal.

- **Velocity**:
    $$
    \forall run, t:\ \mathrm{Velocity}(run, t) = v
    $$
    *Interpretation*: At time $t$ in run $run$, the robot's velocity is $v$ m/s.

- **Angular Velocity**:
    $$
    \forall run, t:\ \mathrm{AngularVelocity}(run, t) = \omega
    $$
    *Interpretation*: At time $t$ in run $run$, the robot's angular velocity is $\omega$ rad/s.

- **Time Since Progress**:
    $$
    \forall run, t:\ \mathrm{TimeSinceProgress}(run, t) = \tau
    $$
    *Interpretation*: At time $t$ in run $run$, it has been $\tau$ seconds since the robot last made progress.

- **Wall Clearance**:
    $$
    \forall run, t:\ \mathrm{WallClearance}(run, t) = c
    $$
    *Interpretation*: At time $t$ in run $run$, the robot's clearance from the nearest wall is $c$ meters.

- **Localization Uncertainty**:
    $$
    \forall run, t:\ \mathrm{LocalizationUncertainty}(run, t) = u
    $$
    *Interpretation*: At time $t$ in run $run$, the robot's localization uncertainty is $u$ (unitless or as defined).

### 3.3 Atomic Relations

- **Stuck**
    $$
    \mathrm{Stuck}(run, t) \equiv \mathrm{Velocity}(run, t) < 0.01
    $$
    *Interpretation*: The robot is considered stuck if its velocity is less than 0.01 m/s.

- **No Progress**
    $$
    \mathrm{NoProgress}(run, t) \equiv \mathrm{ProgressRate}(run, t) < \epsilon
    $$
    *Interpretation*: The robot is not making progress if its progress rate is below a small threshold $\epsilon$.

- **Overspeed**
    $$
    \mathrm{Overspeed}(run, t) \equiv \mathrm{Velocity}(run, t) > v_{max}
    $$
    *Interpretation*: The robot is overspeeding if its velocity exceeds the safe maximum $v_{max}$.

- **Near Obstacle**
    $$
    \mathrm{NearObstacle}(run, t) \equiv \mathrm{ObstacleDistance}(run, t) < d_{obs}
    $$
    *Interpretation*: The robot is near an obstacle if the distance to the nearest obstacle is less than $d_{obs}$.

- **Wrong Way**
    $$
    \mathrm{WrongWay}(run, t) \equiv \mathrm{HeadingError}(run, t) > \theta_{thresh}
    $$
    *Interpretation*: The robot is going the wrong way if its heading error exceeds a threshold $\theta_{thresh}$.

- **Near Goal**
    $$
    \mathrm{NearGoal}(run, t) \equiv \mathrm{DistToGoal}(run, t) < d_{goal}
    $$
    *Interpretation*: The robot is near the goal if its distance to the goal is less than $d_{goal}$.

- **Stuck Near Obstacle**
    $$
    \mathrm{StuckNearObstacle}(run, t) \equiv \mathrm{Stuck}(run, t) \wedge \mathrm{NearObstacle}(run, t)
    $$
    *Interpretation*: The robot is stuck near an obstacle if both the "stuck" and "near obstacle" conditions are true at the same time.

### 3.4 Contexts

In our analysis, a **context** is a label that describes the specific situation or environment the robot is experiencing at a given time. Contexts help us interpret relations and rules more accurately by focusing on relevant conditions (such as "near a door", "in a narrow corridor", or "approaching the goal"). This allows us to apply different rules depending on where and how the robot is navigating, improving both interpretability and predictive power.

#### Spatial Room Identification

We identify the rooms present in the map. This allows us to create contexts that are not only threshold-based but also room-based, giving us an additional perspective on collecting information about anomalies by room.

#### How Did We Define and Extract Contexts?

1. **Feature-Based Context Assignment**
     - **Near Obstacle**: Assigned if the distance to the nearest obstacle is below a threshold.
     - **Narrow Corridor**: Assigned if the corridor width is less than a set value.
     - **Near Door**: Assigned if the robot is close to a door and the door width is tight.
     - **Near Goal**: Assigned if the distance to the goal is below a certain threshold.
     - **Open Space**: Assigned if the robot is not near any obstacles or walls.

2. **Rule-Based Context Logic**
     - For each time step, we evaluated logical conditions using the robot's features. If a condition was met, the corresponding context label was assigned. For example:
         - If `corridor_width < 0.5m`, assign context `"narrow_corridor"`.
         - If `dist_to_goal < 1.0m`, assign context `"near_goal"`.
         - If `door_width < robot_width + margin`, assign context `"tight_doorway"`.

3. **Hierarchical and Overlapping Contexts**
     - Contexts can overlap (e.g., the robot can be both "near obstacle" and "in narrow corridor" at the same time). We allowed multiple context labels per time step to capture these complex situations.

4. **Context Extraction in the Pipeline**
     - During feature engineering, we computed these context labels for every anomaly timestamp. The context information was then used to:
         - Filter which relations and rules are relevant in each situation.
         - Improve the interpretability and generalization of extracted FOL rules.

#### Example

- **Context Definition**:
    $$
    \mathrm{Context}(run, t, \text{"narrow\_corridor"}) \equiv \mathrm{CorridorWidth}(run, t) < 0.5
    $$
- **Rule Using Context**:
    $$
    \forall run, t:\ \mathrm{Context}(run, t, \text{"narrow\_corridor"}) \wedge \mathrm{Stuck}(run, t) \implies \mathrm{Anomaly}(run, t)
    $$
    *Interpretation*: If the robot is stuck while in a narrow corridor, an anomaly is likely.

---

## 4. **Metric definition and justification**:

  This guide provides a detailed breakdown of every metric derived during the assignments, from foundational physics-based calculations to advanced temporal and spatial reasoning features. These metrics were specifically selected to satisfy **Functional Requirement 2** (Accurate Metric Computation) and **Requirement 3** (Anomaly Detection).

  ---

  ### 1. Core Performance & Localization Metrics
  These metrics serve as the baseline for evaluating whether a navigation mission was successful and how precisely the robot maintained its state.

  *   **Mean Localization Error:** The average Euclidean distance between the robot’s estimated position (AMCL) and its true position (Ground Truth) over a sequence of $N$ time steps.
      *   **Formula:** $\text{Mean Error} = \frac{1}{N}\sum_{i=1}^{N} \sqrt{(x_i^{est}-x_i^{true})^2 + (y_i^{est}-y_i^{true})^2}$.
  *   **Max Localization Error:** The single largest deviation observed during a run.
  *   **Yaw Error (Orientation Error):** The absolute difference between the robot's estimated heading and its actual heading.
      *   **Formula:** $\text{Yaw Error} = |\theta^{est} - \theta^{true}|$.
  *   **Goal Success Rate:** The percentage of goals reached out of total attempted goals.
  *   **Goal Reaching Time:** The total duration from start to reaching the target.

  **Justification:** These metrics quantify how well the robot knows its location, which is crucial for precise maneuvering. In **Causal Reasoning**, a high localization error often correlates with "Machine Phenomena" like inaccurate sensor data interpretation.

  ---

  ### 2. Kinematic & Physical Motion Metrics
  Derived primarily in Assignment 1, these metrics describe the robot's physical behavior in the simulation world.

  *   **Linear Velocity ($v$):** Calculated as the Euclidean distance between consecutive $(x, y)$ coordinates over time.
  *   **Acceleration ($a$):** The derivative of velocity over time.
  *   **Angular Velocity ($\omega$):** The rate of change in the robot's heading (yaw).
  *   **Curvature:** Calculated as the ratio of absolute angular velocity to linear velocity ($|w| / (|v| + \epsilon)$).

  **Justification for Anomaly Detection:** Sudden spikes in acceleration (> 0.3 m/s²) or erratic motion (high speed combined with high acceleration) are deterministic indicators of failure. In **Causal Reasoning**, high curvature in narrow passages helps identify "World Phenomena" where complex geometry causes the robot to struggle.

  ---

  ### 3. Advanced Error & Sensitivity Metrics
  Developed in Assignment 2, these metrics enhance the sensitivity of the anomaly detection model.

  *   **Absolute Position Error (APE):** The raw Euclidean difference between estimated and ground truth poses.
  *   **Squared Pose Error:** The square of the position error, used to increase the model's sensitivity to large, sudden deviations.
  *   **Relative Pose Error:** APE normalized by the ground truth movement to account for different travel speeds.
  *   **Covariance-Weighted Error:** This scales the raw position error by the robot’s own internal uncertainty (covariance total).

  **Justification:** These metrics are essential for the **Isolation Forest** model. By weighting error against internal uncertainty, the system reduces false positives from noisy sensors while highlighting genuine planning logic failures.

  ---

  ### 4. Temporal-Aware Features (Causal Differentiators)
  Introduced in Assignment 3, these metrics emphasize *duration*, which the code identifies as the key differentiator between successful and failed runs.

  *   **Time Since Progress ($F1$):** The time elapsed since the robot last moved at least 0.1m closer to the goal.
  *   **Cumulative Stopped Time ($F2$):** The total time spent in a "Stopped" state (velocity < 0.01 m/s) within a sliding 30-second window.
  *   **Time in Current Room ($F3$):** The duration the robot has remained within a specific spatial context/room.
  *   **Path Efficiency ($F5$):** The ratio of progress toward the goal versus the actual distance traveled.
  *   **Recovery Attempt Count ($F8$):** The number of significant direction changes (> 45°) in the last 20 seconds, acting as an "Oscillation Indicator".
  *   **Backward Motion Ratio ($F10$):** The ratio of time spent moving *away* from the goal versus moving toward it, serving as a "Retreat Indicator".

  **Justification for Causal Reasoning:** These metrics provide the "why" behind an anomaly. For example, a high **Backward Motion Ratio** identifies a robot attempting to exit a dead-end, while **Time Since Progress** helps distinguish a temporary pause for obstacle avoidance from a definitive "Stuck" failure.

  ---

  ### 5. Uncertainty & Predictive Scores
  These metrics focus on the **Early Warning System** (FR4) and the reliability of the detection itself.

  *   **Covariance Trace (Total Uncertainty):** The sum of uncertainty across X, Y, and Yaw axes from the `pose.covariance` data.
  *   **Robust Z-Scores:** A normalized score for features like curvature and "wobble" (RMS of angular velocity) used to find outliers without being skewed by noisy sensor artifacts.
  *   **Early Anomaly Score:** A weighted composite score calculated as:
      *   $0.6 \times \text{Curvature Z-score} + 0.8 \times \text{Wobble Z-score} + 3.0 \times \text{Pose Jumps} + 1.5 \times \text{Stuck Flag} + 1.0 \times \text{Oscillation Flag}$.
  *   **Lift Metric:** The ratio of how much more likely a relation (like `r_stuck`) appears in a failure run versus a success run.

  **Justification:** The **Early Anomaly Score** allows the system to foresee potential failures (like a robot about to hit an obstacle) well before they occur. The **Lift** metric is the cornerstone of **Generalization Analysis**, proving that derived relations represent genuine failure patterns across different environments and aren't just noise.

## 5. **Anomaly detection approach and validation**:

### 5.1 Anomaly Detection Approaches:

We have worked on two different approaches to be able to detect anomalies:

#### We implement a rule-based/threshold-based anomaly detection model

  - Uses predefined thresholds for temporal and spatial features
  - Combines state (velocity, progress) with duration, so we not only detect such as whether the robot is stuck but also for how long it is stuck. This information is used to interpret/detect different anomalies.
      ```python
      r['r_stuck_stopped'] = r['r_stopped'] & (time_in_state > self.LONG_DURATION)
      r['r_stuck_slow_movement'] = r['r_very_slow'] & (time_in_state > self.MODERATE_DURATION)
      r['r_stuck_no_recovery'] = r['r_no_progress'] & (time_in_state > self.LONG_DURATION)
      ```
  - Some rules incorporate spatial context (near goal, near obstacle), so we consider where the robot is, not just what it's doing. Such as if the robot is stuck near the goal for more than five seconds we identify it as "near_goal_not_reached" anomaly. But without spatial contexts any robot stuck for more than five seconds would be considered as anomaly.

  - Rules are applied in priority order, so rules are checked in sequence, not simultaneously. With this logic we try to  pick the most urgent/safety-critical anomalies first. So this priority system transforms anomaly detection from a descriptive ("Here are all the things wrong") to a prescriptive ("Here's the most important thing to fix right now") system, which is essential for real-time robotic control.

#### We implement Isolation Forest for Anomaly Detection

  - Another method we implemented in Assignment2 was an unsupervised learning model with Isolation Forest. 
  - The model detects abnormal behaviour or anomalies by learning what normal behaviour looks like from kinematic data.
  - It flags points which deviate from normal behaviour/points


### 5.2 Validation and Evaluation Methodologies used:

#### A. Log-Based Ground Truth Validation
  1. Ground truth extraction: Anomalies extracted from system logs for each timestamp
  2. Direct comparison: Detected anomalies compared against log-extracted anomalies
  3. Accuracy assessment: Measures how well detection algorithms match actual system logs

#### B. Outcome Correlation Validation
  1. Mission outcome comparison: Analyzes correlation between detected anomalies and mission success/failure
  2. Quantitative metrics: Computes lift ratios (how much more frequent in failures vs successes)
  3. Statistical significance: Uses chi-square tests to validate non-random correlations
  4. Importance categorization: Classifies anomalies as High/Medium/Low importance based on predictive strength
  5. analyze_relation_anomaly_correlation(): is performing validation of our detected anomalies by analyzing how well they correlate with actual mission outcomes (success vs failure).

#### C. Performance Metrics and Visualization
  1. Confusion matrices: Shows true/false positives/negatives for best-performing relations
  2. Precision-recall analysis: Quantifies trade-off between detection accuracy and coverage
  3. F1 scoring: Provides balanced performance metric for anomaly detection quality

---

## 6. **Causal analysis and root-cause identification**:

  This explains causal analysis and root-cause identification framework developed throughout the assignemnts. This phase moves beyond simply noticing *that* a robot failed to explain *why* it failed, utilizing a structured approach that links environment, task, and robot behaviors.

  ### 1. The Multi-Relational Approach to Causal Analysis
  The methodology identifies causes by analyzing the interaction between three core pillars: the **Environment** (World Phenomena), the **Robot** (Machine Phenomena), and the **Task** (Navigation Goals).

  *   **World Phenomena (Environment):** These are external causes like narrow passages, complex geometries (corners/walls), or uneven terrain that hinder navigation.
  *   **Machine Phenomena (Robot):** These are internal failures, such as sensor data misinterpretation, latency in processing, or failures in path planning and obstacle avoidance logic.
  *   **Task-Robot Relations:** The system evaluates how the robot performs relative to its mission, using metrics like **Distance to Goal** and **Time Since Progress** to determine if the robot is fulfilling its objective.

  ### 2. Justification of Causal Assumptions and Representations
  The project represents these causal links using **First-Order Logic (FOL)** and **Spatial Contexts**, providing a human-interpretable "reasoning" layer.

  #### First-Order Logic (FOL) Representation
  Causal assumptions are formalized into **Atomic Relations**. For example, the assumption that a robot is "stuck" is represented as:

$$
\text{Stuck}(run, t) \equiv \text{Velocity}(run, t) < 0.01
$$

where the velocity is measured in m/s.

  By representing behaviors as logical predicates, the system can build composite rules that explain anomalies. A rule like $Context(\text{"narrow\_corridor"}) \wedge Stuck \implies Anomaly$ creates a clear causal link: the tight environment (Context) caused the robot to stop (Relation), resulting in a failure (Anomaly).

  #### Spatial Context Identification
  The system uses a `SpatialContextMapper` to identify where the robot is (e.g., "near door", "in corridor") using map polygons. This is vital for causal reasoning because a robot stopping in an "Open Space" might indicate a sensor failure (Machine Phenomenon), while stopping "Near Door" likely indicates a geometric obstacle (World Phenomenon).

  ### 3. Methodology for Identifying Root Causes
  The code implements an interpretable pipeline to mine these causes automatically:

  1.  **Feature Normalization:** Continuous features are scaled, with **temporal features** (e.g., duration of a state) given a **60% weighting**. This is based on the causal assumption that the *duration* of an abnormal state is the primary differentiator between a temporary obstacle and a mission-ending failure.
  2.  **Unsupervised Clustering (DBSCAN):** The system groups similar anomaly events based on these features. This allows the model to discover natural "failure modes" (e.g., a "stuck" cluster vs. a "wrong way" cluster) without needing human labels.
  3.  **Rule Extraction:** For each discovered cluster, the system mines dominant relations to generate FOL rules that describe the conditions under which that specific anomaly arises.

  ### 4. Validation of Causal Explanations
  To ensure these causal explanations are not just artifacts of the data, the project uses a rigorous **Generalization Analysis**.

  *   **Lift Metric:** This validates the strength of a causal predictor. A **Lift > 2.0** indicates that a relation (like `StuckNearObstacle`) is much more likely to appear in a failure run than a success run, proving a strong correlation between that behavior and the outcome.
  *   **F1-Score and Quality Thresholds:** Rules are categorized by their predictive quality. **"Excellent"** relations have an **F1 > 0.7**, signifying they are highly reliable for automated systems.
  *   **Confusion Matrix:** The system generates 2x2 heatmaps for the best relations to evaluate **True Positives** (correctly identified causes) and **False Negatives** (dangerous missed failures). In safety-critical robotics, the framework prioritizes high **Recall** to ensure no potential crash cause is ignored.
  *   **Log-Based Ground Truth:** The detected anomalies are compared against semantic failure classifications derived directly from `system.log` (e.g., "Planning Failure", "Spin Timeout"). If the FOL rules match the internal software logs, the causal explanation is considered validated.

## 7. **End-to-end pipeline design**: Your pipeline should support the following two modes:

  ### Scenario-based prediction:

  - We only use robot information, scenario.config, and maps_details.json, extract some environmental features from them and then try to predict some possible anomalies and success/failure chances depending on the number of predicted anomalies. We also implemented some custom scenarios for scenario based predictions.

  ### Log-based prediction: 

  - We use csv files, robot information, and maps to detect possible anomalies as explained in the anomaly detection section. Thus our pipeline detects anomalies using the dataset gathered the navigation runs.
  - We mine anomalies from logs and use them as ground truth to reason about the anomalies we detected.

---

## 8. **Answers to the questions**:

### 8.1 Generalization and scalability: Discussion of how the proposed approach can generalize to different robots and environments and describe required variations in data to support such generalization.

  #### Generalization to Different Robots
  - Dynamic Thresholding: A core design decision for robot generalization is that thresholds are not hard-coded for one specific model. For instance, the prerpocess_rosbag function dynamically calculates the robot_width by inspecting transform data between the wheels (transforms.transform.translation.y), allowing the pipeline to adapt automatically to different footprints
  - Universal Atomic Relations: The First-Order Logic (FOL) predicates, such as Stuck (v<0.01 m/s) or Overspeed (v>vmax), represent physical states common to all mobile robots. If a robot changes, the user only needs to update these specific parameter values (like vmax or goal distance thresholds) within the TemporalAtomicRelations class to maintain accuracy.
  - Consistent Data Patterns: Because the framework operates on standardized streams (LiDAR, Poses, and Behaviors), the internal logic remains valid as long as the new robot provides these standard ROS 2 topics

  ####  Generalization to Different Environments
  Generalization across environments ensures that the framework can distinguish between World Phenomena (environmentally driven failures) and Machine Phenomena (robot logic failures) regardless of the floorplan.

  - Spatial Context Awareness: To prevent "overfitting" detection rules to a specific map, the system uses a SpatialContextMapper. This component uses map polygons to label the robot's environment (e.g., "narrow corridor," "near door," or "open space"). This allows rules to be context-specific; for example, being "stuck" is a high-risk anomaly in a "narrow corridor" but might be normal behavior in an "open space" while waiting for a path update.
  - Generalization Analysis via "Lift": The framework uses the Lift metric to validate environmental transferability. A relation has high importance if it is significantly more likely to appear in failures than successes (Lift>2.0) across the entire dataset of 100 scenarios. If a relation only appears in one scenario, it is flagged as noise or an artifact rather than a generalizable pattern.
  - Scenario Families: Testing the framework against "scenario families" (e.g., door-width, hallway-window, room-size-less) ensures that the navigation reliability is maintained across varied geometries and floor types.

 #### Scalability: Handling Large Datasets (NFR4)
  To satisfy the requirement of handling large datasets efficiently (NFR4), the system implements several "Ultra-Optimized" features in the MemoryEfficientPatternMiner.

  - Vectorized Operations: The OptimizedAnomalyDetector replaces slow row-by-row Python loops with NumPy/Pandas vectorized masks. This allows the system to process hundreds of thousands of data points simultaneously, which is critical for real-time computation (NFR2).
  - Memory-Efficient Data Types: The system aggressively optimizes memory by converting data types. It uses float32 instead of float64 for normalized features (saving 50% RAM) and int8 for binary relation columns.
  - Intelligent Sampling: For massive datasets, the system samples data to a manageable limit (e.g., 50,000 rows). It uses a stratified strategy that prioritizes keeping all failure cases (high priority) while sampling successes to maintain a balanced signal for the DBSCAN clustering algorithm.
  - Incremental PCA: Instead of traditional PCA, which requires loading the entire feature matrix into memory, the system uses IncrementalPCA in batches to perform dimensionality reduction for cluster visualization.

 #### Required Variations in Data for Generalization
  To support such high levels of generalization, the input data must include specific variations during collection:

  - Environmental Variation: Data must span different "Scenario Families" to capture World Phenomena like narrow passages, varied door widths, and obstacle densities.
  - Sensor Noise and Drop Rates: To generalize across hardware qualities, the dataset includes variations in laserscan_gaussian_noise_std_deviation and laserscan_random_drop_percentage.
  - Metadata Consistency: Supporting generalizations requires standardized configuration files (scenario.config) and map geometry details (maps_details.json) to accurately define the robot's spatial context and goal parameters

### 8.2 Challenges and insights: What are the major challenges encountered during the project? Discuss unique insights gained in terms of approach and results.

  ### Major Project Challenges:

  - One challenge was with the anomalies in the logs were not being apperant/obvious. Meaning we had to spot some key words or sentences in a log and say that this key word may correspond to this anomaly. And all these assumptions effect the final results/precision/recall we get, so we had to be careful. Because, we were going to use these anomalies which were derived from logs are ground truth, and compare them against anomalies detected by our functions/methods. 
  - Stream Synchronization and Mismatched Data: The framework had to reconcile data from AMCL (estimated poses), Ground Truth (true poses), and Behaviors, all recorded with mismatched timestamps. This required complex linear interpolation and merge_asof logic to ensure that every estimated position could be accurately compared to its real-world counterpart.
  - Computational Scalability: As the dataset grew to 100 scenarios with 1.6 million data points, the system faced massive memory spikes. This necessitated building a "MemoryEfficientPatternMiner" that utilized float32 data types and aggressive stratified sampling to prevent kernel crashes during clustering.

  ### Unique Insights Gained:
  - Temporal Features as Differentiators: A major insight was that the duration of a robot's state is the best predictor of failure. While successful runs might slow down momentarily, failure runs are characterized by prolonged periods without progress. This led to weighting temporal features at 60% during normalization to capture these critical dynamics.
  - The Importance of Spatial Context: The team realized that an anomaly cannot be defined by movement alone; it must be interpreted through the environment. By using map polygons to identify "narrow corridors" or "near doors," the system could apply context-dependent rules, such as identifying that a robot being "stuck" is a much higher risk in a tight passage than in an open room.
  - Hybrid Anomaly Detection Efficacy: Combining unsupervised Isolation Forest (to find complex deviations without labels) with physics-based rules (to capture interpretable failures like "Stuck") provided the most robust results. This allowed the system to detect patterns that simple thresholds might miss.

